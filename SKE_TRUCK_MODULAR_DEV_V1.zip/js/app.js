// ── 77 จังหวัด ────────────────────────────────────────────────────────────────
const PROVINCES=["กรุงเทพมหานคร","กระบี่","กาญจนบุรี","กาฬสินธุ์","กำแพงเพชร","ขอนแก่น","จันทบุรี","ฉะเชิงเทรา","ชลบุรี","ชัยนาท","ชัยภูมิ","ชุมพร","เชียงราย","เชียงใหม่","ตรัง","ตราด","ตาก","นครนายก","นครปฐม","นครพนม","นครราชสีมา","นครศรีธรรมราช","นครสวรรค์","นนทบุรี","นราธิวาส","น่าน","บึงกาฬ","บุรีรัมย์","ปทุมธานี","ประจวบคีรีขันธ์","ปราจีนบุรี","ปัตตานี","พระนครศรีอยุธยา","พะเยา","พังงา","พัทลุง","พิจิตร","พิษณุโลก","เพชรบุรี","เพชรบูรณ์","แพร่","ภูเก็ต","มหาสารคาม","มุกดาหาร","แม่ฮ่องสอน","ยโสธร","ยะลา","ร้อยเอ็ด","ระนอง","ระยอง","ราชบุรี","ลพบุรี","ลำปาง","ลำพูน","เลย","ศรีสะเกษ","สกลนคร","สงขลา","สตูล","สมุทรปราการ","สมุทรสงคราม","สมุทรสาคร","สระแก้ว","สระบุรี","สิงห์บุรี","สุโขทัย","สุพรรณบุรี","สุราษฎร์ธานี","สุรินทร์","หนองคาย","หนองบัวลำภู","อ่างทอง","อำนาจเจริญ","อุดรธานี","อุตรดิตถ์","อุทัยธานี","อุบลราชธานี"];

// ── ชุดไอคอน SVG ระดับมืออาชีพ (เส้นสม่ำเสมอ สไตล์ Lucide) แทนอิโมจิ ───────────────
// ไอคอนทำตัวเหมือน "ตัวอักษร": กว้าง/สูง = 1em ปรับขนาดตาม font-size และรับสีจาก color (currentColor)
const SKE_ICONS = {
  overview:'<rect width="7" height="9" x="3" y="3" rx="1"/><rect width="7" height="5" x="14" y="3" rx="1"/><rect width="7" height="9" x="14" y="12" rx="1"/><rect width="7" height="5" x="3" y="16" rx="1"/>',
  wrench:'<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>',
  money:'<path d="M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1"/><path d="M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4"/>',
  leave:'<path d="M13 8c0-2.76-2.46-5-5.5-5S2 5.24 2 8h2l1-1 1 1h4"/><path d="M13 7.14A5.82 5.82 0 0 1 16.5 6c3.04 0 5.5 2.24 5.5 5h-3l-1-1-1 1h-3"/><path d="M5.89 9.71c-2.15 2.15-2.3 5.47-.35 7.43l4.24-4.25.7-.7.71-.71 2.12-2.12c-1.95-1.96-5.27-1.8-7.42.35z"/><path d="M11 15.5c.5 2.5-.17 4.5-1 6.5h4c2-5.5-.5-12-1-14"/>',
  settings:'<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>',
  home:'<path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
  grid:'<rect width="7" height="7" x="3" y="3" rx="1"/><rect width="7" height="7" x="14" y="3" rx="1"/><rect width="7" height="7" x="14" y="14" rx="1"/><rect width="7" height="7" x="3" y="14" rx="1"/>',
  alert:'<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
  bell:'<path d="M10.268 21a2 2 0 0 0 3.464 0"/><path d="M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326"/>',
  check:'<path d="M21.801 10A10 10 0 1 1 17 3.335"/><path d="m9 11 3 3L22 4"/>',
  oil:'<path d="M12 22a7 7 0 0 0 7-7c0-2-1-3.9-3-5.5s-3.5-4-4-6.5c-.5 2.5-2 4.9-4 6.5C4 11.1 3 13 3 15a7 7 0 0 0 7 7z"/>',
  history:'<path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l4 2"/>',
  truck:'<path d="M5 18H3c-.6 0-1-.4-1-1V7c0-.6.4-1 1-1h10c.6 0 1 .4 1 1v11"/><path d="M14 9h4l4 4v4c0 .6-.4 1-1 1h-2"/><circle cx="7" cy="18" r="2"/><path d="M15 18H9"/><circle cx="17" cy="18" r="2"/>',
  bayin:'<path d="M22 8.35V20a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V8.35A2 2 0 0 1 3.26 6.5l8-3.2a2 2 0 0 1 1.48 0l8 3.2A2 2 0 0 1 22 8.35Z"/><path d="M6 18h12"/><path d="M6 14h12"/><rect width="12" height="8" x="6" y="14"/>',
  boxup:'<path d="m18 9-6-6-6 6"/><path d="M12 3v14"/><path d="M5 21h14"/>',
  boxdown:'<path d="M12 17V3"/><path d="m6 11 6 6 6-6"/><path d="M19 21H5"/>',
  returning:'<path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/>',
  hourglass:'<path d="M5 22h14"/><path d="M5 2h14"/><path d="M17 22v-4.172a2 2 0 0 0-.586-1.414L12 12l-4.414 4.414A2 2 0 0 0 7 17.828V22"/><path d="M7 2v4.172a2 2 0 0 0 .586 1.414L12 12l4.414-4.414A2 2 0 0 0 17 6.172V2"/>',
  box:'<path d="m16 16 2 2 4-4"/><path d="M21 10V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l2-1.14"/><path d="M16.5 9.4 7.55 4.24"/><polyline points="3.29 7 12 12 20.71 7"/><line x1="12" x2="12" y1="22" y2="12"/>',
  arrived:'<path d="M12 22s8-5.33 8-12a8 8 0 1 0-16 0c0 6.67 8 12 8 12z"/><path d="m9 10 2 2 4-4"/>',
  idle:'<path d="M21.801 10A10 10 0 1 1 17 3.335"/><path d="m9 11 3 3L22 4"/>',
  user:'<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
  note:'<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M16 13H8"/><path d="M16 17H8"/><path d="M10 9H8"/>',
  pin:'<path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0"/><circle cx="12" cy="10" r="3"/>'
};
function skeIcon(name){const p=SKE_ICONS[name];return p?('<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:1em;height:1em;display:inline-block;vertical-align:-.18em;flex-shrink:0" aria-hidden="true">'+p+'</svg>'):'';}
window.skeIcon = skeIcon;

const STATUSES=[
  {id:"loading_bay",label:"เข้าช่องขึ้นงานแล้ว",ic:"bayin",    emoji:"🟢",color:"#15803D",bg:"#F0FDF4",border:"#86EFAC"},
  {id:"unload_bay", label:"ถึงแล้วรอลงงาน",  ic:"arrived",  emoji:"🔵",color:"#1D4ED8",bg:"#EFF6FF",border:"#93C5FD"},
  {id:"loading",    label:"กำลังขึ้นงาน",         ic:"boxup",    emoji:"🟡",color:"#92400E",bg:"#FFFBEB",border:"#FCD34D"},
  {id:"unloading",  label:"กำลังลงงาน",           ic:"boxdown",  emoji:"🟠",color:"#C2410C",bg:"#FFF7ED",border:"#FCA5A5"},
  {id:"traveling",  label:"ออกเดินทาง",           ic:"truck",    emoji:"🚛",color:"#0E7490",bg:"#ECFEFF",border:"#67E8F9"},
  {id:"returning",  label:"กำลังไหลกลับ",         ic:"returning",emoji:"🔁",color:"#0F766E",bg:"#F0FDFA",border:"#5EEAD4"},
  {id:"standby",    label:"สแตนบายรอขึ้นงาน",      ic:"hourglass",emoji:"⏳",color:"#6D28D9",bg:"#F5F3FF",border:"#C4B5FD"},
  {id:"got_job",    label:"ได้งานแล้ว",            ic:"box",      emoji:"📦",color:"#4F46E5",bg:"#EEF2FF",border:"#A5B4FC"},
  {id:"repairing",  label:"กำลังซ่อมรถอยู่",       ic:"wrench",   emoji:"🔧",color:"#B91C1C",bg:"#FEF2F2",border:"#FCA5A5"},
  {id:"done",       label:"สแตนบายว่างงาน",        ic:"idle",     emoji:"✅",color:"#065F46",bg:"#ECFDF5",border:"#6EE7B7"},
];
const INACTIVE_STATUS={id:"inactive",label:"ยังไม่ได้ผูกรถ (ถูกสลับออก)",ic:"idle",emoji:"⚪",color:"#64748B",bg:"#F1F5F9",border:"#CBD5E1"};
function getS(id){if(id==='inactive')return INACTIVE_STATUS;return STATUSES.find(s=>s.id===id)||STATUSES.find(s=>s.id==='standby')||STATUSES[0];}
// ── กันข้อมูลซ้ำ: ถ้ามีพนักงาน 2 คนขึ้นไปถือทะเบียนรถเดียวกันพร้อมกัน (เช่น แก้ไขโปรไฟล์ตรงๆ โดยไม่ผ่าน "สลับคนขับ"
// หรือข้อมูลเก่าค้างจากก่อนหน้านี้) ให้ถือว่าคนที่อัปเดตสถานะล่าสุดคือคนขับตัวจริงของคันนั้น แล้วตัดคนอื่นออกจากบอร์ดสถานะ
// ไม่กระทบข้อมูล/ประวัติเดิมของใครเลย แค่ไม่เอามาแสดง/นับซ้ำในหน้าสถานะเท่านั้น
function _dedupByPlate(list){
  const latestByPlate={};
  list.forEach(e=>{
    const p=(e.plate||'').trim();
    if(!p)return;
    const t=e.updatedAt||'';
    if(!latestByPlate[p]||t>(latestByPlate[p].updatedAt||''))latestByPlate[p]=e;
  });
  return list.filter(e=>{
    const p=(e.plate||'').trim();
    // ไม่มีทะเบียนรถ = พนักงานออฟฟิศ/ตำแหน่งที่ไม่ได้ผูกกับรถ — ไม่นับรวมในภาพรวม "สถานะรถ" ของแดชบอร์ด
    // (ใช้ฟังก์ชันนี้เฉพาะจุดสรุป/แสดงกลุ่มสถานะรถ 6 จุดเท่านั้น ไม่กระทบระบบอื่น เช่น จัดการพนักงาน/ลา/เบิกเงิน)
    if(!p)return false;
    return latestByPlate[p]===e;
  });
}
// คำนวณลำดับคิวของพนักงานคนนี้ ตอนสถานะเป็น "สแตนบายว่างงาน" — ใช้ตรรกะเดียวกับฝั่งแอดมิน (เรียงตามเวลาว่างงาน จังหวัดเดียวกัน)
function getQueuePosition(emp){
  if(!emp||emp.status!=='done')return null;
  const prov=emp.province||'ไม่ระบุจังหวัด';
  const group=employees.filter(e=>e.status==='done'&&(e.province||'ไม่ระบุจังหวัด')===prov);
  group.sort((a,b)=>(a.updatedAt||'')>(b.updatedAt||'')?1:-1);
  const idx=group.findIndex(e=>e.id===emp.id);
  if(idx===-1)return null;
  return{pos:idx+1,total:group.length,prov};
}



// แสดงรายชื่อเพื่อนที่สแตนบาย/ว่างงานจังหวัดเดียวกันบนหน้าพนักงาน
// ใช้ลำดับเดียวกับหน้าแผงผู้ดูแล: เรียงจากคนที่เริ่มว่างงาน/สแตนบายนานสุดก่อน
function renderSameStandbyEmployees(me){
  if(!me||!me.province)return'';
  const isDone=me.status==='done';
  const isStandby=me.status==='standby';
  if(!isDone&&!isStandby)return'';
  const prov=me.province||'ไม่ระบุจังหวัด';
  const statusId=isDone?'done':'standby';
  const list=(employees||[])
    .filter(e=>e&&e.status===statusId&&((e.province||'ไม่ระบุจังหวัด')===prov))
    .sort((a,b)=>{
      const ta=isDone?(a.updatedAt||''):(a.standbyAt||a.updatedAt||'');
      const tb=isDone?(b.updatedAt||''):(b.standbyAt||b.updatedAt||'');
      return ta>tb?1:(ta<tb?-1:0);
    });
  if(!list.length)return'';
  const title=isDone?`เพื่อนสแตนบายว่างงานใน${esc(prov)} (${list.length} คัน)`:`เพื่อนสแตนบายรอขึ้นงานใน${esc(prov)} (${list.length} คัน)`;
  const sub=isDone?'เรียงลำดับตามเวลาเริ่มว่างงาน (คิวแรกควรได้งานก่อน)':'เรียงลำดับตามเวลาเริ่มสแตนบาย';
  return `<div style="margin-top:10px;padding:10px 8px;background:#F0FDF4;border:1.5px solid #6EE7B7;border-radius:12px;">
    <div style="display:flex;align-items:center;gap:6px;color:#065F46;font-size:13px;font-weight:900;margin-bottom:3px;">👥 ${title}</div>
    <div style="font-size:11px;color:#6B7280;margin-bottom:8px;">${sub}</div>
    <div style="display:flex;flex-direction:column;gap:7px;">
      ${list.map((e,i)=>{
        const timeVal=isDone?(e.updatedAt||''):(e.standbyAt||e.updatedAt||'');
        const isMe=e.id===me.id;
        return `<div style="display:flex;align-items:center;gap:8px;padding:8px;background:#fff;border:1px solid #D1FAE5;border-radius:10px;box-shadow:0 1px 4px rgba(0,0,0,.04);">
          <span style="flex-shrink:0;width:26px;height:26px;border-radius:50%;background:#065F46;color:#fff;font-size:12px;font-weight:900;display:flex;align-items:center;justify-content:center;">${i+1}</span>
          <div class="avatar" style="width:34px;height:34px;font-size:14px;flex-shrink:0;">${avatarImg(e,34)}</div>
          <div style="flex:1;min-width:0;">
            <div style="font-size:12.5px;font-weight:800;color:#1a1a2e;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${esc(e.name)}${isMe?' (คุณ)':''}</div>
            <div style="font-size:11px;color:#888;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">🚛 ${esc(e.plate||'-')}${e.phone?` · ${esc(e.phone)}`:''}</div>
          </div>
          <div style="text-align:right;flex-shrink:0;">
            <div style="display:inline-block;background:#ECFDF5;color:#065F46;border-radius:999px;padding:3px 8px;font-size:10.5px;font-weight:800;">${isDone?'สแตนบาย':'รอขึ้นงาน'}</div>
            <div style="font-size:10px;color:#888;margin-top:3px;">${timeVal?fmt(timeVal):'ไม่ระบุเวลา'}</div>
          </div>
        </div>`;
      }).join('')}
    </div>
    <div style="font-size:10.5px;color:#94A3B8;margin-top:8px;">ⓘ ข้อมูลจะอัปเดตตามรายการพนักงานล่าสุด</div>
  </div>`;
}

// ── พิกัด (lat,lon) ของศาลากลางแต่ละจังหวัด — ใช้ดึงสภาพอากาศจาก Open-Meteo (ฟรี ไม่ต้องใช้ API key) ──
const PROVINCE_COORDS={
  "กรุงเทพมหานคร":[13.7563,100.5018],"กระบี่":[8.0863,98.9063],"กาญจนบุรี":[14.0228,99.5328],
  "กาฬสินธุ์":[16.4322,103.5060],"กำแพงเพชร":[16.4827,99.5226],"ขอนแก่น":[16.4322,102.8236],
  "จันทบุรี":[12.6113,102.1038],"ฉะเชิงเทรา":[13.6904,101.0779],"ชลบุรี":[13.3611,100.9847],
  "ชัยนาท":[15.1851,100.1251],"ชัยภูมิ":[15.8068,102.0317],"ชุมพร":[10.4930,99.1800],
  "เชียงราย":[19.9105,99.8406],"เชียงใหม่":[18.7883,98.9853],"ตรัง":[7.5645,99.6238],
  "ตราด":[12.2428,102.5178],"ตาก":[16.8839,99.1258],"นครนายก":[14.2069,101.2130],
  "นครปฐม":[13.8199,100.0623],"นครพนม":[17.4097,104.7791],"นครราชสีมา":[14.9799,102.0978],
  "นครศรีธรรมราช":[8.4304,99.9631],"นครสวรรค์":[15.7030,100.1370],"นนทบุรี":[13.8622,100.5144],
  "นราธิวาส":[6.4264,101.8230],"น่าน":[18.7756,100.7730],"บึงกาฬ":[18.3609,103.6466],
  "บุรีรัมย์":[14.9930,103.1029],"ปทุมธานี":[14.0208,100.5251],"ประจวบคีรีขันธ์":[11.8126,99.7957],
  "ปราจีนบุรี":[14.0508,101.3724],"ปัตตานี":[6.8693,101.2500],"พระนครศรีอยุธยา":[14.3532,100.5689],
  "พะเยา":[19.1664,99.8985],"พังงา":[8.4510,98.5298],"พัทลุง":[7.6166,100.0742],
  "พิจิตร":[16.4421,100.3487],"พิษณุโลก":[16.8211,100.2659],"เพชรบุรี":[13.1119,99.9398],
  "เพชรบูรณ์":[16.4189,101.1591],"แพร่":[18.1445,100.1405],"ภูเก็ต":[7.8804,98.3923],
  "มหาสารคาม":[16.1850,103.3000],"มุกดาหาร":[16.5450,104.7242],"แม่ฮ่องสอน":[19.3020,97.9654],
  "ยโสธร":[15.7929,104.1450],"ยะลา":[6.5413,101.2803],"ร้อยเอ็ด":[16.0538,103.6520],
  "ระนอง":[9.9528,98.6084],"ระยอง":[12.6814,101.2816],"ราชบุรี":[13.5282,99.8134],
  "ลพบุรี":[14.7995,100.6534],"ลำปาง":[18.2888,99.4900],"ลำพูน":[18.5744,99.0087],
  "เลย":[17.4860,101.7223],"ศรีสะเกษ":[15.1186,104.3220],"สกลนคร":[17.1545,104.1348],
  "สงขลา":[7.1898,100.5950],"สตูล":[6.6238,100.0674],"สมุทรปราการ":[13.5990,100.5998],
  "สมุทรสงคราม":[13.4096,100.0023],"สมุทรสาคร":[13.5475,100.2745],"สระแก้ว":[13.8240,102.0645],
  "สระบุรี":[14.5289,100.9100],"สิงห์บุรี":[14.8907,100.3968],"สุโขทัย":[17.0061,99.8265],
  "สุพรรณบุรี":[14.4744,100.1177],"สุราษฎร์ธานี":[9.1382,99.3215],"สุรินทร์":[14.8819,103.4936],
  "หนองคาย":[17.8783,102.7420],"หนองบัวลำภู":[17.2046,102.4262],"อ่างทอง":[14.5896,100.4549],
  "อำนาจเจริญ":[15.8656,104.6259],"อุดรธานี":[17.4138,102.7870],"อุตรดิตถ์":[17.6201,100.0993],
  "อุทัยธานี":[15.3835,100.0246],"อุบลราชธานี":[15.2287,104.8580]
};

// แปลง WMO weather code (มาตรฐานที่ Open-Meteo ใช้) เป็นไอคอน+คำอธิบายภาษาไทย
function weatherIconInfo(code){
  if(code===0)return{icon:'☀️',label:'ท้องฟ้าโปร่ง'};
  if(code===1)return{icon:'🌤️',label:'แจ่มใสเป็นส่วนใหญ่'};
  if(code===2)return{icon:'⛅',label:'มีเมฆบางส่วน'};
  if(code===3)return{icon:'☁️',label:'เมฆมาก'};
  if(code===45||code===48)return{icon:'🌫️',label:'หมอก'};
  if([51,53,55,56,57].includes(code))return{icon:'🌦️',label:'ฝนปรอยๆ'};
  if([61,63,65,66,67].includes(code))return{icon:'🌧️',label:'ฝนตก'};
  if([71,73,75,77].includes(code))return{icon:'❄️',label:'หิมะตก'};
  if([80,81,82].includes(code))return{icon:'🌧️',label:'ฝนตกเป็นช่วง'};
  if([85,86].includes(code))return{icon:'🌨️',label:'หิมะตกเป็นช่วง'};
  if([95,96,99].includes(code))return{icon:'⛈️',label:'พายุฝนฟ้าคะนอง'};
  return{icon:'🌡️',label:''};
}

// ── ดึงสภาพอากาศ (Open-Meteo — ฟรี ไม่ต้องสมัคร key) พร้อมแคชไว้ 30 นาที กันยิง API ถี่เกินไป ──
const _weatherCache={};
const WEATHER_CACHE_MIN=30;
function getWeather(province,cb){
  const c=_weatherCache[province];
  if(c&&(Date.now()-c.fetchedAt)<WEATHER_CACHE_MIN*60*1000){cb(c);return;}
  const coord=PROVINCE_COORDS[province];
  if(!coord){cb(null);return;}
  const url=`https://api.open-meteo.com/v1/forecast?latitude=${coord[0]}&longitude=${coord[1]}&current=temperature_2m,weather_code&daily=precipitation_probability_max&timezone=Asia%2FBangkok&forecast_days=1`;
  fetch(url).then(r=>r.json()).then(d=>{
    const data={
      temp:Math.round(d.current?.temperature_2m),
      code:d.current?.weather_code,
      rainProb:d.daily?.precipitation_probability_max?.[0],
      fetchedAt:Date.now()
    };
    _weatherCache[province]=data;
    cb(data);
  }).catch(e=>{console.warn('weather fetch error',e);cb(null);});
}
// อัพเดทเนื้อหาวิดเจ็ตอากาศในการ์ดของพนักงาน (เรียกแบบ async แยกจากการ render การ์ดหลัก กันหน้าจอกระตุกตอนรอโหลด)
function updateWeatherWidget(province){
  getWeather(province,data=>{
    const el=document.getElementById('weatherWidget');
    if(!el)return; // การ์ดอาจถูก re-render ทับไปแล้วระหว่างรอข้อมูล
    if(!data||data.temp===undefined||isNaN(data.temp)){el.style.display='none';return;}
    const wi=weatherIconInfo(data.code);
    const rp=(data.rainProb!==undefined&&data.rainProb!==null)?`โอกาสฝนตก ${data.rainProb}% · `:'';
    el.innerHTML=`
      <span style="font-size:20px;">${wi.icon}</span>
      <div style="flex:1;">
        <div style="font-size:13px;font-weight:800;color:#1a1a2e;">อากาศที่${esc(province)} — ${data.temp}°C</div>
        <div style="font-size:11px;color:#888;">${rp}${esc(wi.label)}</div>
      </div>`;
  });
}

function getFullLabel(e){
  let label='';
  if(e.status==='standby'&&e.province) label=`สแตนบาย — ${e.province}`;
  else if(e.status==='traveling'&&e.province) label=`ออกเดินทาง → ${e.province}`;
  else if(e.status==='returning'&&e.province) label=`กำลังไหลกลับ → ${e.province}`;
  else if(e.status==='done'&&e.province) label=`สแตนบายว่างงาน — ${e.province}`;
  else label=getS(e.status).label;

  // ถ้าพนักงานกำลังลา ให้แสดงในหน้าสถานะปกติด้วย
  if(isLeaveActiveToday(e)) label += ' (🌴 ลาอยู่วันนี้)';
  return label;
}
// ── ไอคอนป้ายเล็กมุมรูปประจำตัว บอกว่า "กำลังลา" — สีจะเปลี่ยนตามสถานะอนุมัติ ──
// 🟡 รออนุมัติ  🟢 อนุมัติแล้ว  🔴 ไม่อนุมัติ (แต่ยังลาอยู่ในระบบ)
function leaveIcon(e){
  // ไอคอนลาในหน้าสถานะปกติให้ขึ้นเฉพาะรายการที่อนุมัติแล้ว
  if(!e.onLeave||e.leaveApproval!=='approved')return'';
  const border='#6EE7B7';
  const title='ลา (อนุมัติแล้ว)';
  return`<span class="leave-badge" style="border-color:${border};" title="${title}">${skeIcon('leave')}</span>`;
}

// ── Helpers: escape user text + clickable phone ──────────────────────────────
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
// คืน HTML เบอร์โทรที่กดโทรออกได้ทันที (พร้อมตัวคั่น • ด้านหน้า)
function phoneLink(phone){
  if(!phone)return'';
  const tel=String(phone).replace(/[^\d+]/g,'');
  if(!tel)return'';
  return ` • <a href="tel:${tel}" onclick="event.stopPropagation()" style="color:#1E90D6;font-weight:600;text-decoration:none;white-space:nowrap;">📞 ${esc(phone)}</a>`;
}
// เปิดแชท LINE ของพนักงานคนนั้นโดยตรง (ต้องมี LINE ID บันทึกไว้ในโปรไฟล์)
// หมายเหตุ: LINE ไม่รองรับลิงก์ที่ "โทรออกอัตโนมัติ" ได้ — กดแล้วจะพาไปเปิดหน้าแชทกับคนนั้นให้ก่อน
// ผู้ใช้ต้องกดปุ่มโทรในหน้าแชทเองอีกที (เป็นข้อจำกัดของ LINE เอง ไม่ใช่บั๊ก)
function lineLink(lineId){
  if(!lineId)return'';
  const lid=String(lineId).trim().replace(/^@/,'').replace(/[^\w.\-]/g,'');
  if(!lid)return'';
  return ` • <a href="https://line.me/ti/p/~${encodeURIComponent(lid)}" target="_blank" onclick="event.stopPropagation()" style="color:#06C755;font-weight:600;text-decoration:none;white-space:nowrap;">💬 LINE ด่วน</a>`;
}

const SKE_APP_VERSION='v2026.07.24-connection-v3.1-rollback';

// ══ เช็คเวอร์ชันใหม่อัตโนมัติ — ไม่ต้องมีไฟล์ version.json แยก ไม่ต้องจำอัปเดตคู่กันทุกครั้ง ══
// ปัญหาที่แก้: พนักงานเปิดแอปค้างไว้นานๆ (ทั้งวัน/หลายวัน) โค้ดที่รันอยู่ในเครื่องจะเป็นเวอร์ชันเดิมตลอด
// ไม่มีทางรู้เองว่ามีเวอร์ชันใหม่ที่แก้บั๊กไปแล้ว จนกว่าจะปิดแอปแล้วเปิดใหม่ — ทำให้ยังเจอบั๊กเดิมซ้ำอยู่เรื่อยๆ ทั้งที่แก้ไปแล้ว
// วิธีแก้: ยิง HEAD request ไปที่หน้าเว็บตัวเอง (ไม่โหลดเนื้อไฟล์ทั้งหมด แค่ขอ "header" เบามาก) แล้วอ่านค่า ETag/Last-Modified
// ที่ GitHub Pages สร้างให้อัตโนมัติทุกครั้งที่มีการอัปโหลดไฟล์ใหม่ (ไม่ต้องมีใครมาพิมพ์เลขเวอร์ชันเอง) — ถ้าค่าที่ได้ไม่ตรงกับตอนเปิดแอปครั้งแรก
// แปลว่าไฟล์บนเซิร์ฟเวอร์ถูกอัปเดตไปแล้ว จึงโชว์แบนเนอร์เตือน — อัปแค่ index.html ไฟล์เดียวตลอดไปได้เลย ไม่ต้องมีไฟล์คู่กันอีก
let _skeUpdateBannerShown=false;
let _skeVersionBaseline=null;
async function _getSkeAssetTag(){
  try{
    const res=await fetch(location.pathname||'./',{method:'HEAD',cache:'no-store'});
    return res.headers.get('etag')||res.headers.get('last-modified')||null;
  }catch(e){return null;} // เน็ตหลุด/เช็คไม่ได้ — เงียบไว้ ไม่รบกวนผู้ใช้ ลองใหม่รอบถัดไป
}
async function _checkSkeVersion(){
  if(_skeUpdateBannerShown)return; // เตือนไปแล้วไม่ต้องเช็คซ้ำ รอผู้ใช้กดเองก่อน
  const tag=await _getSkeAssetTag();
  if(!tag)return;
  if(_skeVersionBaseline===null){ _skeVersionBaseline=tag; return; } // เช็คครั้งแรก — แค่บันทึกไว้เป็นค่าตั้งต้นของเซสชันนี้
  if(tag!==_skeVersionBaseline){
    _skeUpdateBannerShown=true;
    _showSkeUpdateBanner();
  }
}
function _showSkeUpdateBanner(){
  if(document.getElementById('skeUpdateBanner'))return;

  // กล่องอัปเดตแบบกลางจอ — อ่านง่าย กดสะดวก และไม่ชิดขอบล่างของโทรศัพท์
  if(!document.getElementById('skeUpdateModalStyle')){
    const style=document.createElement('style');
    style.id='skeUpdateModalStyle';
    style.textContent=`
      @keyframes skeUpdateFadeIn{from{opacity:0}to{opacity:1}}
      @keyframes skeUpdatePopIn{0%{opacity:0;transform:translateY(22px) scale(.9)}70%{transform:translateY(-3px) scale(1.015)}100%{opacity:1;transform:translateY(0) scale(1)}}
      @keyframes skeUpdateOrbit{to{transform:rotate(360deg)}}
      @keyframes skeUpdateGlow{0%,100%{box-shadow:0 12px 26px rgba(91,33,182,.28)}50%{box-shadow:0 16px 34px rgba(37,99,235,.42)}}
      #skeUpdateBanner{position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center;padding:24px max(18px,env(safe-area-inset-right)) max(24px,env(safe-area-inset-bottom)) max(18px,env(safe-area-inset-left));background:rgba(15,23,42,.58);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);animation:skeUpdateFadeIn .25s ease-out}
      #skeUpdateBanner .ske-update-card{position:relative;width:min(100%,360px);overflow:hidden;border:1px solid rgba(255,255,255,.82);border-radius:28px;background:linear-gradient(155deg,rgba(255,255,255,.99),rgba(248,250,255,.97));box-shadow:0 28px 80px rgba(15,23,42,.38);padding:30px 24px 24px;text-align:center;animation:skeUpdatePopIn .48s cubic-bezier(.2,.85,.25,1.1)}
      #skeUpdateBanner .ske-update-card:before{content:'';position:absolute;width:190px;height:190px;border-radius:50%;top:-115px;right:-70px;background:radial-gradient(circle,#60A5FA 0%,#8B5CF6 48%,transparent 70%);opacity:.24;pointer-events:none}
      #skeUpdateBanner .ske-update-card:after{content:'';position:absolute;width:150px;height:150px;border-radius:50%;bottom:-105px;left:-70px;background:radial-gradient(circle,#F472B6 0%,#F59E0B 48%,transparent 70%);opacity:.18;pointer-events:none}
      #skeUpdateBanner .ske-update-icon-wrap{position:relative;width:82px;height:82px;margin:0 auto 18px;display:grid;place-items:center}
      #skeUpdateBanner .ske-update-orbit{position:absolute;inset:0;border-radius:50%;border:3px solid transparent;border-top-color:#7C3AED;border-right-color:#2563EB;border-bottom-color:#EC4899;animation:skeUpdateOrbit 1.8s linear infinite}
      #skeUpdateBanner .ske-update-icon{width:62px;height:62px;border-radius:20px;display:grid;place-items:center;background:linear-gradient(135deg,#7C3AED,#2563EB 58%,#06B6D4);color:#fff;font-size:29px;box-shadow:0 13px 28px rgba(79,70,229,.34);transform:rotate(-3deg)}
      #skeUpdateBanner .ske-update-badge{display:inline-flex;align-items:center;gap:6px;padding:6px 11px;border-radius:999px;background:#EEF2FF;color:#5B21B6;font-size:11px;font-weight:900;letter-spacing:.2px;margin-bottom:10px}
      #skeUpdateBanner .ske-update-title{position:relative;color:#0F172A;font-size:21px;font-weight:950;line-height:1.25;margin:0 0 8px}
      #skeUpdateBanner .ske-update-sub{position:relative;color:#64748B;font-size:13px;font-weight:600;line-height:1.65;margin:0 auto 20px;max-width:285px}
      #skeUpdateBanner .ske-update-points{position:relative;display:flex;justify-content:center;gap:7px;margin:-4px 0 20px}
      #skeUpdateBanner .ske-update-points span{width:7px;height:7px;border-radius:50%;background:#CBD5E1}
      #skeUpdateBanner .ske-update-points span:nth-child(1){background:#8B5CF6}#skeUpdateBanner .ske-update-points span:nth-child(2){background:#3B82F6}#skeUpdateBanner .ske-update-points span:nth-child(3){background:#EC4899}
      #skeUpdateBanner .ske-update-btn{position:relative;width:100%;border:0;border-radius:16px;padding:14px 18px;background:linear-gradient(100deg,#7C3AED,#2563EB 58%,#0891B2);color:#fff;font-size:14px;font-weight:950;letter-spacing:.1px;cursor:pointer;animation:skeUpdateGlow 2.4s ease-in-out infinite;transition:transform .15s ease,filter .15s ease}
      #skeUpdateBanner .ske-update-btn:active{transform:scale(.97);filter:brightness(.96)}
      #skeUpdateBanner .ske-update-note{position:relative;margin-top:12px;color:#94A3B8;font-size:10.5px;font-weight:650}
    `;
    document.head.appendChild(style);
  }

  const modal=document.createElement('div');
  modal.id='skeUpdateBanner';
  modal.setAttribute('role','dialog');
  modal.setAttribute('aria-modal','true');
  modal.setAttribute('aria-label','มีแอปเวอร์ชันใหม่พร้อมใช้งาน');
  modal.innerHTML=`
    <div class="ske-update-card">
      <div class="ske-update-icon-wrap">
        <div class="ske-update-orbit"></div>
        <div class="ske-update-icon">↻</div>
      </div>
      <div class="ske-update-badge">✨ UPDATE AVAILABLE</div>
      <h2 class="ske-update-title">มีเวอร์ชันใหม่แล้ว</h2>
      <p class="ske-update-sub">อัปเดตเพื่อรับการแก้ไขล่าสุด<br>และใช้งานแอปได้ลื่นไหลยิ่งขึ้น</p>
      <div class="ske-update-points"><span></span><span></span><span></span></div>
      <button class="ske-update-btn" onclick="this.disabled=true;this.textContent='กำลังอัปเดต...';location.reload()">อัปเดตแอปตอนนี้</button>
      <div class="ske-update-note">ใช้เวลาเพียงครู่เดียว • ข้อมูลไม่สูญหาย</div>
    </div>`;
  document.body.appendChild(modal);
  setTimeout(()=>modal.querySelector('.ske-update-btn')?.focus(),350);
}
// ตั้งค่าตั้งต้นทันทีตอนเปิดแอป (รอ 8 วิให้แอปโหลดเสร็จก่อน กันแย่งเน็ตตอนเริ่มต้น) + เช็คซ้ำทุก 5 นาทีที่เปิดแอปค้างไว้
setTimeout(_checkSkeVersion,8000);
setInterval(_checkSkeVersion,5*60*1000);
// เช็คทันทีทุกครั้งที่สลับกลับมาที่แอป (เช่น สลับแอปอื่นแล้วกลับมา) — จังหวะที่เจอเวอร์ชันใหม่ได้บ่อยที่สุด
document.addEventListener('visibilitychange',()=>{ if(document.visibilityState==='visible')_checkSkeVersion(); });
// ตัวเขียน cache ปลอดภัย — ใช้ตัวจริงจาก module (ตัดรูปอัตโนมัติเมื่อพื้นที่เต็ม) ถ้ายังโหลดไม่เสร็จใช้ fallback ที่ไม่ throw
function _cacheSet(key,value){
  if(window._skeCacheSet)return window._skeCacheSet(key,value);
  try{localStorage.setItem(key,JSON.stringify(value));return true;}
  catch(e){console.error('[SKE] พื้นที่เก็บในเครื่องเต็ม:',key);return false;}
}

// อัพเดทข้อมูลพนักงานรายคนขึ้น Firebase แบบกันพลาด:
// 1) พยายามแพตช์เฉพาะฟิลด์ก่อน (เบา เร็ว ไม่แตะข้อมูลคนอื่น)
// 2) ถ้าล้มเหลวค่อย fallback ส่งทั้งก้อน — แต่ต้อง "ใส่ patch กลับเข้าไปใหม่ก่อนส่งเสมอ"
//    เพราะกว่าจะถึงตอน fallback ตัวแปร employees อาจถูก realtime ทับด้วยข้อมูลเก่า (ที่ยังไม่มีสถานะใหม่) ไปแล้ว
//    ถ้าส่งทั้งก้อนโดยไม่ใส่ patch กลับ = สถานะที่พนักงานเพิ่งกดยืนยันจะหายถาวร (บั๊ก "สถานะเด้งกลับ")
function fbPatchEmployee(empId,patch){
  const reapply=()=>{employees=(employees||[]).map(e=>e&&e.id===empId?{...e,...patch}:e);_cacheSet('ske_emp',employees);};
  if(window.fbUpdateEmployeeFields){
    return window.fbUpdateEmployeeFields(empId,patch).catch(()=>{reapply();if(window.fbSaveEmployees)return window.fbSaveEmployees(employees);});
  }
  if(window.fbSaveEmployees){reapply();return window.fbSaveEmployees(employees);}
  return Promise.resolve();
}

// ══ คลังรูปฝั่งแอป ══
// รูปทุกใบอ้างอิงด้วยรหัส (ph_...) — โหลดจริงเฉพาะตอนต้องแสดง แล้ว cache ในเครื่องถาวร (รหัสรูปไม่มีวันเปลี่ยน)
// รองรับรูปยุคเก่าที่ยังฝัง base64 มากับข้อมูล (ขึ้นต้น data:) ให้แสดงได้ตามปกติระหว่างที่ยังไม่ได้กดย้ายเข้าคลัง
const _photoMem=new Map();
function _newPhotoId(){return 'ph_'+Date.now()+'_'+Math.random().toString(36).slice(2,8);}
function resolvePhoto(v){
  if(!v)return Promise.resolve(null);
  v=String(v);
  if(v.startsWith('data:'))return Promise.resolve(v);
  if(_photoMem.has(v))return Promise.resolve(_photoMem.get(v));
  try{const c=localStorage.getItem('ske_ph_'+v);if(c){_photoMem.set(v,c);return Promise.resolve(c);}}catch(e){}
  if(!window.fbGetPhotoRemote)return Promise.resolve(null);
  return window.fbGetPhotoRemote(v).then(d=>{
    if(d){_photoMem.set(v,d);try{localStorage.setItem('ske_ph_'+v,d);}catch(e){/* พื้นที่เต็มก็แค่ไม่ cache โหลดใหม่ครั้งหน้า */}}
    return d;
  }).catch(()=>null);
}
async function uploadPhoto(dataUrl){
  const id=_newPhotoId();
  if(window.fbSavePhoto)await window.fbSavePhoto(id,dataUrl);
  _photoMem.set(id,dataUrl);
  try{localStorage.setItem('ske_ph_'+id,dataUrl);}catch(e){}
  return id;
}
const _PH_PLACEHOLDER='data:image/svg+xml;utf8,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="72" height="72"><rect width="100%" height="100%" fill="#EEF1F6"/><text x="50%" y="56%" font-size="24" text-anchor="middle">🖼️</text></svg>');
function _hydratePhotoEl(el){
  const v=el.getAttribute('data-ph');
  if(!v||el.getAttribute('data-ph-done'))return;
  el.setAttribute('data-ph-done','1');
  if(v.startsWith('data:')){el.src=v;return;}
  el.src=_PH_PLACEHOLDER;
  resolvePhoto(v).then(d=>{if(d)el.src=d;});
}
// เฝ้าดู DOM — ทุกครั้งที่มี <img data-ph="..."> ถูกวาดขึ้นจอ ให้ไปโหลดรูปมาใส่เองอัตโนมัติ
// (จุด render ทั้ง 19 จุดในแอปไม่ต้องรู้จักระบบโหลดรูปเลย แค่ใส่ data-ph แทน src ก็พอ)
new MutationObserver(muts=>{
  muts.forEach(m=>{if(!m.addedNodes)return;m.addedNodes.forEach(n=>{
    if(n.nodeType!==1)return;
    if(n.matches&&n.matches('img[data-ph]'))_hydratePhotoEl(n);
    if(n.querySelectorAll)n.querySelectorAll('img[data-ph]').forEach(_hydratePhotoEl);
  });});
}).observe(document.documentElement,{childList:true,subtree:true});

// อัพโหลดรูปเป็นชุด (คืนรหัสรูปตามลำดับ) — ใช้ตอนแจ้งซ่อม/ของเหลวที่แนบหลายรูป
async function uploadPhotos(dataUrls){
  const ids=[];
  for(const d of (dataUrls||[])){
    // รายการที่เป็นรหัสอยู่แล้ว (เช่นกดเพิ่มรูปซ้ำ) ไม่ต้องอัพซ้ำ
    ids.push(String(d).startsWith('data:')?await uploadPhoto(d):d);
  }
  return ids;
}

const _DEFAULT_EMP=[{"id": "emp001", "name": "นพการณ์ ขันทะ", "plate": "", "phone": "", "pin": "1111", "status": "standby", "province": "", "note": "", "updatedAt": null, "standbyAt": null}, {"id": "emp002", "name": "อภิวัฒน์ กำทอง", "plate": "", "phone": "", "pin": "2222", "status": "standby", "province": "", "note": "", "updatedAt": null, "standbyAt": null}, {"id": "emp003", "name": "ราม สุขจิตเกษม", "plate": "731744", "phone": "", "pin": "3333", "status": "standby", "province": "", "note": "", "updatedAt": null, "standbyAt": null}, {"id": "emp004", "name": "ธีรนัย หมัดเด", "plate": "", "phone": "", "pin": "4444", "status": "standby", "province": "", "note": "", "updatedAt": null, "standbyAt": null}, {"id": "emp005", "name": "อรรคพล มีแก้ว", "plate": "73-4296", "phone": "", "pin": "5555", "status": "standby", "province": "", "note": "", "updatedAt": null, "standbyAt": null}, {"id": "emp006", "name": "วิชญาดา งามจันทร์", "plate": "", "phone": "", "pin": "6666", "status": "standby", "province": "", "note": "", "updatedAt": null, "standbyAt": null}, {"id": "emp007", "name": "นิรุช ศรีภาชน์", "plate": "", "phone": "", "pin": "7777", "status": "standby", "province": "", "note": "", "updatedAt": null, "standbyAt": null}, {"id": "emp008", "name": "ณัฎฐกฤต รักสุข", "plate": "73-1856", "phone": "", "pin": "8888", "status": "standby", "province": "", "note": "", "updatedAt": null, "standbyAt": null}, {"id": "emp009", "name": "กฤษฎิ์ ชมชื่น", "plate": "73-4397", "phone": "", "pin": "9999", "status": "standby", "province": "", "note": "", "updatedAt": null, "standbyAt": null}, {"id": "emp010", "name": "เจริญ ตั้งเสถียร", "plate": "73-4397", "phone": "", "pin": "1010", "status": "standby", "province": "", "note": "", "updatedAt": null, "standbyAt": null}, {"id": "emp011", "name": "สำราญ สิงห์โต", "plate": "73-1854", "phone": "", "pin": "1112", "status": "standby", "province": "", "note": "", "updatedAt": null, "standbyAt": null}, {"id": "emp012", "name": "ศราวุฒิ เมืองสอน", "plate": "73-4253", "phone": "", "pin": "1212", "status": "standby", "province": "", "note": "", "updatedAt": null, "standbyAt": null}, {"id": "emp013", "name": "กอบชัย เสนาวัลย์", "plate": "73-1861", "phone": "", "pin": "1313", "status": "standby", "province": "", "note": "", "updatedAt": null, "standbyAt": null}, {"id": "emp014", "name": "อนุรักษ์ เสยกระโทก", "plate": "73-1896", "phone": "", "pin": "1414", "status": "standby", "province": "", "note": "", "updatedAt": null, "standbyAt": null}, {"id": "emp015", "name": "สิทธิโชค สระเสือ", "plate": "73-6521", "phone": "", "pin": "1515", "status": "standby", "province": "", "note": "", "updatedAt": null, "standbyAt": null}, {"id": "emp016", "name": "วันชัย จันทร์คง", "plate": "73-1853", "phone": "", "pin": "1616", "status": "standby", "province": "", "note": "", "updatedAt": null, "standbyAt": null}, {"id": "emp017", "name": "รัชชานนท์ กริบกระโทก", "plate": "73-1883", "phone": "", "pin": "1717", "status": "standby", "province": "", "note": "", "updatedAt": null, "standbyAt": null}];
let employees=(()=>{
  const stored=JSON.parse(localStorage.getItem('ske_emp')||'[]');
  // ใช้ข้อมูลที่บันทึกไว้เสมอถ้ามี — ใช้ default เฉพาะตอนเครื่องใหม่ที่ยังไม่เคยมีข้อมูลเลย (รอ Firebase ซิงค์ข้อมูลจริงมาแทนภายในไม่กี่วินาที)
  if(!Array.isArray(stored)||stored.length===0) return _DEFAULT_EMP.map(e=>e);
  return stored;
})();
// ── รถ (vehicles) — เอนทิตี้แยกจากพนักงานเด็ดขาด: เพิ่ม/ลบ/แก้ไขทะเบียนรถได้เองจากหน้า "จัดการรถ"
// ไม่ผูกกับคนขับอีกต่อไป — "รถทั้งหมด" นับจาก vehicles.length ตรงๆ ไม่ต้องเดาจากทะเบียนที่กรอกไว้ในโปรไฟล์พนักงาน
// ตอนสร้างครั้งแรก (เครื่องที่ยังไม่เคยมีข้อมูลรถเลย) จะดึงทะเบียนที่ไม่ซ้ำจากพนักงานเดิมมาตั้งต้นให้อัตโนมัติ กันข้อมูลรถหายไปเฉยๆ
let vehicles=(()=>{
  const stored=JSON.parse(localStorage.getItem('ske_vehicles')||'[]');
  if(Array.isArray(stored)&&stored.length>0)return stored;
  const seen=new Set();
  const seeded=[];
  employees.forEach(e=>{
    const p=(e.plate||'').trim();
    if(!p||seen.has(p))return;
    seen.add(p);
    seeded.push({id:'veh_'+Date.now()+'_'+seeded.length,plate:p,type:'',note:'',active:true,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()});
  });
  return seeded;
})();
function saveV(){
  localStorage.setItem('ske_vehicles',JSON.stringify(vehicles));
  if(window.fbSaveVehicles) window.fbSaveVehicles(vehicles);
}
let currentUser=JSON.parse(localStorage.getItem('ske_user')||'null');
// ── ระบบรหัสผ่านหลังบ้าน (เข้ารหัส SHA-256 ก่อนเก็บ/ส่งขึ้น Firebase เสมอ ไม่เก็บ/ส่ง plain text อีกต่อไป) ──
const SKE_DEFAULT_ADMIN_PW='admin1234', SKE_DEFAULT_VIEWER_PW='view1234', SKE_DEFAULT_PIN2='135790', SKE_DEFAULT_EMERGENCY_CODE='SKE-RESET-2025';
async function sha256Hex(str){
  const buf=await crypto.subtle.digest('SHA-256', new TextEncoder().encode(String(str)));
  return Array.from(new Uint8Array(buf)).map(b=>b.toString(16).padStart(2,'0')).join('');
}
let adminPwHash=localStorage.getItem('ske_pwHash')||null;
let viewerPwHash=localStorage.getItem('ske_viewerPwHash')||null;
let adminPin2Hash=localStorage.getItem('ske_pin2Hash')||null;
let emergencyCodeHash=localStorage.getItem('ske_emergHash')||null;
// ถ้าเครื่องนี้ยังไม่เคยมี hash เลย (ติดตั้งใหม่/ยังไม่เคยล็อกอิน) ให้คำนวณ hash ของค่าเริ่มต้นไว้ก่อน เผื่อใช้เทียบตอน login ครั้งแรก
(async()=>{
  if(!adminPwHash)adminPwHash=await sha256Hex(SKE_DEFAULT_ADMIN_PW);
  if(!viewerPwHash)viewerPwHash=await sha256Hex(SKE_DEFAULT_VIEWER_PW);
  if(!adminPin2Hash)adminPin2Hash=await sha256Hex(SKE_DEFAULT_PIN2);
  if(!emergencyCodeHash)emergencyCodeHash=await sha256Hex(SKE_DEFAULT_EMERGENCY_CODE);
})();
let adminMode=false,editOpen=false,leaveFormOpen=false;
// บทบาทผู้เข้าระบบฝั่งหลังบ้าน: 'super' = ผู้ดูแล (สิทธิ์เต็ม), 'viewer' = แอดมิน (ดูเฉพาะแผนผังงาน)
let adminRole=localStorage.getItem('ske_adminRole')||null;
let _selStatus='standby',_selProv='';
let _selLeaveAt='',_selLeaveTo='',_selLeaveNote='';
let deferredPrompt=null;
let repairs=(()=>{try{const s=JSON.parse(localStorage.getItem('ske_repairs')||'[]');return Array.isArray(s)?s:[];}catch(e){return[];}})();
let fluidLogs=(()=>{try{const s=JSON.parse(localStorage.getItem('ske_fluid')||'[]');return Array.isArray(s)?s:[];}catch(e){return[];}})();
let cashRequests=(()=>{try{const s=JSON.parse(localStorage.getItem('ske_cash')||'[]');return Array.isArray(s)?s:[];}catch(e){return[];}})();
let leaveLogs=(()=>{try{const s=JSON.parse(localStorage.getItem('ske_leaveLogs')||'[]');return Array.isArray(s)?s:[];}catch(e){return[];}})();
// ประวัติเที่ยววิ่งงาน — บันทึกถาวรทุกครั้งที่มีเที่ยวใหม่ (ไม่ขึ้นกับสถานะปัจจุบันของพนักงานอีกต่อไป)
let runLogs=(()=>{try{const s=JSON.parse(localStorage.getItem('ske_runlogs')||'[]');return Array.isArray(s)?s:[];}catch(e){return[];}})();
let monthlyDocs=(()=>{try{const s=JSON.parse(localStorage.getItem('ske_monthly_docs')||'[]');return Array.isArray(s)?s:[];}catch(e){return[];}})();
let jobPlanRows=(()=>{try{const s=JSON.parse(localStorage.getItem('ske_jobplan')||'[]');return Array.isArray(s)?s:[];}catch(e){return[];}})();
let jobRouteTemplates=(()=>{try{const s=JSON.parse(localStorage.getItem('ske_jobtemplates')||'[]');return Array.isArray(s)?s:[];}catch(e){return[];}})();
let companyFeedbacks=(()=>{try{const s=JSON.parse(localStorage.getItem('ske_feedbacks')||'[]');return Array.isArray(s)?s:[];}catch(e){return[];}})();
let _repUrgency='normal';
let _repNewPhotos=[]; // รูปที่พนักงานเลือกไว้ก่อนกดส่งแจ้งซ่อม (ย่อแล้ว)
let _fluNewPhotos=[]; // รูปที่พนักงานเลือกไว้ก่อนบันทึกการเปลี่ยนถ่ายของเหลว (ย่อแล้ว)

function saveE(){
  _cacheSet('ske_emp', employees);
  if(window.fbSaveEmployees) window.fbSaveEmployees(employees);
}
function saveU(){localStorage.setItem('ske_user',JSON.stringify(currentUser));}
// ตั้งรหัสผ่าน/PIN ใหม่ — รับค่าที่พิมพ์เข้ามาแบบข้อความปกติ แล้วเข้ารหัสก่อนเก็บ/ส่งขึ้น Firebase เสมอ (ไม่มีการเก็บ/ส่ง plain text อีกต่อไป)
async function setAdminPw(plainPw){
  adminPwHash=await sha256Hex(plainPw);
  localStorage.setItem('ske_pwHash',adminPwHash);
  if(window.fbSaveAdminPwHash) window.fbSaveAdminPwHash(adminPwHash);
}
async function setViewerPw(plainPw){
  viewerPwHash=await sha256Hex(plainPw);
  localStorage.setItem('ske_viewerPwHash',viewerPwHash);
  if(window.fbSaveViewerPwHash) window.fbSaveViewerPwHash(viewerPwHash);
}
async function setAdminPin2(plainPin){
  adminPin2Hash=await sha256Hex(plainPin);
  localStorage.setItem('ske_pin2Hash',adminPin2Hash);
  if(window.fbSaveAdminPin2Hash) window.fbSaveAdminPin2Hash(adminPin2Hash);
}
async function setEmergencyCode(plainCode){
  emergencyCodeHash=await sha256Hex(plainCode);
  localStorage.setItem('ske_emergHash',emergencyCodeHash);
  if(window.fbSaveEmergencyCodeHash) window.fbSaveEmergencyCodeHash(emergencyCodeHash);
}
function saveA(){localStorage.setItem('ske_admin',adminMode?'1':'0');}
function saveAR(){if(adminRole)localStorage.setItem('ske_adminRole',adminRole);else localStorage.removeItem('ske_adminRole');}
function saveRepairs(){
  _cacheSet('ske_repairs', repairs);
  if(window.fbSaveRepairs) return window.fbSaveRepairs(repairs);
  return Promise.resolve();
}
function saveFluid(){
  _cacheSet('ske_fluid', fluidLogs);
  if(window.fbSaveFluidLogs) return window.fbSaveFluidLogs(fluidLogs);
  return Promise.resolve();
}
// แพตช์เฉพาะรายการแจ้งซ่อม/ของเหลว 1 รายการ (ไม่อัพโหลดประวัติทั้งหมดซ้ำ) — ถ้าแพตช์ล้มเหลวค่อย fallback เป็นอัพโหลดทั้งก้อน (มี outbox กันข้อมูลหายอยู่แล้ว)
// หมายเหตุ: ต้องอัพเดทตัวแปร repairs/fluidLogs ในเครื่องให้เสร็จก่อนเรียกฟังก์ชันนี้ เผื่อต้อง fallback
function _patchRepair(id,patch){
  if(window.fbUpdateRepairFields){
    return window.fbUpdateRepairFields(id,patch).catch(()=>{ if(window.fbSaveRepairs) return window.fbSaveRepairs(repairs).catch(()=>{}); });
  } else if(window.fbSaveRepairs){
    return window.fbSaveRepairs(repairs).catch(()=>{});
  }
  return Promise.resolve();
}
function _patchFluid(id,patch){
  if(window.fbUpdateFluidFields){
    return window.fbUpdateFluidFields(id,patch).catch(()=>{ if(window.fbSaveFluidLogs) return window.fbSaveFluidLogs(fluidLogs).catch(()=>{}); });
  } else if(window.fbSaveFluidLogs){
    return window.fbSaveFluidLogs(fluidLogs).catch(()=>{});
  }
  return Promise.resolve();
}
function saveCash(){
  localStorage.setItem('ske_cash',JSON.stringify(cashRequests));
  if(window.fbSaveCashRequests) window.fbSaveCashRequests(cashRequests);
}
function saveLeaveLogs(){
  localStorage.setItem('ske_leaveLogs',JSON.stringify(leaveLogs));
  if(window.fbSaveLeaveLogs) window.fbSaveLeaveLogs(leaveLogs);
}
function saveMonthlyDocs(){
  _cacheSet('ske_monthly_docs', monthlyDocs||[]);
  if(window.fbSaveMonthlyDocs) return window.fbSaveMonthlyDocs(monthlyDocs||[]);
  return Promise.resolve();
}
function saveRunLogs(){
  localStorage.setItem('ske_runlogs',JSON.stringify(runLogs));
  if(window.fbSaveRunLogs) window.fbSaveRunLogs(runLogs);
}

// ══════════════════════════════════════════════════════════════════════════
// ── เก็บประวัติซ่อมบำรุงไว้ 12 เดือน แล้วลบอัตโนมัติ ─────────────────────────
// (รายการแจ้งซ่อม ใช้วันที่แจ้ง / รายการเปลี่ยนถ่ายของเหลว ใช้วันที่เปลี่ยน) ──
// ══════════════════════════════════════════════════════════════════════════
function _maintCutoffTime(){
  const d=new Date();
  d.setMonth(d.getMonth()-12);
  return d.getTime();
}
function pruneOldMaintenance(){
  const cutoff=_maintCutoffTime();
  let changed=false;
  const newRepairs=repairs.filter(r=>{
    const t=new Date(r.createdAt||0).getTime();
    return !isFinite(t)||t>=cutoff;
  });
  if(newRepairs.length!==repairs.length){repairs=newRepairs;changed=true;saveRepairs().catch(()=>{});}
  const newFluid=fluidLogs.filter(f=>{
    const t=new Date(f.changedAt||f.createdAt||0).getTime();
    return !isFinite(t)||t>=cutoff;
  });
  if(newFluid.length!==fluidLogs.length){fluidLogs=newFluid;changed=true;saveFluid().catch(()=>{});}
  if(changed){
    const rm=document.getElementById('repairModal');if(rm&&!rm.classList.contains('hidden'))renderRepairList();
    const fm=document.getElementById('fluidModal');if(fm&&!fm.classList.contains('hidden'))renderFluidList();
    const ap=document.getElementById('adminMaintPanel');if(ap&&!ap.classList.contains('hidden'))renderAdminMaint();
    updateMaintBadges();
  }
  return changed;
}
// ตรวจสอบซ้ำทุก 1 ชั่วโมง เผื่อแอปเปิดค้างไว้นาน
setInterval(pruneOldMaintenance,60*60*1000);

// ── ลบเฉพาะรูปแนบออกจากรายการที่อายุเกิน 12 เดือน ─────────────────────────────
// รายการยังอยู่ครบ (ไม่หาย) แค่รูปโดนล้างเพื่อประหยัด Firebase DB quota
// รันครั้งเดียวตอน sync ครั้งแรก (เรียกจาก onValue repairs)
function purgeOldPhotos(){
  const cutoff=_maintCutoffTime();
  let repChanged=false,fluChanged=false;
  const purgedIds=[]; // รหัสรูปที่ถูกถอดออก — จะตามไปลบตัวรูปจริงในคลังด้วย ไม่ให้เป็นขยะค้าง

  // repairs: ลบ r.empPhotos และ r.photos ของรายการที่อายุเกิน 12 เดือน
  repairs=repairs.map(r=>{
    const t=new Date(r.createdAt||0).getTime();
    if(isFinite(t)&&t<cutoff){
      const hadPhotos=(r.empPhotos&&r.empPhotos.length)||(r.photos&&r.photos.length);
      if(hadPhotos){
        repChanged=true;
        (r.empPhotos||[]).concat(r.photos||[]).forEach(p=>purgedIds.push(p));
        return{...r,empPhotos:[],photos:[]};
      }
    }
    return r;
  });
  if(repChanged){saveRepairs().catch(()=>{});console.log('[SKE] purgeOldPhotos: ลบรูปเก่าออกจาก repairs แล้ว');}

  // fluidLogs: ลบ f.photos ของรายการที่อายุเกิน 12 เดือน
  fluidLogs=fluidLogs.map(f=>{
    const t=new Date(f.changedAt||f.createdAt||0).getTime();
    if(isFinite(t)&&t<cutoff){
      if(f.photos&&f.photos.length){
        fluChanged=true;
        (f.photos||[]).forEach(p=>purgedIds.push(p));
        return{...f,photos:[]};
      }
    }
    return f;
  });
  if(fluChanged){saveFluid().catch(()=>{});console.log('[SKE] purgeOldPhotos: ลบรูปเก่าออกจาก fluidLogs แล้ว');}
  if(purgedIds.length&&window.fbDeletePhotos)window.fbDeletePhotos(purgedIds);
}

// ── ย้ายข้อมูลเก่า: พนักงานที่เคยมี status==='leave' (ก่อนแยก "ลา" ออกจากสถานะทั่วไป) ──
// ย้ายเป็น onLeave=true + คืนสถานะการทำงานจริงเป็น standby (ค่าเริ่มต้นปลอดภัย ผู้ดูแลแก้ไขเพิ่มเติมได้)
function migrateLegacyLeaveStatus(){
  let changed=false;
  const migrated=employees.map(e=>{
    if(e.status==='leave'){
      changed=true;
      const dateOnly=e.leaveAt?new Date(e.leaveAt).toISOString().slice(0,10):null;
      return{...e,status:'standby',onLeave:true,leaveFrom:e.leaveFrom||dateOnly,leaveTo:e.leaveTo||dateOnly};
    }
    return e;
  });
  if(changed){employees=migrated;saveE();}
  return changed;
}

// ── PWA ───────────────────────────────────────────────────────────────────────
window.addEventListener('beforeinstallprompt',e=>{
  e.preventDefault();
  deferredPrompt=e;
  showInstallBar();
  // แสดงปุ่มติดตั้งบน splash ด้วย
  const splashBtn=document.getElementById('splashInstallBtn');
  if(splashBtn)splashBtn.style.display='block';
});
window.addEventListener('appinstalled',()=>{document.getElementById('installBar').classList.add('hidden');deferredPrompt=null;});

function showInstallBar(){
  const bar=document.getElementById('installBar');
  const hint=document.getElementById('installHint');
  const ios=/iPhone|iPad|iPod/i.test(navigator.userAgent);
  if(ios){
    hint.textContent='แตะ 🔗 Share แล้วเลือก "Add to Home Screen"';
    bar.classList.remove('hidden');
    bar.querySelector('.install-bar-btn').textContent='รับทราบ';
    bar.querySelector('.install-bar-btn').onclick=()=>bar.classList.add('hidden');
  }else if(deferredPrompt){
    hint.textContent='กดปุ่มเพื่อเพิ่มไอคอนลงหน้าจอหลัก';
    bar.classList.remove('hidden');
  }
}
function doInstall(){
  if(deferredPrompt){deferredPrompt.prompt();deferredPrompt.userChoice.then(()=>{deferredPrompt=null;document.getElementById('installBar').classList.add('hidden');});}
}

// ── Service Worker — แจ้งเตือนเด้งขึ้นถาดระบบ + สั่น แม้แอพอยู่เบื้องหลัง ──
// หมายเหตุ: Service Worker ทำงานได้เฉพาะบน HTTPS จริง (หรือ localhost) เท่านั้น
// ตอนเปิดไฟล์ในพรีวิว/แบบ file:// จะข้ามการลงทะเบียนไปเงียบๆ ไม่ขึ้น error (ไม่กระทบการใช้งานอื่น)
let _swReg = null;
if ('serviceWorker' in navigator &&
    (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('sw.js').then(reg => {
      _swReg = reg;
    }).catch(e => console.info('SW ยังไม่พร้อม (จะใช้งานได้เมื่ออัปขึ้นโฮสต์จริงพร้อมไฟล์ sw.js):', e.message));
  });
}
const _SKE_ICON='data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"%3E%3Ccircle cx="50" cy="50" r="50" fill="%231E90D6"/%3E%3Ctext x="50" y="65" text-anchor="middle" font-size="36" fill="white" font-family="Arial"%3ESKE%3C/text%3E%3C/svg%3E';
// แสดงการแจ้งเตือน — ผ่าน Service Worker ถ้าพร้อม (เด้งขึ้น system tray ได้แม้อยู่เบื้องหลัง) ไม่งั้น fallback Notification ปกติ
function showSystemNotification(title, options){
  if(!('Notification' in window) || Notification.permission!=='granted') return;
  const opts=Object.assign({
    icon:_SKE_ICON, badge:_SKE_ICON, vibrate:[200,100,200],
    requireInteraction:false, tag:'ske-alert', renotify:true
  }, options||{});
  try{
    const reg=_swReg||(navigator.serviceWorker&&navigator.serviceWorker.controller?navigator.serviceWorker.ready:null);
    if(_swReg&&_swReg.showNotification){ _swReg.showNotification(title,opts); return; }
    if(navigator.serviceWorker&&navigator.serviceWorker.ready){
      navigator.serviceWorker.ready.then(r=>{ _swReg=r; r.showNotification(title,opts); }).catch(()=>{ new Notification(title,opts); });
      return;
    }
    new Notification(title,opts);
  }catch(e){ try{ new Notification(title,opts); }catch(_){} }
}

// ── Keep Awake / Prevent bounce ───────────────────────────────────────────────
(async function(){
  try{if('wakeLock' in navigator){let wl=await navigator.wakeLock.request('screen');document.addEventListener('visibilitychange',async()=>{try{if(document.visibilityState==='visible')wl=await navigator.wakeLock.request('screen');}catch(e){}});}}catch(e){}
})();
window.addEventListener('beforeunload',e=>{e.preventDefault();e.returnValue='';});


// ── Premium video intro controller ───────────────────────────────────────────
// เอาวิดีโอ splash ออกแล้ว (17/07/2569) — ใช้โลโก้ธรรมดาแทน โชว์สั้นๆ แล้วเข้าแอปเลย ไม่ต้องโหลด/แคชไฟล์วิดีโออีกต่อไป
window.SKEIntro={
  play:function(done){
    const splash=document.getElementById('splash');
    if(!splash){ if(typeof done==='function')done(); return; }
    splash.classList.remove('hidden');
    setTimeout(()=>{
      splash.classList.add('ske-intro-fadeout');
      setTimeout(()=>{ splash.classList.add('hidden'); splash.classList.remove('ske-intro-fadeout'); if(typeof done==='function')done(); },520);
    },800);
  }
};

// ── Init ──────────────────────────────────────────────────────────────────────
// ใช้ DOMContentLoaded แทน window.onload เพราะ window.onload จะรอให้ "ทุก resource" ในหน้ารวมถึง
// วิดีโอ splash โหลดเสร็จ 100% ก่อนถึงจะเริ่มแอพ — ถ้าเน็ตช้ามากจะทำให้แอพค้างไม่เปิดเลย
// DOMContentLoaded ยิงทันทีที่ HTML พาร์สเสร็จ ส่วนวิดีโอยังเล่นแบบ progressive ได้ตามปกติ
// และถ้าเน็ตช้าจนเล่นวิดีโอไม่ได้จริงๆ ตัว fallback timeout 8.5 วิที่มีอยู่แล้วจะพาเข้าแอพให้เอง
function skeInitApp(){
  const startApp=function(){
  const ios=/iPhone|iPad|iPod/i.test(navigator.userAgent);
  const sa=window.navigator.standalone||window.matchMedia('(display-mode:standalone)').matches;
  if(!sa&&ios) setTimeout(showInstallBar,600);
  // รอ Firebase โหลดข้อมูลก่อน (max 3 วินาที) — เริ่มเช็คทันที ไม่หน่วงเริ่มต้นอีกต่อไป
  // (เดิมหน่วง 1.8 วิเปล่าๆ ก่อนเริ่มเช็คด้วยซ้ำ ทำให้เปิดแอพช้าเสมอแม้ Firebase จะพร้อมแล้วก็ตาม)
  const startTime=Date.now();
  function tryStart(){
    if(window._fbReady||Date.now()-startTime>3000){
      pruneOldMaintenance();
      migrateLegacyLeaveStatus();
      const savedAdmin=localStorage.getItem('ske_admin')==='1';
      if(savedAdmin){
        adminMode=true;
        adminRole=localStorage.getItem('ske_adminRole')||'super';
        show('admin');renderAdmin();switchAdminTab('summary');applyAdminRoleUI();
        if(window.fbRegisterPushToken)window.fbRegisterPushToken(adminRole==='viewer'?'viewer':'super');
        startAdminAlertTimer();
      }
      else if(currentUser){show('dashboard');renderDashboard();startAlertTimer();}
      else{show('login');renderEmpList();}
    } else {
      setTimeout(tryStart,50);
    }
  }
  tryStart();
  };
  if(window.SKEIntro&&typeof window.SKEIntro.play==='function') window.SKEIntro.play(startApp);
  else startApp();
}
// สคริปต์นี้อยู่ท้าย body ทำให้ DOM พร้อมใช้งานแล้วเกือบตลอด แต่กันเคสที่ DOMContentLoaded
// ยิงไปก่อนแล้ว (เช่นโหลดจาก cache) ด้วยการเช็ค readyState ก่อน
if(document.readyState==='loading'){
  document.addEventListener('DOMContentLoaded',skeInitApp);
} else {
  skeInitApp();
}

// ── กลับเข้าแอปจาก background: soft refresh เท่านั้น ───────────────────────
// ไม่สั่ง goOffline/goOnline อัตโนมัติ เพราะการเข้า–ออกถี่จะทำให้ socket ถูกตัดต่อซ้อนกัน
let _lastVisibleRefresh=0;
let _resumeRefreshTimer=null;
document.addEventListener('visibilitychange',()=>{
  if(document.visibilityState!=='visible')return;
  const now=Date.now();
  if(now-_lastVisibleRefresh<3000)return;
  _lastVisibleRefresh=now;
  clearTimeout(_resumeRefreshTimer);
  _resumeRefreshTimer=setTimeout(()=>{
    if(!navigator.onLine){
      if(window._skeDebugLog)window._skeDebugLog('Resume','เครื่องยัง offline — รอ event online');
      return;
    }
    if(window._skeDebugLog)window._skeDebugLog('Resume','กลับเข้าแอป — soft refresh โดยไม่ตัด connection');
    if(window.forceReconnectNow) window.forceReconnectNow('resume');
    const dash=document.getElementById('dashboard');
    const admin=document.getElementById('admin');
    setTimeout(()=>{
      if(dash&&!dash.classList.contains('hidden')&&typeof renderDashboard==='function')renderDashboard();
      if(admin&&!admin.classList.contains('hidden')&&typeof renderAdmin==='function')renderAdmin();
    },500);
  },700);
});

// ── Nav helpers ───────────────────────────────────────────────────────────────
function show(id){['splash','login','dashboard','admin'].forEach(s=>document.getElementById(s).classList.add('hidden'));document.getElementById(id).classList.remove('hidden');}
function showMode(m){['mode-select','mode-register','mode-adminPw','mode-pin'].forEach(x=>document.getElementById(x).classList.add('hidden'));document.getElementById('mode-'+m).classList.remove('hidden');['loginMsg','regMsg','adminPwMsg','pinMsg'].forEach(x=>{const el=document.getElementById(x);if(el)el.classList.add('hidden');});if(m==='adminPw'){const i=document.getElementById('adminPwInput');if(i)i.value='';const p2=document.getElementById('adminPin2Input');if(p2)p2.value='';if(typeof selLoginRole==='function')selLoginRole('super');}}

function highlightNav(btn){document.querySelectorAll('#dashboard .nav-btn').forEach(b=>b.classList.remove('active'));btn.classList.add('active');}
function highlightAdminNav(btn){document.querySelectorAll('#admin .bottom-nav .nav-btn').forEach(b=>{if(b!==document.querySelector('#admin .nav-btn-orange'))b.classList.remove('active')});btn.classList.add('active');}

// ── Avatar helpers ────────────────────────────────────────────────────────────
// คืน HTML ของรูปภายใน .avatar — ถ้ามี photo ใช้รูป ถ้าไม่มีใช้ตัวอักษร
function avatarImg(emp, size){
  if(emp && emp.photo){
    return `<img data-ph="${emp.photo}" alt="${esc(emp.name)}" loading="lazy" decoding="async" style="width:${size}px;height:${size}px;object-fit:cover;border-radius:50%;display:block;">`;
  }
  return esc((emp && emp.name) ? emp.name.charAt(0) : '?');
}

// บีบอัดรูปให้เล็กลงก่อนบันทึก (max 200x200, quality 0.7) — คืน Promise<base64>
function compressAvatar(file){
  return new Promise((resolve, reject)=>{
    const r=new FileReader();
    r.onload=e=>{
      const img=new Image();
      img.onload=()=>{
        const MAX=200;
        let w=img.width, h=img.height;
        if(w>h){if(w>MAX){h=Math.round(h*MAX/w);w=MAX;}}
        else{if(h>MAX){w=Math.round(w*MAX/h);h=MAX;}}
        const canvas=document.createElement('canvas');
        canvas.width=w; canvas.height=h;
        canvas.getContext('2d').drawImage(img,0,0,w,h);
        resolve(canvas.toDataURL('image/jpeg',0.75));
      };
      img.onerror=reject;
      img.src=e.target.result;
    };
    r.onerror=reject;
    r.readAsDataURL(file);
  });
}

// ── Login ─────────────────────────────────────────────────────────────────────
function renderEmpList(){
  const el=document.getElementById('empList');
  if(!employees.length){
    el.innerHTML='<div class="card" style="text-align:center;color:#9CA3AF;padding:32px;border-radius:20px;"><div style="font-size:44px;margin-bottom:10px;">👷</div><b style="color:#374151;">ยังไม่มีพนักงาน</b><br>กรุณาลงทะเบียนก่อน</div>';
    return;
  }
  el.innerHTML=employees.map(e=>{
    const s=getS(e.status);const lbl=getFullLabel(e);
    return `<button class="emp-btn" onclick="askPin('${e.id}')">
      <div class="avatar">${avatarImg(e,58)}${leaveIcon(e)}</div>
      <div style="flex:1;min-width:0;">
        <div class="login-emp-name">${esc(e.name)}</div>
        <div class="login-emp-plate">🚛 ${esc(e.plate||'-')} นครปฐม</div>
      </div>
      <div class="login-status-pill" style="background:${s.bg};color:${s.color};border:1px solid ${s.border};">${skeIcon(s.ic)} <span style="overflow:hidden;text-overflow:ellipsis;">${esc(lbl)}</span></div>
    </button>`;
  }).join('');
}

let _pinTargetId=null;
function askPin(id){
  const emp=employees.find(e=>e.id===id);if(!emp)return;
  _pinTargetId=id;
  const s=getS(emp.status);
  document.getElementById('pinEmpInfo').innerHTML=`
    <div class="avatar" style="width:52px;height:52px;font-size:22px;margin:0 auto 8px;">${avatarImg(emp,52)}</div>
    <div style="font-weight:800;font-size:16px;color:#1a1a2e;">${esc(emp.name)}</div>
    <div style="color:#888;font-size:12px;margin-top:2px;">🚛 ${esc(emp.plate)}</div>`;
  document.getElementById('pinInput').value='';
  showMode('pin');
  setTimeout(()=>{const p=document.getElementById('pinInput');if(p)p.focus();},200);
}
function doConfirmPin(){
  const emp=employees.find(e=>e.id===_pinTargetId);
  const entered=document.getElementById('pinInput').value.trim();
  const m=document.getElementById('pinMsg');
  if(!emp){m.textContent='เกิดข้อผิดพลาด กรุณาลองใหม่';m.classList.remove('hidden');return;}
  if(!emp.pin){
    // พนักงานเก่าที่ยังไม่มี PIN — ให้ผ่านได้และบันทึก PIN ใหม่
    if(entered.length===4&&/^\d{4}$/.test(entered)){
      employees=employees.map(e=>e.id===emp.id?{...e,pin:entered}:e);saveE();
      doLogin(emp.id);return;
    }else{m.textContent='กรุณากรอก PIN 4 หลัก (ครั้งแรกระบบจะบันทึกเป็น PIN ของคุณ)';m.classList.remove('hidden');return;}
  }
  if(entered!==emp.pin){
    m.textContent='❌ PIN ไม่ถูกต้อง กรุณาลองใหม่';m.classList.remove('hidden');
    document.getElementById('pinInput').value='';return;
  }
  doLogin(emp.id);
}
function doLogin(id){
  currentUser=employees.find(e=>e.id===id)||null;
  saveU();adminMode=false;
  _unlockAudio(); // unlock AudioContext ทันทีที่ login (user gesture)
  show('dashboard');renderDashboard();
  requestNotifPermission();
  startAlertTimer();
}

function doRegister(){
  const name=document.getElementById('regName').value.trim();
  const plate=document.getElementById('regPlate').value.trim().toUpperCase();
  const phone=document.getElementById('regPhone').value.trim();
  const pin=document.getElementById('regPin').value.trim();
  const pin2=document.getElementById('regPin2').value.trim();
  const m=document.getElementById('regMsg');
  if(!name||!plate){m.textContent='กรุณากรอกชื่อและทะเบียนรถ';m.classList.remove('hidden');return;}
  if(!pin||pin.length!==4||!/^\d{4}$/.test(pin)){m.textContent='PIN ต้องเป็นตัวเลข 4 หลัก';m.classList.remove('hidden');return;}
  if(pin!==pin2){m.textContent='PIN ทั้งสองช่องไม่ตรงกัน';m.classList.remove('hidden');return;}
  employees.push({id:Date.now()+'',name,plate,phone,pin,status:'standby',province:'',note:'',updatedAt:new Date().toISOString()});
  saveE();['regName','regPlate','regPhone','regPin','regPin2'].forEach(x=>document.getElementById(x).value='');
  m.classList.add('hidden');showMode('select');renderEmpList();
  const lg=document.getElementById('loginMsg');lg.textContent='✅ ลงทะเบียนสำเร็จ! เลือกชื่อด้านล่าง';lg.classList.remove('hidden');
}

// ── สิทธิ์เข้าระบบหลังบ้าน: super = ผู้ดูแล (เต็ม), viewer = แอดมิน (ดูแผนผังงานอย่างเดียว) ──
let _loginRole='super';
function selLoginRole(r){
  _loginRole=r;
  document.getElementById('roleBtnSuper')?.classList.toggle('active',r==='super');
  document.getElementById('roleBtnViewer')?.classList.toggle('active',r==='viewer');
  const hint=document.getElementById('adminPwHint');
  if(hint){
    if(r==='super'){
      hint.innerHTML='🔑 รหัสผ่านเริ่มต้น: <b>admin1234</b> • PIN ชั้น 2 เริ่มต้น: <b>135790</b><br><span style="color:#888;font-size:11px;">(สิทธิ์เต็ม — จัดการได้ทุกอย่าง · เปลี่ยนรหัสได้ในหน้าตั้งค่า)</span>';
      hint.style.background='#F5F3FF';hint.style.borderColor='#D8B4FE';hint.style.color='#6D28D9';
    }else{
      hint.innerHTML='🔑 รหัสผ่านเริ่มต้น: <b>view1234</b> • PIN ชั้น 2 เริ่มต้น: <b>135790</b><br><span style="color:#888;font-size:11px;">(ดูเฉพาะหน้าแผนผังงาน — แก้ไขอะไรไม่ได้ · ผู้ดูแลตั้งรหัสนี้ได้ในหน้าตั้งค่า)</span>';
      hint.style.background='#ECFEFF';hint.style.borderColor='#A5F3FC';hint.style.color='#0E7490';
    }
  }
  const m=document.getElementById('adminPwMsg');if(m)m.classList.add('hidden');
}

// ปรับหน้าจอแผงหลังบ้านตามบทบาท — viewer เห็นเฉพาะแผนผังงาน, ซ่อนเมนูล่าง + ปุ่มที่แก้ไขได้
function applyAdminRoleUI(){
  const adminEl=document.getElementById('admin');
  const isViewer=adminRole==='viewer';
  if(adminEl)adminEl.classList.toggle('role-viewer',isViewer);
  const title=document.getElementById('adminPanelTitle');
  if(title)title.textContent=isViewer?'แผนผังงาน':'แผงผู้ดูแล';
  const badge=document.getElementById('adminTopBadge');
  if(badge){badge.textContent=isViewer?'แอดมิน':'ADMIN';badge.className=isViewer?'badge-viewer':'badge-admin';}
  document.getElementById('adminViewerLogout')?.classList.toggle('hidden',!isViewer);
  document.getElementById('adminRefreshBtn')?.classList.toggle('hidden',false);
  // แสดงปุ่ม "ดูประวัติการลา" ในหน้าลาเฉพาะ viewer (ผู้ดูแลมีปุ่มนี้ใน accordion ตั้งค่าอยู่แล้ว)
  document.getElementById('viewerLeaveHistoryBar')?.classList.toggle('hidden',!isViewer);
  // viewer ถูกบังคับให้อยู่หน้าแผนผังงาน (summary) เสมอ
  if(isViewer)switchAdminTab('summary');
}

async function doAdminLogin(){
  const pw=document.getElementById('adminPwInput').value;
  const pin2=document.getElementById('adminPin2Input').value;
  const m=document.getElementById('adminPwMsg');
  const wantViewer=_loginRole==='viewer';
  const expectHash=wantViewer?viewerPwHash:adminPwHash;
  const defHint=wantViewer?'view1234':'admin1234';
  if(!pin2){m.textContent='❌ กรุณากรอกรหัสชั้นที่ 2 (PIN) ด้วย';m.classList.remove('hidden');return;}
  const [pwHash,pin2Hash]=await Promise.all([sha256Hex(pw),sha256Hex(pin2)]);
  if(pwHash===expectHash && pin2Hash===adminPin2Hash){
    adminMode=true;adminRole=wantViewer?'viewer':'super';
    saveA();saveAR();
    document.getElementById('adminPwInput').value='';
    document.getElementById('adminPin2Input').value='';
    _unlockAudio(); // unlock AudioContext ทันทีที่ login (user gesture)
    show('admin');renderAdmin();switchAdminTab('summary');applyAdminRoleUI();
    requestNotifPermission();
    // ลงทะเบียน FCM push token — รับแจ้งเตือนแม้ปิดแอป (super/viewer ลงทะเบียนได้ทั้งคู่)
    if(window.fbRegisterPushToken)window.fbRegisterPushToken(wantViewer?'viewer':'super');
    startAdminAlertTimer(); // แอดมินและผู้ดูแลได้รับแจ้งเตือนสถานะค้างเหมือนกัน
  }
  else if(pwHash!==expectHash){m.textContent=`❌ รหัสผ่านไม่ถูกต้อง  (รหัสเริ่มต้น: ${defHint})`;m.classList.remove('hidden');}
  else{m.textContent='❌ รหัสชั้นที่ 2 (PIN) ไม่ถูกต้อง';m.classList.remove('hidden');}
}

function togglePwVis(){
  const inp=document.getElementById('adminPwInput');
  const btn=document.getElementById('pwEyeBtn');
  if(inp.type==='password'){inp.type='text';btn.textContent='🙈';}
  else{inp.type='password';btn.textContent='👁️';}
}

function showResetPw(){document.getElementById('resetPwPanel').classList.remove('hidden');}

async function doEmergencyReset(){
  const code=document.getElementById('emergencyCode').value.trim();
  const m=document.getElementById('resetMsg');
  if(!code){m.textContent='❌ กรุณากรอก Emergency Code';m.style.color='#EF4444';m.classList.remove('hidden');return;}
  const codeHash=await sha256Hex(code);
  if(codeHash===emergencyCodeHash){
    await setAdminPw('admin1234');
    await setViewerPw('view1234');
    await setAdminPin2('135790');
    m.textContent='✅ รีเซ็ตสำเร็จ! ผู้ดูแล=admin1234, แอดมิน=view1234, PIN ชั้น 2=135790';m.style.color='#10B981';m.classList.remove('hidden');
    document.getElementById('adminPwInput').value=(_loginRole==='viewer')?'view1234':'admin1234';
    document.getElementById('adminPin2Input').value='135790';
    setTimeout(()=>{document.getElementById('resetPwPanel').classList.add('hidden');m.classList.add('hidden');},2500);
  }else{m.textContent='❌ Emergency Code ไม่ถูกต้อง';m.style.color='#EF4444';m.classList.remove('hidden');}
}

// ── Alert / Notification System ──────────────────────────────────────────────
const ALERT_STATUSES = ['loading_bay','unload_bay','loading','unloading','standby'];
const ALERT_HOURS = 3;       // แจ้งเตือนทุก 3 ชม. ถ้าไม่อัพเดท (กำลังขึ้น-ลงสินค้า + สแตนบายรอขึ้นงาน)
// นับชั่วโมงที่ "ค้างสถานะ" แบบเพิ่มขึ้นเรื่อยๆ (3,4,5,...) จนกว่าจะมีการเปลี่ยนสถานะ (updatedAt เปลี่ยน)
// ใช้แทนการโชว์แค่ "เวลาล่าสุด" เพราะดูความเร่งด่วนง่ายกว่ามาก ไม่ต้องคำนวณเทียบเวลาปัจจุบันเอง
function _elapsedHours(t){ return t?Math.floor((Date.now()-new Date(t).getTime())/3600000):null; }
function _elapsedLabel(t){
  const h=_elapsedHours(t);
  if(h==null)return'ยังไม่เคยอัพเดท';
  if(h<1)return'เพิ่งอัพเดท';
  if(h>=24)return`ค้างมาแล้ว ${Math.floor(h/24)} วัน ${h%24} ชม.`;
  return`ค้างมาแล้ว ${h} ชม.`;
}
const STALE_ALL_HOURS = 24;  // แจ้งเตือนผู้ดูแล — ทุกสถานะที่ไม่อัพเดทเกิน 24 ชม.
const SNOOZE_MIN = 30;       // snooze 30 นาที

let _alertTimer = null;
let _snoozeUntil = 0;
let _audioCtx = null;
let _audioUnlocked = false;

// unlock AudioContext ทันทีที่ผู้ใช้แตะหน้าจอครั้งแรก
// (Android บังคับให้มี user gesture ก่อนเล่นเสียงได้)
function _unlockAudio(){
  if(_audioUnlocked) return;
  try{
    if(!_audioCtx) _audioCtx = new (window.AudioContext||window.webkitAudioContext)();
    if(_audioCtx.state === 'suspended') _audioCtx.resume();
    // เล่นเสียง silent สั้นๆ เพื่อ unlock
    const buf = _audioCtx.createBuffer(1,1,22050);
    const src = _audioCtx.createBufferSource();
    src.buffer = buf; src.connect(_audioCtx.destination); src.start(0);
    _audioUnlocked = true;
  }catch(e){}
}
document.addEventListener('touchstart', _unlockAudio, {once:true, passive:true});
document.addEventListener('click', _unlockAudio, {once:true, passive:true});

// เล่นเสียงแจ้งเตือน (Web Audio API — ไม่ต้องไฟล์เสียง)
function playAlertSound(){
  try{
    if(!_audioCtx) _audioCtx = new (window.AudioContext||window.webkitAudioContext)();
    const ctx = _audioCtx;
    // resume ก่อนเล่นเสมอ (กัน suspended state บน Android)
    const doPlay = () => {
      [0, 0.18, 0.36, 0.54, 0.72].forEach(offset => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain); gain.connect(ctx.destination);
        osc.type = 'square';
        osc.frequency.setValueAtTime(1100, ctx.currentTime + offset);
        gain.gain.setValueAtTime(0.4, ctx.currentTime + offset);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + offset + 0.14);
        osc.start(ctx.currentTime + offset);
        osc.stop(ctx.currentTime + offset + 0.18);
      });
    };
    if(ctx.state === 'suspended'){
      ctx.resume().then(doPlay).catch(()=>{});
    } else {
      doPlay();
    }
  }catch(e){ console.warn('audio error',e); }
}

function checkAlert(){
  if(!currentUser || adminMode) return;
  const me = employees.find(e=>e.id===currentUser.id);
  if(!me) return;
  // ตรวจเฉพาะสถานะที่กำหนด
  if(!ALERT_STATUSES.includes(me.status)) return;
  // ถ้า snooze อยู่ — ข้าม
  if(Date.now() < _snoozeUntil) return;
  // คำนวณเวลาตั้งแต่อัพเดทล่าสุด
  const last = me.updatedAt ? new Date(me.updatedAt).getTime() : 0;
  const hoursAgo = (Date.now() - last) / 3600000;
  if(hoursAgo >= ALERT_HOURS){
    showAlertModal(me, hoursAgo);
  }
}

function showAlertModal(me, hoursAgo){
  const s = STATUSES.find(st=>st.id===me.status);
  const h = Math.floor(hoursAgo);
  const m = Math.floor((hoursAgo - h) * 60);
  const timeStr = h > 0 ? `${h} ชม. ${m} นาที` : `${m} นาที`;
  document.getElementById('alertModalMsg').innerHTML =
    `สถานะปัจจุบันของคุณ:<br>
     <b style="color:${s?.color||'#333'}">${s?skeIcon(s.ic):''} ${s?.label||me.status}</b><br><br>
     ไม่มีการอัพเดทมาแล้ว <b style="color:#DC2626">${timeStr}</b><br>
     กรุณาอัพเดทสถานะให้เป็นปัจจุบัน`;
  document.getElementById('alertModal').classList.remove('hidden');
  document.getElementById('alertModal').style.display='flex';
  playAlertSound();
  // แจ้งเตือนระบบ (เด้งถาดระบบ+สั่น แม้อยู่เบื้องหลัง)
  showSystemNotification('⚠️ แจ้งเตือนสถานะรถ SKE', {
    body: `${s?.emoji||''} ${s?.label} — ไม่อัพเดทมา ${timeStr} กรุณาอัพเดทสถานะ`,
    icon: 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"%3E%3Ccircle cx="50" cy="50" r="50" fill="%23F47920"/%3E%3Ctext x="50" y="65" text-anchor="middle" font-size="36" fill="white" font-family="Arial"%3ESKE%3C/text%3E%3C/svg%3E'
  });
}

function dismissAlert(){
  document.getElementById('alertModal').classList.add('hidden');
  // เปิด edit panel ให้อัพเดทได้เลย
  editOpen = false;
  renderDashboard();
  setTimeout(()=>{ editOpen=true; renderDashboard(); }, 100);
}

function snoozeAlert(){
  document.getElementById('alertModal').classList.add('hidden');
  _snoozeUntil = Date.now() + SNOOZE_MIN * 60 * 1000;
}

function startAlertTimer(){
  if(_alertTimer) clearInterval(_alertTimer);
  // ตรวจทุก 1 นาที
  _alertTimer = setInterval(checkAlert, 60 * 1000);
  // ตรวจทันทีหลัง 5 วินาที
  setTimeout(checkAlert, 5000);
}

function stopAlertTimer(){
  if(_alertTimer){ clearInterval(_alertTimer); _alertTimer=null; }
}

// ══════════════════════════════════════════════════════════════════════════
// ── แจ้งเตือนผู้ดูแล (เสียง+ข้อความ) เมื่อมีพนักงานไม่อัพเดทสถานะเกิน STALE_ALL_HOURS ──
// ══════════════════════════════════════════════════════════════════════════
let _adminAlertTimer=null;
let _adminSnoozeUntil=0;
// จำว่า "พนักงานคนไหนเคยถูกเด้งแจ้งเตือนค้างสถานะไปแล้ว" — เด้งป๊อปอัพ+เสียงแค่ครั้งเดียวต่อคน
// (กล่องแดง+ป้ายตัวเลขในภาพรวมยังคงแสดงค้างตามจริง ไม่เกี่ยวกับชุดนี้)
// พอพนักงานอัพเดทสถานะจนหลุดจากค้างแล้ว จะลบออกจากชุดนี้ ถ้าค้างใหม่อีกครั้งในอนาคตถึงจะเด้งซ้ำ
let _staleAlerted=(()=>{try{const s=JSON.parse(localStorage.getItem('ske_stale_alerted')||'[]');return new Set(Array.isArray(s)?s:[]);}catch(e){return new Set();}})();
function _saveStaleAlerted(){try{localStorage.setItem('ske_stale_alerted',JSON.stringify([..._staleAlerted]));}catch(e){}}
// ══════════════════════════════════════════════════════════════════════════
// ── แจ้งเตือนผู้ดูแล (เสียง+ข้อความ) ทันทีที่มีพนักงานคนใดเปลี่ยนสถานะ ──
// (เคสพิเศษ "เปลี่ยนเป็นสแตนบายว่างงาน" จะมีกล่องข้อความสีเขียวแยกต่างหาก
//  ส่วนการเปลี่ยนสถานะอื่นๆ ทั้งหมดจะแจ้งด้วยกล่องข้อความสีฟ้าแบบทั่วไป — ทั้งสองแบบเล่นเสียงเหมือนกัน)
// ══════════════════════════════════════════════════════════════════════════
let _availToastTimer=null;
let _statusChangeToastTimer=null;
// เฉพาะ 4 สถานะนี้เท่านั้นที่จะแจ้งเตือนผู้ดูแล (เสียง+ข้อความ) — สถานะอื่นเปลี่ยนแล้วจะไม่แจ้งเตือน
const NOTIFY_STATUSES=['done','standby','loading','unloading'];
function notifyNewlyAvailable(oldList,newList){
  if(!adminMode)return;
  const adminScreen=document.getElementById('admin');
  if(!adminScreen||adminScreen.classList.contains('hidden'))return;
  const oldMap={};
  (oldList||[]).forEach(e=>{oldMap[e.id]=e.status;});
  // เฉพาะพนักงานที่มีข้อมูลอยู่ก่อนแล้ว (ไม่ใช่เพิ่งถูกเพิ่มใหม่), สถานะเปลี่ยนไปจากเดิมจริงๆ,
  // และสถานะใหม่ต้องอยู่ในกลุ่มที่ต้องการแจ้งเตือนเท่านั้น
  const changed=(newList||[]).filter(e=>{
    const prevStatus=oldMap[e.id];
    return prevStatus!==undefined&&prevStatus!==e.status&&NOTIFY_STATUSES.includes(e.status);
  });
  if(!changed.length)return;

  const becameAvailable=changed.filter(e=>e.status==='done');
  const others=changed.filter(e=>e.status!=='done');

  playAlertSound();

  if(becameAvailable.length){
    showAvailableToast(becameAvailable);
    if('Notification' in window && Notification.permission==='granted'){
      const names=becameAvailable.map(e=>e.name).join(', ');
      showSystemNotification('✅ มีรถว่างงานใหม่!', {
        body:`${names} — เปลี่ยนเป็นสแตนบายว่างงานแล้ว`,
        icon:'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"%3E%3Ccircle cx="50" cy="50" r="50" fill="%2310B981"/%3E%3Ctext x="50" y="65" text-anchor="middle" font-size="36" fill="white" font-family="Arial"%3ESKE%3C/text%3E%3C/svg%3E'
      });
    }
  }
  if(others.length){
    showStatusChangeToast(others);
    if('Notification' in window && Notification.permission==='granted'){
      const detail=others.map(e=>{
        const s=STATUSES.find(st=>st.id===e.status);
        return `${e.name} → ${s?.label||e.status}`;
      }).join(' • ');
      showSystemNotification('🔔 มีการเปลี่ยนสถานะรถ', {
        body:detail,
        icon:'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"%3E%3Ccircle cx="50" cy="50" r="50" fill="%231E90D6"/%3E%3Ctext x="50" y="65" text-anchor="middle" font-size="36" fill="white" font-family="Arial"%3ESKE%3C/text%3E%3C/svg%3E'
      });
    }
  }
}
function showAvailableToast(list){
  const el=document.getElementById('vehicleAvailToast');
  const msg=document.getElementById('vehicleAvailToastMsg');
  if(!el||!msg)return;
  const names=list.map(e=>esc(e.name)).join(', ');
  msg.innerHTML=list.length===1?`<b>${names}</b> ว่างงานแล้ว!`:`มีรถว่างงานใหม่ <b>${list.length}</b> คัน: ${names}`;
  el.classList.remove('hidden');el.style.display='flex';
  if(_availToastTimer)clearTimeout(_availToastTimer);
  _availToastTimer=setTimeout(()=>{el.classList.add('hidden');el.style.display='none';},7000);
}
function dismissAvailableToast(){
  const el=document.getElementById('vehicleAvailToast');
  el.classList.add('hidden');el.style.display='none';
  if(_availToastTimer){clearTimeout(_availToastTimer);_availToastTimer=null;}
}
function showStatusChangeToast(list){
  const el=document.getElementById('statusChangeToast');
  const msg=document.getElementById('statusChangeToastMsg');
  if(!el||!msg)return;
  const parts=list.map(e=>{
    const s=getS(e.status);
    return `<b>${esc(e.name)}</b> → ${skeIcon(s.ic)} ${esc(s.label)}`;
  });
  msg.innerHTML=list.length===1?parts[0]:`มีการเปลี่ยนสถานะ ${list.length} คัน: ${parts.join(', ')}`;
  el.classList.remove('hidden');el.style.display='flex';
  if(_statusChangeToastTimer)clearTimeout(_statusChangeToastTimer);
  _statusChangeToastTimer=setTimeout(()=>{el.classList.add('hidden');el.style.display='none';},7000);
}
function dismissStatusChangeToast(){
  const el=document.getElementById('statusChangeToast');
  el.classList.add('hidden');el.style.display='none';
  if(_statusChangeToastTimer){clearTimeout(_statusChangeToastTimer);_statusChangeToastTimer=null;}
}

function checkAdminStaleAlert(){
  if(!adminMode)return;
  const adminScreen=document.getElementById('admin');
  if(!adminScreen||adminScreen.classList.contains('hidden'))return;
  // สถานะเร่งด่วน (กำลังขึ้น-ลงสินค้า + สแตนบายรอขึ้นงาน) ใช้เกณฑ์เดียวกับพนักงาน (ALERT_HOURS=3ชม.)
  // สถานะอื่นๆ (เช่น ออกเดินทาง ที่วิ่งได้ทั้งวันโดยไม่ต้องอัปเดต) ยังคงใช้ STALE_ALL_HOURS=24ชม. กันแจ้งเตือนถี่เกินไป
  // เตือนเฉพาะตำแหน่งพนักงานขับรถเท่านั้น — ตำแหน่งอื่นไม่ต้องแจ้งสถานะรถ ไม่ควรถูกนับว่า "ค้าง"
  const stale=employees.filter(e=>{
    if(!isDrivingPosition(e.position))return false;
    if(!e.updatedAt)return true;
    const hrs=(Date.now()-new Date(e.updatedAt))/3600000;
    const threshold=ALERT_STATUSES.includes(e.status)?ALERT_HOURS:STALE_ALL_HOURS;
    return hrs>=threshold;
  });
  const staleIds=new Set(stale.map(e=>e.id));
  // คนที่หลุดจากค้างแล้ว (อัพเดทสถานะใหม่) → เอาออกจากชุดที่เคยเตือน เพื่อให้ครั้งหน้าถ้าค้างอีกเด้งได้
  let changed=false;
  [..._staleAlerted].forEach(id=>{if(!staleIds.has(id)){_staleAlerted.delete(id);changed=true;}});
  // เด้งเฉพาะ "คนใหม่" ที่ค้างแต่ยังไม่เคยเตือน
  const newStale=stale.filter(e=>!_staleAlerted.has(e.id));
  if(changed&&!newStale.length)_saveStaleAlerted();
  if(Date.now()<_adminSnoozeUntil)return;
  const m=document.getElementById('adminStaleModal');
  if(m&&!m.classList.contains('hidden'))return; // เปิดอยู่แล้ว ไม่ต้องเด้งซ้ำ
  if(newStale.length>0){
    // ถ้าไม่ได้อยู่หน้า "ภาพรวม" (summary) ไม่ต้องเด้ง popup กวนใจ — แต่ยังคงบันทึกว่าเตือนคนนี้ไปแล้ว
    // (badge ตัวเลขแจ้งเตือนที่แท็บภาพรวมยังขึ้นตามจริงอยู่ ไม่เกี่ยวกับส่วนนี้ — คนละกลไกกัน)
    if(window._currentAdminTab!=='summary')return;
    newStale.forEach(e=>_staleAlerted.add(e.id));
    _saveStaleAlerted();
    showAdminStaleAlert(stale); // แสดงรายชื่อค้างทั้งหมด แต่จะเด้งก็ต่อเมื่อมีคนใหม่เท่านั้น
  }
}
function showAdminStaleAlert(stale){
  const sorted=[...stale].sort((a,b)=>(a.updatedAt?new Date(a.updatedAt):0)-(b.updatedAt?new Date(b.updatedAt):0));
  const rows=sorted.slice(0,8).map(e=>{
    let timeStr='ไม่เคยอัพเดท';
    if(e.updatedAt){
      const hrs=(Date.now()-new Date(e.updatedAt))/3600000;
      timeStr=hrs>=24?`${Math.floor(hrs/24)} วัน`:`${Math.floor(hrs)} ชม.`;
    }
    return`<div style="display:flex;align-items:center;justify-content:space-between;padding:7px 0;border-bottom:1px solid #F0F2F8;">
      <span style="font-weight:700;color:#1a1a2e;font-size:13px;">${esc(e.name)}</span>
      <span style="color:#DC2626;font-weight:700;font-size:12px;">${timeStr}</span>
    </div>`;
  }).join('');
  const more=stale.length>8?`<div style="color:#888;font-size:11.5px;margin-top:6px;">และอีก ${stale.length-8} คน</div>`:'';
  document.getElementById('adminStaleMsg').innerHTML=
    `พบพนักงาน <b style="color:#DC2626">${stale.length} คน</b> ที่ไม่อัพเดทสถานะนานผิดปกติ
     <div style="font-size:11px;color:#999;margin-top:2px;">(สแตนบาย/กำลังขึ้น-ลงสินค้า เกิน ${ALERT_HOURS} ชม. · สถานะอื่นๆ เกิน ${STALE_ALL_HOURS} ชม.)</div>
     <div style="margin-top:10px;text-align:left;max-height:240px;overflow-y:auto;">${rows}</div>${more}`;
  const m=document.getElementById('adminStaleModal');
  m.classList.remove('hidden');m.style.display='flex';
  playAlertSound();
  if('Notification' in window && Notification.permission==='granted'){
    showSystemNotification('⚠️ แจ้งเตือนสถานะรถ SKE', {
      body:`มีพนักงาน ${stale.length} คน ไม่อัพเดทสถานะนานผิดปกติ`,
      icon:'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"%3E%3Ccircle cx="50" cy="50" r="50" fill="%23F47920"/%3E%3Ctext x="50" y="65" text-anchor="middle" font-size="36" fill="white" font-family="Arial"%3ESKE%3C/text%3E%3C/svg%3E'
    });
  }
}
function dismissAdminStale(){
  const m=document.getElementById('adminStaleModal');
  m.classList.add('hidden');m.style.display='none';
  switchAdminTab('summary');
}
function snoozeAdminStale(){
  const m=document.getElementById('adminStaleModal');
  m.classList.add('hidden');m.style.display='none';
  _adminSnoozeUntil=Date.now()+SNOOZE_MIN*60*1000;
}
function startAdminAlertTimer(){
  if(_adminAlertTimer)clearInterval(_adminAlertTimer);
  _adminAlertTimer=setInterval(checkAdminStaleAlert,60*1000);
  setTimeout(checkAdminStaleAlert,5000);
}
function stopAdminAlertTimer(){
  if(_adminAlertTimer){clearInterval(_adminAlertTimer);_adminAlertTimer=null;}
}

// ขอ permission แจ้งเตือนตอน login
function requestNotifPermission(){
  if('Notification' in window && Notification.permission==='default'){
    Notification.requestPermission();
  }
}

function doLogout(){if(window.fbUnregisterPushToken)window.fbUnregisterPushToken();closeEmpSettings();closeRepairModal();closeFluidModal();stopAlertTimer();stopAdminAlertTimer();currentUser=null;adminMode=false;adminRole=null;saveU();saveA();saveAR();document.getElementById('admin')?.classList.remove('role-viewer');show('login');renderEmpList();showMode('select');}

// ── Employee settings sheet (โปรไฟล์ + ออกจากระบบ) ───────────────────────────
function openEmpSettings(){
  const me=employees.find(e=>e.id===currentUser?.id)||currentUser;
  if(!me){show('login');renderEmpList();return;}
  const n=document.getElementById('setName'),p=document.getElementById('setPlate'),ph=document.getElementById('setPhone'),li=document.getElementById('setLineId');
  if(n)n.value=me.name||'';
  if(p)p.value=me.plate||'';
  if(ph)ph.value=me.phone||'';
  if(li)li.value=me.lineId||'';
  const msg=document.getElementById('setMsg');if(msg)msg.classList.add('hidden');
  // ล้างฟอร์มเปลี่ยน PIN ทุกครั้งที่เปิด
  ['myCurPin','myNewPin','myNewPin2'].forEach(id=>{const el=document.getElementById(id);if(el)el.value='';});
  const pm=document.getElementById('myPinMsg');if(pm)pm.classList.add('hidden');
  // แสดงรูปโปรไฟล์ปัจจุบัน
  _refreshSettingsAvatar(me);
  const m=document.getElementById('empSettingsModal');
  if(m){m.classList.remove('hidden');m.style.display='flex';}
  document.getElementById('navSettings')?.classList.add('active');
  document.getElementById('navHome')?.classList.remove('active');
}

function _refreshSettingsAvatar(me){
  const av=document.getElementById('settingsAvatar');
  const removeBtn=document.getElementById('removeAvatarBtn');
  if(!av)return;
  if(me && me.photo){
    av.innerHTML=`<img data-ph="${me.photo}" style="width:80px;height:80px;object-fit:cover;border-radius:50%;display:block;">`;
    if(removeBtn)removeBtn.classList.remove('hidden');
  } else {
    av.innerHTML=esc((me&&me.name)?me.name.charAt(0):'?');
    if(removeBtn)removeBtn.classList.add('hidden');
  }
}

async function handleAvatarChange(input){
  const file=input.files&&input.files[0];
  if(!file||!currentUser)return;
  try{
    const compressed=await compressAvatar(file);
    // แสดง preview ทันที
    const av=document.getElementById('settingsAvatar');
    if(av)av.innerHTML=`<img src="${compressed}" style="width:80px;height:80px;object-fit:cover;border-radius:50%;display:block;">`;
    document.getElementById('removeAvatarBtn')?.classList.remove('hidden');
    // อัพรูปเข้าคลัง — ข้อมูลพนักงานเก็บแค่รหัสรูป (ลบรูปเก่าจากคลังทิ้งด้วย)
    const oldPhoto=(employees.find(e=>e.id===currentUser.id)||{}).photo;
    const photoId=await uploadPhoto(compressed);
    if(oldPhoto&&window.fbDeletePhotos)window.fbDeletePhotos([oldPhoto]);
    const patch={photo:photoId};
    employees=employees.map(e=>e.id===currentUser.id?{...e,...patch}:e);
    currentUser={...currentUser,...patch};
    _cacheSet('ske_emp', employees);saveU();
    if(window.fbUpdateEmployeeFields)fbPatchEmployee(currentUser.id,patch);
    renderDashboard();
    const msg=document.getElementById('setMsg');
    if(msg){msg.textContent='✅ อัปเดตรูปโปรไฟล์แล้ว';msg.className='msg-ok';msg.classList.remove('hidden');setTimeout(()=>msg.classList.add('hidden'),2000);}
  }catch(e){console.error('avatar error',e);}
  input.value='';
}

function removeAvatar(){
  if(!currentUser)return;
  const av=document.getElementById('settingsAvatar');
  const me=employees.find(e=>e.id===currentUser.id)||currentUser;
  if(me&&me.photo&&window.fbDeletePhotos)window.fbDeletePhotos([me.photo]);
  if(av)av.innerHTML=esc((me&&me.name)?me.name.charAt(0):'?');
  document.getElementById('removeAvatarBtn')?.classList.add('hidden');
  const patch={photo:null};
  employees=employees.map(e=>e.id===currentUser.id?{...e,...patch}:e);
  currentUser={...currentUser,...patch};
  _cacheSet('ske_emp', employees);saveU();
  if(window.fbUpdateEmployeeFields)fbPatchEmployee(currentUser.id,patch);
  renderDashboard();
}
function closeEmpSettings(){
  const m=document.getElementById('empSettingsModal');
  if(m){m.classList.add('hidden');m.style.display='none';}
  document.getElementById('navSettings')?.classList.remove('active');
  document.getElementById('navHome')?.classList.add('active');
}
function doSaveProfile(){
  if(!currentUser){closeEmpSettings();return;}
  const name=document.getElementById('setName').value.trim();
  const plate=document.getElementById('setPlate').value.trim().toUpperCase();
  const phone=document.getElementById('setPhone').value.trim();
  const lineId=document.getElementById('setLineId')?.value.trim()||'';
  const msg=document.getElementById('setMsg');
  if(!name||!plate){if(msg){msg.textContent='กรุณากรอกชื่อและทะเบียนรถ';msg.className='msg-err';msg.classList.remove('hidden');}return;}
  const patch={name,plate,phone,lineId};
  employees=employees.map(e=>e.id===currentUser.id?{...e,...patch}:e);
  currentUser={...currentUser,...patch};
  saveU();
  _cacheSet('ske_emp', employees);
  if(window.fbUpdateEmployeeFields){
    fbPatchEmployee(currentUser.id,patch);
  } else if(window.fbSaveEmployees){
    window.fbSaveEmployees(employees);
  }
  if(msg){msg.textContent='✅ บันทึกข้อมูลแล้ว';msg.className='msg-ok';msg.classList.remove('hidden');}
  renderDashboard();
  setTimeout(closeEmpSettings,800);
}

// เปลี่ยน PIN ของตนเอง: ตรวจ PIN เดิม + PIN ใหม่ 2 ช่องต้องตรงกัน (กันบุคคลที่ 3 มาแก้)
function doChangeMyPin(){
  const m=document.getElementById('myPinMsg');
  const showErr=(t)=>{if(m){m.textContent=t;m.className='msg-err';m.classList.remove('hidden');}};
  if(!currentUser){closeEmpSettings();return;}
  const me=employees.find(e=>e.id===currentUser.id)||currentUser;
  const cur=(document.getElementById('myCurPin').value||'').trim();
  const np=(document.getElementById('myNewPin').value||'').trim();
  const np2=(document.getElementById('myNewPin2').value||'').trim();
  // ถ้าพนักงานยังไม่เคยตั้ง PIN ให้ผ่านได้โดยไม่ต้องกรอกของเดิม
  if(me.pin && cur!==me.pin){showErr('❌ PIN เดิมไม่ถูกต้อง');return;}
  if(!/^\d{4}$/.test(np)){showErr('PIN ใหม่ต้องเป็นตัวเลข 4 หลัก');return;}
  if(np!==np2){showErr('❌ PIN ใหม่ทั้งสองช่องไม่ตรงกัน');return;}
  if(me.pin && np===me.pin){showErr('⚠️ PIN ใหม่ต้องไม่ซ้ำกับ PIN เดิม');return;}
  const patch={pin:np};
  employees=employees.map(e=>e.id===currentUser.id?{...e,...patch}:e);
  currentUser={...currentUser,...patch};
  saveU();
  _cacheSet('ske_emp', employees);
  if(window.fbUpdateEmployeeFields){
    fbPatchEmployee(currentUser.id,patch);
  } else if(window.fbSaveEmployees){
    window.fbSaveEmployees(employees);
  }
  ['myCurPin','myNewPin','myNewPin2'].forEach(id=>{const el=document.getElementById(id);if(el)el.value='';});
  if(m){m.textContent='✅ เปลี่ยน PIN สำเร็จ! ครั้งต่อไปใช้ PIN ใหม่เข้าใช้งาน';m.className='msg-ok';m.classList.remove('hidden');}
  setTimeout(()=>{if(m)m.classList.add('hidden');},2800);
}

// ── ความคิดเห็น/ข้อเสนอแนะที่มีต่อบริษัท ────────────────────────────────────
function saveFeedbacks(){
  _cacheSet('ske_feedbacks',companyFeedbacks);
  if(window.fbSaveFeedbacks)return window.fbSaveFeedbacks(companyFeedbacks).catch(()=>{});
  return Promise.resolve();
}
function openFeedbackModal(){
  const m=document.getElementById('fbMsg');
  if(m)m.classList.add('hidden');
  document.getElementById('feedbackModal')?.classList.remove('hidden');
}
function closeFeedbackModal(){
  document.getElementById('feedbackModal')?.classList.add('hidden');
}
function doSendFeedback(){
  const m=document.getElementById('fbMsg');
  const showErr=(t)=>{if(m){m.textContent=t;m.className='msg-err';m.classList.remove('hidden');}};
  const text=(document.getElementById('fbText')?.value||'').trim();
  if(!text){showErr('⚠️ กรุณาพิมพ์ความคิดเห็นก่อนส่ง');return;}
  const isAnon=document.getElementById('fbAnon')?.checked||false;
  const me=employees.find(e=>e.id===currentUser?.id)||currentUser;
  const entry={
    id:'fb_'+Date.now()+'_'+Math.random().toString(36).slice(2,6),
    empId:isAnon?'':(me?.id||''),
    empName:isAnon?'':(me?.name||''),
    text,
    isAnonymous:isAnon,
    createdAt:new Date().toISOString()
  };
  companyFeedbacks=companyFeedbacks.concat([entry]);
  saveFeedbacks();
  document.getElementById('fbText').value='';
  document.getElementById('fbAnon').checked=false;
  if(m){m.textContent='✅ ส่งความคิดเห็นเรียบร้อยแล้ว ขอบคุณสำหรับข้อเสนอแนะ';m.className='msg-ok';m.classList.remove('hidden');}
  setTimeout(()=>{closeFeedbackModal();if(m)m.classList.add('hidden');},1800);
}

// ── หน้าแอดมิน: ดูความคิดเห็น/ข้อเสนอแนะที่พนักงานส่งมาทั้งหมด ──
function renderFeedbackList(){
  const el=document.getElementById('feedbackList');
  if(!el)return;
  const list=companyFeedbacks.slice().sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt));
  if(!list.length){
    el.innerHTML='<div style="font-size:12px;color:#aaa;padding:8px 0;">ยังไม่มีความคิดเห็น/ข้อเสนอแนะเข้ามา</div>';
    return;
  }
  el.innerHTML=list.map(f=>`<div class="card" style="padding:12px;margin-bottom:8px;">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;">
      <span style="font-weight:800;font-size:12.5px;color:${f.isAnonymous?'#94A3B8':'#059669'};">${f.isAnonymous?'🙈 ไม่ระบุชื่อ':'👤 '+esc(f.empName||'-')}</span>
      <button onclick="delFeedback('${f.id}')" style="background:none;border:none;color:#DC2626;font-size:14px;cursor:pointer;">🗑️</button>
    </div>
    <div style="font-size:13.5px;color:#1a1a2e;line-height:1.6;white-space:pre-wrap;">${esc(f.text)}</div>
    <div style="font-size:10.5px;color:#aaa;margin-top:6px;">${fmt(f.createdAt)}</div>
  </div>`).join('');
}
function delFeedback(id){
  if(!confirm('ลบความคิดเห็นนี้?'))return;
  companyFeedbacks=companyFeedbacks.filter(f=>f.id!==id);
  saveFeedbacks();
  renderFeedbackList();
}

// ══════════════════════════════════════════════════════════════════════════
// ── รายการแจ้งซ่อม (Repair reports) ─────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════════════
function openRepairModal(){
  if(!currentUser)return;
  document.getElementById('repairForm').classList.add('hidden');
  document.getElementById('repairFormToggleBtn').textContent='+ แจ้งซ่อมใหม่';
  document.getElementById('repIssue').value='';
  selRepUrgency('normal');
  renderRepairList();
  const m=document.getElementById('repairModal');
  m.classList.remove('hidden');m.style.display='flex';
}
function closeRepairModal(){
  const m=document.getElementById('repairModal');
  m.classList.add('hidden');m.style.display='none';
}
function toggleRepairForm(){
  const f=document.getElementById('repairForm');
  const open=f.classList.toggle('hidden');
  document.getElementById('repairFormToggleBtn').textContent=open?'+ แจ้งซ่อมใหม่':'✕ ยกเลิก';
  if(open){ // เพิ่งปิดฟอร์ม (ยกเลิก) → ล้างรูปที่เลือกค้างไว้
    _repNewPhotos=[];renderNewRepairPhotos();
    const ti=document.getElementById('repIssue');if(ti)ti.value='';
  }
}
function selRepUrgency(u){
  _repUrgency=u;
  document.getElementById('repUrg_normal').style.cssText=u==='normal'?'border-color:#1E90D6;color:#1E90D6;background:#EFF6FF;':'border-color:#E8EAF0;color:#888;background:#F5F6FA;';
  document.getElementById('repUrg_urgent').style.cssText=u==='urgent'?'border-color:#EF4444;color:#EF4444;background:#FEF2F2;':'border-color:#E8EAF0;color:#888;background:#F5F6FA;';
}
// พนักงานเลือกรูปแนบตอนแจ้งซ่อม (ย่อก่อนเก็บไว้ใน staging)
async function addNewRepairPhotos(input){
  const files=Array.from(input.files||[]);
  input.value='';
  if(!files.length)return;
  const room=3-_repNewPhotos.length;
  if(room<=0){alert('⚠️ แนบได้สูงสุด 3 รูป');return;}
  const take=files.slice(0,room);
  if(files.length>room)alert(`⚠️ แนบได้อีก ${room} รูป (สูงสุด 3 รูป)`);
  try{
    for(const f of take){
      const dataUrl=await _compressImage(f,900,0.6);
      _repNewPhotos.push(dataUrl);
    }
    renderNewRepairPhotos();
  }catch(e){console.error('compress error',e);alert('❌ '+((e&&e.message&&/[ก-๙]/.test(e.message))?e.message:'เพิ่มรูปไม่สำเร็จ ลองใหม่อีกครั้ง'));}
}
function delNewRepairPhoto(idx){
  _repNewPhotos.splice(idx,1);
  renderNewRepairPhotos();
}
function renderNewRepairPhotos(){
  const box=document.getElementById('repNewImgPreview');
  if(!box)return;
  box.innerHTML=_repNewPhotos.map((p,i)=>`<div style="position:relative;">
    <img src="${p}" style="width:72px;height:72px;object-fit:cover;border-radius:8px;border:1px solid #E8EAF0;">
    <button type="button" onclick="delNewRepairPhoto(${i})" style="position:absolute;top:-6px;right:-6px;background:#EF4444;color:#fff;border:none;border-radius:50%;width:22px;height:22px;font-size:13px;line-height:1;cursor:pointer;box-shadow:0 1px 4px rgba(0,0,0,.3);">✕</button>
  </div>`).join('');
}
async function doAddRepair(){
  if(!currentUser)return;
  const issue=document.getElementById('repIssue').value.trim();
  if(!issue){document.getElementById('repIssue').focus();return;}
  const me=employees.find(e=>e.id===currentUser.id)||currentUser;
  const hasPhotos=_repNewPhotos.length>0;
  let photoIds=[];
  if(hasPhotos){
    showDocUploadPopup('กำลังส่งรูปแจ้งซ่อม','กรุณารอสักครู่ อย่าเพิ่งปิดหน้านี้');
    try{
      photoIds=await uploadPhotos(_repNewPhotos); // อัพรูปเข้าคลังก่อน — รายการเก็บแค่รหัส
    }catch(e){
      hideDocUploadPopup();
      alert('❌ ส่งรูปไม่สำเร็จ (เน็ตช้า/หลุด) กรุณาลองใหม่อีกครั้ง — ข้อความและรูปที่เลือกไว้ยังอยู่ครบ');
      return;
    }
  }
  const newRec={
    id:'rep_'+Date.now(),
    empId:me.id,empName:me.name,plate:me.plate||'',
    issue,urgency:_repUrgency,status:'pending',approval:'pending',
    empPhotos:photoIds,
    createdAt:new Date().toISOString()
  };
  repairs.unshift(newRec);
  try{
    await saveRepairs();
    if(hasPhotos){hideDocUploadPopup();showDocUploadToast('✅ ส่งแจ้งซ่อมสำเร็จ',true);}
  }catch(e){
    // เน็ตช้า/หลุด — ข้อมูล (ตอนนี้เบามาก เพราะไม่มีรูปฝัง) ถูกคิวไว้ใน outbox แล้ว ส่งซ้ำอัตโนมัติ
    console.warn('doAddRepair: บันทึกไม่สำเร็จในทันที รอคิวส่งซ้ำอัตโนมัติ',e);
    hideDocUploadPopup();
    showDocUploadToast('⚠️ เน็ตช้า/หลุดอยู่ — ระบบจะส่งข้อมูลนี้ต่อให้อัตโนมัติเมื่อสัญญาณกลับมา',false);
  }
  document.getElementById('repIssue').value='';
  _repNewPhotos=[];
  renderNewRepairPhotos();
  selRepUrgency('normal');
  toggleRepairForm();
  refreshRepairViews();
}
// ── สถานะรวม "อนุมัติ/ไม่อนุมัติ" + "ซ่อมเสร็จ/รอดำเนินการ" ของรายการแจ้งซ่อม ──
// ── สถานะ "อนุมัติ/ไม่อนุมัติ" การลา ──────────────────────────────────────────
function leaveApprovalPill(e){
  if(e.leaveApproval==='approved')return{text:'✅ อนุมัติการลาแล้ว',bg:'#ECFDF5',color:'#065F46',border:'#6EE7B7'};
  if(e.leaveApproval==='rejected')return{text:'❌ ไม่อนุมัติการลา',bg:'#FEF2F2',color:'#DC2626',border:'#FCA5A5'};
  return{text:'🕐 รอการอนุมัติ',bg:'#FFFBEB',color:'#92400E',border:'#FCD34D'};
}
function setLeaveApproval(empId,decision){
  const e=employees.find(x=>x.id===empId);if(!e)return;

  if(decision==='approved'){
    // อนุมัติแล้ว: ให้คงสถานะลาไว้ เพื่อให้ขึ้นในหน้าภาพรวม/สถานะรถระหว่างวันที่ลา
    // และบันทึกประวัติ 1 ครั้งเท่านั้น
    const logKey=empId+'_'+(e.leaveFrom||todayStr())+'_'+(e.leaveTo||e.leaveFrom||todayStr());
    const exists=leaveLogs.some(l=>(l.empId+'_'+l.leaveFrom+'_'+l.leaveTo)===logKey);
    if(!exists){
      const log={
        id:'lv_'+Date.now()+'_'+empId,
        empId,empName:e.name,plate:e.plate||'',phone:e.phone||'',
        leaveFrom:e.leaveFrom||todayStr(),leaveTo:e.leaveTo||e.leaveFrom||todayStr(),
        leaveNote:e.leaveNote||'',leaveReply:e.leaveReply||'',
        approvedAt:new Date().toISOString(),
        year:new Date().getFullYear(),
        month:new Date().getMonth()+1,
      };
      try{
        const d1=new Date(log.leaveFrom),d2=new Date(log.leaveTo);
        log.days=Math.max(1,Math.round((d2-d1)/(86400000))+1);
      }catch(_){log.days=1;}
      leaveLogs.unshift(log);
      const curYear=new Date().getFullYear();
      leaveLogs=leaveLogs.filter(l=>l.year>=curYear-1);
      saveLeaveLogs();
    }
    const patch={onLeave:true,leaveFrom:e.leaveFrom||todayStr(),leaveTo:e.leaveTo||e.leaveFrom||todayStr(),leaveApproval:'approved'};
    employees=employees.map(x=>x.id===empId?{...x,...patch}:x);
    if(currentUser?.id===empId){currentUser={...currentUser,...patch};saveU();}
    _cacheSet('ske_emp', employees);
    if(window.fbUpdateEmployeeFields){
      fbPatchEmployee(empId,patch);
    } else if(window.fbSaveEmployees){window.fbSaveEmployees(employees);}
    renderAdmin();
    return;
  }

  if(decision==='rejected'){
    // ไม่อนุมัติ: ไม่แสดงสถานะลา และไม่เก็บเข้าประวัติการลา
    const patch={onLeave:false,leaveFrom:null,leaveTo:null,leaveNote:null,leaveApproval:null,leaveReply:null,leaveReplyAt:null};
    employees=employees.map(x=>x.id===empId?{...x,...patch}:x);
    if(currentUser?.id===empId){currentUser={...currentUser,...patch};saveU();}
    _cacheSet('ske_emp', employees);
    if(window.fbUpdateEmployeeFields){
      fbPatchEmployee(empId,patch);
    } else if(window.fbSaveEmployees){
      window.fbSaveEmployees(employees);
    }
    renderAdmin();
    return;
  }

  const patch={leaveApproval:decision};
  employees=employees.map(x=>x.id===empId?{...x,...patch}:x);
  if(currentUser?.id===empId){currentUser={...currentUser,...patch};saveU();}
  _cacheSet('ske_emp', employees);
  if(window.fbUpdateEmployeeFields){
    fbPatchEmployee(empId,patch);
  } else if(window.fbSaveEmployees){
    window.fbSaveEmployees(employees);
  }
  renderAdmin();
}

function saveLeaveReply(empId){
  const ta=document.getElementById('lr_'+empId);
  if(!ta)return;
  const msg=ta.value.trim();
  const now=new Date().toISOString();
  const patch={leaveReply:msg,leaveReplyAt:msg?now:null};
  employees=employees.map(e=>e.id===empId?{...e,...patch}:e);
  if(currentUser?.id===empId){currentUser={...currentUser,...patch};saveU();}
  _cacheSet('ske_emp', employees);
  if(window.fbUpdateEmployeeFields){
    fbPatchEmployee(empId,patch);
  } else if(window.fbSaveEmployees){
    window.fbSaveEmployees(employees);
  }
  renderAdmin();
  alert(msg?'✅ ส่งข้อความถึงพนักงานแล้ว':'🗑️ ลบข้อความแล้ว');
}

function repairStatusPill(r){
  if(r.approval==='rejected')return{text:'❌ ไม่อนุมัติ',bg:'#FEF2F2',color:'#DC2626',border:'#FCA5A5'};
  if(r.approval==='checking_price')return{text:'🔍 รอใบเสนอราคา',bg:'#F5F3FF',color:'#6D28D9',border:'#C4B5FD'};
  if(r.approval==='approved'){
    if(r.status==='done')return{text:'✅ ซ่อมเสร็จแล้ว',bg:'#ECFDF5',color:'#065F46',border:'#6EE7B7'};
    return{text:'🔧 อนุมัติแล้ว — กำลังซ่อม',bg:'#EFF6FF',color:'#1E90D6',border:'#93C5FD'};
  }
  return{text:'🕐 รอตรวจสอบ',bg:'#FFFBEB',color:'#92400E',border:'#FCD34D'};
}

function _isRepairInCurrentFilter(r){
  if(!r || isRepairResolved(r))return false;
  if(_repairStatusFilter==='pending')return !r.approval||r.approval==='pending';
  if(_repairStatusFilter==='checking_price')return r.approval==='checking_price';
  if(_repairStatusFilter==='approved')return r.approval==='approved';
  return true;
}
function _refreshOneRepairCard(id){
  const r=repairs.find(x=>x.id===id);
  const card=document.querySelector(`#adminRepairGroups [data-repair-id="${id}"]`);
  if(card && r && _isRepairInCurrentFilter(r)){
    const wrap=document.createElement('div');
    wrap.innerHTML=_repairCardHTML(r).trim();
    card.replaceWith(wrap.firstElementChild);
    updateAdminMaintBadge();
    return true;
  }
  if(card && (!r || !_isRepairInCurrentFilter(r))){card.remove();updateAdminMaintBadge();return true;}
  return false;
}
function setRepairApproval(id,decision){
  const patch={approval:decision};
  repairs=repairs.map(r=>r.id===id?{...r,...patch}:r);
  _cacheSet('ske_repairs', repairs);
  _patchRepair(id,patch);
  const adminPanel=document.getElementById('adminMaintPanel');
  if(adminPanel && !adminPanel.classList.contains('hidden')){
    renderAdminRepairList();
  }else refreshRepairViews();
}
// ผู้ดูแลพิมพ์ข้อความตอบกลับ/แจ้งวิธีดำเนินการต่อ ไปยังพนักงานเจ้าของรายการ
function saveRepairReply(id){
  const ta=document.getElementById('rep_reply_'+id);
  if(!ta)return;
  const msg=ta.value.trim();
  const now=new Date().toISOString();
  const cur=repairs.find(r=>r.id===id);
  const hasPhotos=cur&&cur.photos&&cur.photos.length;
  const patch={reply:msg,replyAt:(msg||hasPhotos)?now:null,replyRead:false};
  repairs=repairs.map(r=>r.id===id?{...r,...patch}:r);
  _cacheSet('ske_repairs', repairs);
  _patchRepair(id,patch);refreshRepairViews();
  alert((msg||hasPhotos)?'✅ ส่งถึงพนักงานแล้ว':'🗑️ ลบข้อความแล้ว');
}

// ย่อ + บีบอัดรูปเป็น base64 (ด้านยาวสุด 900px, JPEG คุณภาพ 0.6) ก่อนเก็บลง DB
// ── ตัวช่วยอ่านรูปแบบทนทาน (ใช้ร่วมกันทุกจุดอัปโหลดรูป) ──
// ปัญหาที่เจอบ่อย: มือถือ Samsung/รุ่นใหม่ตั้งค่ากล้องเป็น "รูปภาพประสิทธิภาพสูง" → ได้ไฟล์ HEIC/HEIF
// ซึ่ง Chrome บน Android เปิดอ่านไม่ได้เลย ระบบบีบอัดรูปจึงล้มเหลวทุกครั้งที่พนักงานเลือกรูปพวกนี้
function _isHeicFile(file){
  const t=((file&&file.type)||'').toLowerCase();
  const n=((file&&file.name)||'').toLowerCase();
  return t.includes('heic')||t.includes('heif')||/\.hei[cf]$/.test(n);
}
const HEIC_HELP_MSG='รูปนี้เป็นไฟล์ HEIC/HEIF ซึ่งเบราว์เซอร์เปิดไม่ได้\n\nวิธีแก้ (เลือกอย่างใดอย่างหนึ่ง):\n1) ส่งรูปนี้เข้า LINE (ส่งหาตัวเองหรือ Keep) แล้วเซฟกลับมาเลือกใหม่ — LINE จะแปลงเป็น JPEG ให้อัตโนมัติ\n2) เข้าตั้งค่ากล้องมือถือ ปิดโหมด "รูปภาพประสิทธิภาพสูง (HEIF)" แล้วถ่ายรูปใหม่';
// decode รูปเป็นสิ่งที่วาดลง canvas ได้ — ลอง createImageBitmap ก่อน (ทนกว่าและประหยัดแรมกว่ากับรูปใหญ่ๆ)
// ถ้าไม่ได้ค่อย fallback เป็นวิธีเดิม (FileReader + <img>) แล้วถ้ายังไม่ได้อีกจึงแจ้ง error ที่บอกวิธีแก้จริงๆ
async function _decodeImage(file){
  try{
    if(window.createImageBitmap){
      const bmp=await createImageBitmap(file);
      if(bmp&&bmp.width&&bmp.height)return{src:bmp,w:bmp.width,h:bmp.height,close:()=>{try{bmp.close();}catch(e){}}};
      try{bmp&&bmp.close&&bmp.close();}catch(e){}
    }
  }catch(e){/* ตกไปวิธีถัดไปด้านล่าง */}
  const dataUrl=await new Promise((res,rej)=>{
    const r=new FileReader();
    r.onerror=()=>rej(new Error('อ่านไฟล์รูปภาพไม่สำเร็จ กรุณาลองเลือกรูปใหม่'));
    r.onload=()=>res(String(r.result||''));
    r.readAsDataURL(file);
  });
  const img=await new Promise((res,rej)=>{
    const im=new Image();
    im.onload=()=>res(im);
    im.onerror=()=>rej(new Error(_isHeicFile(file)?HEIC_HELP_MSG:'ไฟล์รูปนี้เปิดอ่านไม่ได้ กรุณาลองเลือกรูปใหม่'));
    im.src=dataUrl;
  });
  return{src:img,w:img.naturalWidth||img.width,h:img.naturalHeight||img.height,close:()=>{}};
}

async function _compressImage(file,maxDim,quality){
  // รองรับเฉพาะไฟล์รูปภาพ (บาง gallery picker ให้ type ว่างมา — ปล่อยผ่านให้ decoder ตัดสินเอง)
  if(!file||(file.type&&!file.type.startsWith('image/'))){
    throw new Error('ไฟล์ที่เลือกไม่ใช่รูปภาพ กรุณาเลือกรูปภาพเท่านั้น');
  }
  const d=await _decodeImage(file);
  try{
    let w=d.w,h=d.h;
    if(!w||!h)throw new Error('ไฟล์รูปนี้เปิดอ่านไม่ได้ กรุณาลองเลือกรูปใหม่');
    if(w>h){ if(w>maxDim){h=Math.round(h*maxDim/w);w=maxDim;} }
    else{ if(h>maxDim){w=Math.round(w*maxDim/h);h=maxDim;} }
    const cv=document.createElement('canvas');
    cv.width=w;cv.height=h;
    cv.getContext('2d').drawImage(d.src,0,0,w,h);
    return cv.toDataURL('image/jpeg',quality||0.7);
  }finally{d.close();}
}

// แนบรูปเข้ารายการซ่อม (สูงสุด 3 รูป) — ย่อก่อนเก็บแล้ว sync ขึ้น Firebase
async function addRepairPhotos(id,input){
  const files=Array.from(input.files||[]);
  input.value='';
  if(!files.length)return;
  const r=repairs.find(x=>x.id===id);if(!r)return;
  const existing=(r.photos||[]).slice();
  const room=3-existing.length;
  if(room<=0){alert('⚠️ แนบได้สูงสุด 3 รูปต่อรายการ');return;}
  const take=files.slice(0,room);
  if(files.length>room)alert(`⚠️ แนบได้อีก ${room} รูป (สูงสุด 3 รูป) จะเพิ่มให้เฉพาะ ${room} รูปแรก`);
  try{
    showDocUploadPopup('กำลังส่งรูป','กรุณารอสักครู่ อย่าเพิ่งปิดหน้านี้');
    for(const f of take){
      const dataUrl=await _compressImage(f,900,0.6);
      existing.push(await uploadPhoto(dataUrl)); // เข้าคลังรูป เก็บแค่รหัส
    }
    const patch={photos:existing};
    repairs=repairs.map(x=>x.id===id?{...x,...patch}:x);
    _cacheSet('ske_repairs', repairs);
    await _patchRepair(id,patch);
    hideDocUploadPopup();
    refreshRepairViews();
  }catch(e){
    console.error('compress error',e);
    hideDocUploadPopup();
    alert('❌ '+((e&&e.message&&/[ก-๙]/.test(e.message))?e.message:'เพิ่มรูปไม่สำเร็จ ลองใหม่อีกครั้ง'));
  }
}

// ลบรูปออกจากรายการซ่อม (field = 'photos' หรือ 'empPhotos')
function delRepairPhoto(id,idx,field){
  field=field||'photos';
  if(!confirm('ลบรูปนี้?'))return;
  const r=repairs.find(x=>x.id===id);if(!r||!r[field])return;
  const removed=r[field][idx];
  if(removed&&window.fbDeletePhotos)window.fbDeletePhotos([removed]); // ลบตัวรูปจริงออกจากคลังด้วย
  const arr=r[field].filter((_,i)=>i!==idx);
  const patch={[field]:arr};
  repairs=repairs.map(x=>x.id===id?{...x,...patch}:x);
  _cacheSet('ske_repairs', repairs);
  _patchRepair(id,patch);refreshRepairViews();
  closePhotoViewer();
}

// ดูรูปเต็มจอ + ปุ่มลบ — field = 'photos' (ผู้ดูแล) หรือ 'empPhotos' (พนักงานแจ้งซ่อม)
function viewRepairPhoto(id,idx,field){
  field=field||'photos';
  const r=repairs.find(x=>x.id===id);if(!r||!r[field]||!r[field][idx])return;
  let ov=document.getElementById('photoViewer');
  if(!ov){
    ov=document.createElement('div');ov.id='photoViewer';
    ov.style.cssText='position:fixed;inset:0;z-index:10001;background:rgba(0,0,0,.9);display:flex;align-items:center;justify-content:center;flex-direction:column;gap:14px;padding:20px;';
    ov.onclick=ev=>{if(ev.target===ov)closePhotoViewer();};
    document.body.appendChild(ov);
  }
  // ผู้ดูแลลบได้ทุกรูป / พนักงานลบได้เฉพาะรูปที่ตัวเองแนบ (empPhotos) ของรายการตัวเอง
  const canDel=(typeof adminMode!=='undefined'&&adminMode)||(field==='empPhotos'&&currentUser&&r.empId===currentUser.id);
  ov.innerHTML=`<img data-ph="${r[field][idx]}" style="max-width:100%;max-height:78vh;border-radius:12px;object-fit:contain;">
    <div style="display:flex;gap:10px;">
      ${canDel?`<button class="btn btn-red btn-sm" onclick="delRepairPhoto('${id}',${idx},'${field}')">🗑️ ลบรูปนี้</button>`:''}
      <button class="btn btn-gray btn-sm" onclick="closePhotoViewer()">✕ ปิด</button>
    </div>`;
  ov.style.display='flex';
}
function closePhotoViewer(){const ov=document.getElementById('photoViewer');if(ov)ov.style.display='none';}
// ── ดูรูปเดี่ยวแบบง่าย (ใช้กับรูปหลักฐานเอกสารส่วนกลาง ที่ไม่ได้เก็บเป็นอาเรย์รูป) ──
function openPhotoViewer(src){
  if(!src)return;
  let ov=document.getElementById('photoViewer');
  if(!ov){
    ov=document.createElement('div');ov.id='photoViewer';
    ov.style.cssText='position:fixed;inset:0;z-index:10001;background:rgba(0,0,0,.9);display:flex;align-items:center;justify-content:center;flex-direction:column;gap:14px;padding:20px;';
    ov.onclick=ev=>{if(ev.target===ov)closePhotoViewer();};
    document.body.appendChild(ov);
  }
  ov.innerHTML=`<img data-ph="${src}" style="max-width:100%;max-height:82vh;border-radius:12px;object-fit:contain;">
    <button class="btn btn-gray btn-sm" onclick="closePhotoViewer()">✕ ปิด</button>`;
  ov.style.display='flex';
}

// ── รูปแนบในบันทึกเปลี่ยนถ่ายของเหลว ──
function viewFluidPhoto(id,idx){
  const f=fluidLogs.find(x=>x.id===id);if(!f||!f.photos||!f.photos[idx])return;
  let ov=document.getElementById('photoViewer');
  if(!ov){
    ov=document.createElement('div');ov.id='photoViewer';
    ov.style.cssText='position:fixed;inset:0;z-index:10001;background:rgba(0,0,0,.9);display:flex;align-items:center;justify-content:center;flex-direction:column;gap:14px;padding:20px;';
    ov.onclick=ev=>{if(ev.target===ov)closePhotoViewer();};
    document.body.appendChild(ov);
  }
  // ผู้ดูแลลบได้ / พนักงานลบได้เฉพาะของตัวเอง
  const canDel=(typeof adminMode!=='undefined'&&adminMode)||(currentUser&&f.empId===currentUser.id);
  ov.innerHTML=`<img data-ph="${f.photos[idx]}" style="max-width:100%;max-height:78vh;border-radius:12px;object-fit:contain;">
    <div style="display:flex;gap:10px;">
      ${canDel?`<button class="btn btn-red btn-sm" onclick="delFluidPhoto('${id}',${idx})">🗑️ ลบรูปนี้</button>`:''}
      <button class="btn btn-gray btn-sm" onclick="closePhotoViewer()">✕ ปิด</button>
    </div>`;
  ov.style.display='flex';
}
function delFluidPhoto(id,idx){
  if(!confirm('ลบรูปนี้?'))return;
  const f=fluidLogs.find(x=>x.id===id);if(!f||!f.photos)return;
  const photos=f.photos.filter((_,i)=>i!==idx);
  fluidLogs=fluidLogs.map(x=>x.id===id?{...x,photos}:x);
  saveFluid().catch(()=>{});refreshFluidViews();
  closePhotoViewer();
}
let _empRepairVisible=12;
function renderRepairList(loadMore){
  const el=document.getElementById('repairList');
  if(!el||!currentUser)return;
  if(!loadMore)_empRepairVisible=12;
  const mine=repairs.filter(r=>r.empId===currentUser.id).sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt));
  if(!mine.length){
    el.innerHTML='<div class="maint-empty"><div class="empty-icon">'+skeIcon('wrench')+'</div><div>ยังไม่มีรายการแจ้งซ่อม</div></div>';
    updateMaintBadges();
    return;
  }
  const view=mine.slice(0,_empRepairVisible);
  el.innerHTML=view.map(r=>{
    const done=r.status==='done';
    const urg=r.urgency==='urgent';
    const pill=repairStatusPill(r);
    const approved=r.approval==='approved';const rejected=r.approval==='rejected';
    return`<div class="maint-card ${urg&&!done?'urgent':''} ${done?'fixed':''} ${rejected?'fixed':''}" data-repair-id="${r.id}">
      <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:8px;">
        <div style="flex:1;min-width:0;color:#1a1a2e;font-size:13.5px;font-weight:600;line-height:1.5;">${esc(r.issue)}</div>
        <span class="urgency-pill" style="background:${urg?'#FEF2F2':'#EFF6FF'};color:${urg?'#DC2626':'#1E90D6'};border:1px solid ${urg?'#FCA5A5':'#93C5FD'};">${urg?'🔴 เร่งด่วน':'🔵 ปกติ'}</span>
      </div>
      <div style="display:flex;align-items:center;justify-content:space-between;margin-top:10px;">
        <span class="pill" style="background:${pill.bg};color:${pill.color};border:1px solid ${pill.border};">${pill.text}</span>
        <span style="color:#aaa;font-size:11px;">${fmt(r.createdAt)}</span>
      </div>
      ${(r.empPhotos&&r.empPhotos.length)?`<div style="margin-top:10px;">
        <div style="font-size:11px;color:#F47920;font-weight:700;margin-bottom:5px;">📷 รูปที่คุณแนบ (${r.empPhotos.length})</div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;">
          ${r.empPhotos.map((p,i)=>`<img data-ph="${p}" loading="lazy" decoding="async" onclick="viewRepairPhoto('${r.id}',${i},'empPhotos')" style="width:72px;height:72px;object-fit:cover;border-radius:8px;border:1px solid #E8EAF0;cursor:pointer;">`).join('')}
        </div>
      </div>`:''}
      ${r.reply?`<div style="margin-top:10px;background:#EFF6FF;border:1px solid #BFDBFE;border-radius:12px;padding:10px 12px;">
        <div style="font-size:11px;color:#1E90D6;font-weight:700;margin-bottom:3px;">💬 ข้อความจากผู้ดูแล${r.replyAt?` · ${fmt(r.replyAt)}`:''}</div>
        <div style="font-size:13px;color:#1a1a2e;line-height:1.6;white-space:pre-wrap;">${esc(r.reply)}</div>
      </div>`:''}
      ${(r.photos&&r.photos.length)?`<div style="margin-top:10px;">
        <div style="font-size:11px;color:#1E90D6;font-weight:700;margin-bottom:5px;">📷 รูปจากผู้ดูแล (${r.photos.length})</div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;">
          ${r.photos.map((p,i)=>`<img data-ph="${p}" loading="lazy" decoding="async" onclick="viewRepairPhoto('${r.id}',${i})" style="width:72px;height:72px;object-fit:cover;border-radius:8px;border:1px solid #E8EAF0;cursor:pointer;">`).join('')}
        </div>
      </div>`:''}
      <div class="row-btns" style="margin-top:10px;">
        ${approved?`<button class="btn ${done?'btn-gray':'btn-green'} btn-sm" style="flex:1;" onclick="toggleRepairStatus('${r.id}')">${done?'↺ เปิดรายการอีกครั้ง':'✓ แจ้งซ่อมเสร็จแล้ว'}</button>`:''}
        <button class="btn btn-red btn-sm" ${approved?'':'style="flex:1;"'} onclick="doDelRepair('${r.id}')">🗑️ ลบรายการ</button>
      </div>
    </div>`;
  }).join('')+(mine.length>_empRepairVisible?`<button class="btn btn-gray btn-full" style="margin-top:10px;border-radius:14px;" onclick="_empRepairVisible+=12;renderRepairList(true)">โหลดเพิ่ม ${Math.min(12,mine.length-_empRepairVisible)} รายการ</button>`:'');
  updateMaintBadges();
}
function toggleRepairStatus(id){
  const cur=repairs.find(r=>r.id===id);
  const patch={status:(cur&&cur.status==='done')?'pending':'done'};
  repairs=repairs.map(r=>r.id===id?{...r,...patch}:r);
  _cacheSet('ske_repairs', repairs);
  _patchRepair(id,patch);refreshRepairViews();
}
function doDelRepair(id){
  if(!confirm('ลบรายการแจ้งซ่อมนี้?'))return;
  repairs=repairs.filter(r=>r.id!==id);
  saveRepairs().catch(()=>{});refreshRepairViews();
}
// รีเฟรชทุกหน้าที่อาจกำลังแสดงรายการแจ้งซ่อมอยู่ (หน้าพนักงาน + แผงผู้ดูแล)
function refreshRepairViews(){
  const empModal=document.getElementById('repairModal');
  if(empModal && !empModal.classList.contains('hidden'))renderRepairList();
  else updateMaintBadges();
  const adminPanel=document.getElementById('adminMaintPanel');
  if(adminPanel && !adminPanel.classList.contains('hidden'))renderAdminRepairList();
  else updateAdminMaintBadge();
  const histPanel=document.getElementById('adminHistoryPanel');
  if(histPanel && !histPanel.classList.contains('hidden'))renderAdminHistory();
  else updateHistoryBadge();
}

// ══════════════════════════════════════════════════════════════════════════
// ── รายการเปลี่ยนถ่ายของเหลว (Fluid change logs) ────────────────────────────
// ══════════════════════════════════════════════════════════════════════════
const FLUID_TYPES={
  engine_oil:{label:'น้ำมันเครื่อง',emoji:'🛢️'},
  gear_oil:{label:'น้ำมันเกียร์',emoji:'⚙️'},
  brake_fluid:{label:'น้ำมันเบรก/คลัตช์',emoji:'🛑'},
  coolant:{label:'น้ำยาหล่อเย็น/หม้อน้ำ',emoji:'❄️'},
  power_steering:{label:'น้ำมันพวงมาลัยเพาเวอร์',emoji:'🔄'},
  battery_water:{label:'น้ำกลั่นแบตเตอรี่',emoji:'🔋'},
  other:{label:'อื่นๆ',emoji:'🔧'}
};
function fmtDate(d){if(!d)return'-';try{return new Date(d+'T00:00:00').toLocaleDateString('th-TH',{day:'numeric',month:'short',year:'numeric'});}catch(e){return d;}}
function todayStr(){const d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');}

function openFluidModal(){
  if(!currentUser)return;
  document.getElementById('fluidForm').classList.add('hidden');
  document.getElementById('fluidFormToggleBtn').textContent='+ บันทึกการเปลี่ยนถ่ายใหม่';
  document.getElementById('fluType').value='engine_oil';
  document.getElementById('fluDate').value=todayStr();
  document.getElementById('fluOdo').value='';
  document.getElementById('fluNote').value='';
  renderFluidList();
  const m=document.getElementById('fluidModal');
  m.classList.remove('hidden');m.style.display='flex';
}
function closeFluidModal(){
  const m=document.getElementById('fluidModal');
  m.classList.add('hidden');m.style.display='none';
}
function toggleFluidForm(){
  const f=document.getElementById('fluidForm');
  if(f.classList.contains('hidden'))document.getElementById('fluDate').value=document.getElementById('fluDate').value||todayStr();
  const open=f.classList.toggle('hidden');
  document.getElementById('fluidFormToggleBtn').textContent=open?'+ บันทึกการเปลี่ยนถ่ายใหม่':'✕ ยกเลิก';
  if(open){_fluNewPhotos=[];renderNewFluidPhotos();} // ปิดฟอร์ม (ยกเลิก) → ล้างรูปที่เลือกค้างไว้
}
// พนักงานเลือกรูปแนบตอนบันทึกการเปลี่ยนถ่ายของเหลว (ย่อก่อนเก็บไว้ใน staging)
async function addNewFluidPhotos(input){
  const files=Array.from(input.files||[]);
  input.value='';
  if(!files.length)return;
  const room=3-_fluNewPhotos.length;
  if(room<=0){alert('⚠️ แนบได้สูงสุด 3 รูป');return;}
  const take=files.slice(0,room);
  if(files.length>room)alert(`⚠️ แนบได้อีก ${room} รูป (สูงสุด 3 รูป)`);
  try{
    for(const f of take){
      const dataUrl=await _compressImage(f,900,0.6);
      _fluNewPhotos.push(dataUrl);
    }
    renderNewFluidPhotos();
  }catch(e){console.error('compress error',e);alert('❌ '+((e&&e.message&&/[ก-๙]/.test(e.message))?e.message:'เพิ่มรูปไม่สำเร็จ ลองใหม่อีกครั้ง'));}
}
function delNewFluidPhoto(idx){_fluNewPhotos.splice(idx,1);renderNewFluidPhotos();}
function renderNewFluidPhotos(){
  const box=document.getElementById('fluNewImgPreview');
  if(!box)return;
  box.innerHTML=_fluNewPhotos.map((p,i)=>`<div style="position:relative;">
    <img src="${p}" style="width:72px;height:72px;object-fit:cover;border-radius:8px;border:1px solid #E8EAF0;">
    <button type="button" onclick="delNewFluidPhoto(${i})" style="position:absolute;top:-6px;right:-6px;background:#EF4444;color:#fff;border:none;border-radius:50%;width:22px;height:22px;font-size:13px;line-height:1;cursor:pointer;box-shadow:0 1px 4px rgba(0,0,0,.3);">✕</button>
  </div>`).join('');
}
async function doAddFluid(){
  if(!currentUser)return;
  const type=document.getElementById('fluType').value;
  const date=document.getElementById('fluDate').value||todayStr();
  const odo=document.getElementById('fluOdo').value.trim();
  const note=document.getElementById('fluNote').value.trim();
  const me=employees.find(e=>e.id===currentUser.id)||currentUser;
  const hasPhotos=_fluNewPhotos.length>0;
  let photoIds=[];
  if(hasPhotos){
    showDocUploadPopup('กำลังส่งรูป','กรุณารอสักครู่ อย่าเพิ่งปิดหน้านี้');
    try{
      photoIds=await uploadPhotos(_fluNewPhotos);
    }catch(e){
      hideDocUploadPopup();
      alert('❌ ส่งรูปไม่สำเร็จ (เน็ตช้า/หลุด) กรุณาลองใหม่อีกครั้ง — ข้อมูลที่กรอกไว้ยังอยู่ครบ');
      return;
    }
  }
  fluidLogs.unshift({
    id:'flu_'+Date.now(),
    empId:me.id,empName:me.name,plate:me.plate||'',
    fluidType:type,changedAt:date,odometer:odo,note,
    photos:photoIds,
    createdAt:new Date().toISOString()
  });
  try{
    await saveFluid();
    if(hasPhotos){hideDocUploadPopup();showDocUploadToast('✅ บันทึกสำเร็จ',true);}
  }catch(e){
    console.warn('doAddFluid: บันทึกไม่สำเร็จในทันที รอคิวส่งซ้ำอัตโนมัติ',e);
    hideDocUploadPopup();
    showDocUploadToast('⚠️ เน็ตช้า/หลุดอยู่ — ระบบจะส่งข้อมูลนี้ต่อให้อัตโนมัติเมื่อสัญญาณกลับมา',false);
  }
  document.getElementById('fluOdo').value='';
  document.getElementById('fluNote').value='';
  _fluNewPhotos=[];renderNewFluidPhotos();
  toggleFluidForm();
  refreshFluidViews();
}
function renderFluidList(){
  const el=document.getElementById('fluidList');
  if(!el||!currentUser)return;
  const mine=fluidLogs.filter(f=>f.empId===currentUser.id).sort((a,b)=>new Date(b.changedAt)-new Date(a.changedAt));
  if(!mine.length){
    el.innerHTML='<div class="maint-empty"><div class="empty-icon">'+skeIcon('oil')+'</div><div>ยังไม่มีบันทึกการเปลี่ยนถ่าย</div></div>';
    updateMaintBadges();
    return;
  }
  el.innerHTML=mine.map(f=>{
    const ft=FLUID_TYPES[f.fluidType]||FLUID_TYPES.other;
    return`<div class="maint-card">
      <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;">
        <div style="color:#1a1a2e;font-size:13.5px;font-weight:700;">${ft.emoji} ${esc(ft.label)}</div>
        <span style="color:#7B2FBE;font-size:11.5px;font-weight:700;">📅 ${fmtDate(f.changedAt)}</span>
      </div>
      ${f.odometer?`<div style="color:#888;font-size:12px;margin-top:6px;">🧭 เลขไมล์: ${esc(f.odometer)} กม.</div>`:''}
      ${f.note?`<div style="color:#666;font-size:12px;margin-top:4px;">${skeIcon('note')} ${esc(f.note)}</div>`:''}
      ${(f.photos&&f.photos.length)?`<div style="margin-top:8px;display:flex;gap:6px;flex-wrap:wrap;">
        ${f.photos.map((p,i)=>`<img data-ph="${p}" onclick="viewFluidPhoto('${f.id}',${i})" style="width:72px;height:72px;object-fit:cover;border-radius:8px;border:1px solid #E8EAF0;cursor:pointer;">`).join('')}
      </div>`:''}
      <div style="display:flex;align-items:center;justify-content:flex-end;margin-top:10px;">
        <span style="color:#16A34A;font-size:11px;font-weight:700;">✅ บันทึกแล้ว — เปลี่ยนถ่ายเรียบร้อย</span>
      </div>
    </div>`;
  }).join('');
  updateMaintBadges();
}
// รีเฟรชทุกหน้าที่อาจกำลังแสดงรายการเปลี่ยนถ่ายของเหลวอยู่ (หน้าพนักงาน + แผงผู้ดูแล)
function refreshFluidViews(){
  const empModal=document.getElementById('fluidModal');
  if(empModal && !empModal.classList.contains('hidden'))renderFluidList();
  else updateMaintBadges();
  const fluidHistPanel=document.getElementById('adminFluidHistoryPanel');
  if(fluidHistPanel && !fluidHistPanel.classList.contains('hidden'))renderAdminFluidHistory();
}

// ══════════════════════════════════════════════════════════════════════════
// ── เบิกเงินพนักงาน (Cash requisition) — เปิดให้กรอกเฉพาะวันที่ 15 ของทุกเดือน ──
// ══════════════════════════════════════════════════════════════════════════
function isCashDayOpen(){return new Date().getDate()===15;}
function nextCashDateLabel(){
  const now=new Date();
  let y=now.getFullYear(),m=now.getMonth();
  if(now.getDate()>=15){m+=1;if(m>11){m=0;y+=1;}}
  return new Date(y,m,15).toLocaleDateString('th-TH',{day:'numeric',month:'long',year:'numeric'});
}
// ── แจ้งลาพนักงาน — กรอกคำขอได้ทุกเมื่อ แต่วันที่ลาต้องอยู่ในช่วง 16-25 ของเดือนเท่านั้น (ตรวจใน doRequestLeave/_isLeaveDayAllowed) ──
function fmtBaht(n){const num=Number(n)||0;return num.toLocaleString('th-TH',{minimumFractionDigits:0,maximumFractionDigits:2});}
// แสดงรูปบิลที่แนบไว้ในคำขอเบิกเงิน — รองรับทั้งแบบหลายรูป (s.photos array แบบใหม่) และรูปเดียว (s.photo แบบเก่าก่อนอัปเดต)
function _cashPhotosHTML(s,maxH){
  const ids=Array.isArray(s.photos)&&s.photos.length?s.photos:(s.photo?[s.photo]:[]);
  if(!ids.length)return'';
  return `<div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px;">${ids.map(id=>
    `<img data-ph="${esc(id)}" onclick="openPhotoViewer('${esc(id)}')" style="width:${maxH}px;height:${maxH}px;object-fit:cover;border-radius:8px;border:1px solid #E8EAF0;cursor:pointer;">`
  ).join('')}</div>`;
}
function openCashModal(){
  if(!currentUser)return;
  document.getElementById('cashForm').classList.add('hidden');
  document.getElementById('cashFormToggleBtn').textContent='+ เบิกเงินใหม่';
  document.getElementById('cashAmount').value='';
  document.getElementById('cashReason').value='';
  document.getElementById('tollAmount').value='';
  document.getElementById('tollReason').value='';
  document.getElementById('tollPhotoInput').value='';
  _tollNewPhotos=[];
  renderNewTollPhotos();
  renderCashDayNotice();
  renderCashList();
  const m=document.getElementById('cashModal');
  m.classList.remove('hidden');m.style.display='flex';
}
function closeCashModal(){
  const m=document.getElementById('cashModal');
  m.classList.add('hidden');m.style.display='none';
}
function renderCashDayNotice(){
  const el=document.getElementById('cashDayNotice');
  const btn=document.getElementById('cashFormToggleBtn');
  if(!el)return;
  if(isCashDayOpen()){
    el.innerHTML=`<div style="background:#ECFDF5;border:1.5px solid #6EE7B7;border-radius:12px;padding:10px 12px;margin-bottom:12px;font-size:12px;color:#065F46;">✅ วันนี้เปิดให้กรอกคำขอเบิกเงิน</div>`;
    if(btn){btn.style.opacity='1';btn.style.pointerEvents='auto';}
  }else{
    el.innerHTML=`<div style="background:#FFFBEB;border:1.5px solid #FCD34D;border-radius:12px;padding:10px 12px;margin-bottom:12px;font-size:12px;color:#92400E;">🔒 เปิดให้กรอกคำขอเบิกเงินเฉพาะวันที่ 15 ของทุกเดือนเท่านั้น<br>รอบถัดไป: <b>${nextCashDateLabel()}</b></div>`;
    if(btn){btn.style.opacity='.5';btn.style.pointerEvents='none';}
    document.getElementById('cashForm').classList.add('hidden');
  }
}
function toggleCashForm(){
  if(!isCashDayOpen())return;
  const f=document.getElementById('cashForm');
  const open=f.classList.toggle('hidden');
  document.getElementById('cashFormToggleBtn').textContent=open?'+ เบิกเงินใหม่':'✕ ยกเลิก';
}
function doAddCash(){
  if(!currentUser||!isCashDayOpen())return;
  const amount=parseFloat(document.getElementById('cashAmount').value);
  const reason=document.getElementById('cashReason').value.trim();
  if(!amount||amount<=0){document.getElementById('cashAmount').focus();return;}
  if(!reason){document.getElementById('cashReason').focus();return;}
  const me=employees.find(e=>e.id===currentUser.id)||currentUser;
  cashRequests.unshift({
    id:'cash_'+Date.now(),
    empId:me.id,empName:me.name,plate:me.plate||'',
    amount,reason,status:'pending',requestType:'general',
    createdAt:new Date().toISOString()
  });
  saveCash();
  document.getElementById('cashAmount').value='';
  document.getElementById('cashReason').value='';
  toggleCashForm();
  refreshCashViews();
}
// เก็บรูปบิลค่าทางด่วนที่เลือกไว้ชั่วคราว (ยังไม่อัพโหลดจนกว่าจะกดส่งจริง กันอัพรูปทิ้งเปล่าถ้าไม่ได้ส่งคำขอ) — แนบได้หลายรูป สูงสุด 5
let _tollNewPhotos=[];
async function addNewTollPhotos(input){
  const files=Array.from(input.files||[]);
  input.value='';
  if(!files.length)return;
  const room=5-_tollNewPhotos.length;
  if(room<=0){alert('⚠️ แนบได้สูงสุด 5 รูป');return;}
  const take=files.slice(0,room);
  if(files.length>room)alert(`⚠️ แนบได้อีก ${room} รูป (สูงสุด 5 รูป)`);
  for(const f of take){
    if(!f.type||!f.type.startsWith('image/')){alert('กรุณาแนบไฟล์รูปภาพเท่านั้น');continue;}
    if(f.size>12*1024*1024){alert('รูปภาพมีขนาดใหญ่เกินไป กรุณาเลือกรูปไม่เกิน 12 MB');continue;}
    try{
      const dataUrl=await compressMonthlyDocImage(f);
      _tollNewPhotos.push(dataUrl);
    }catch(e){alert('เตรียมรูปไม่สำเร็จ ลองใหม่อีกครั้ง');}
  }
  renderNewTollPhotos();
}
function delNewTollPhoto(idx){
  _tollNewPhotos.splice(idx,1);
  renderNewTollPhotos();
}
function renderNewTollPhotos(){
  const box=document.getElementById('tollPhotoPreviewWrap');
  if(!box)return;
  box.innerHTML=_tollNewPhotos.map((p,i)=>`<div style="position:relative;">
    <img src="${p}" style="width:72px;height:72px;object-fit:cover;border-radius:8px;border:1.5px solid #7DD3FC;">
    <button type="button" onclick="delNewTollPhoto(${i})" style="position:absolute;top:-6px;right:-6px;background:#EF4444;color:#fff;border:none;border-radius:50%;width:22px;height:22px;font-size:13px;line-height:1;cursor:pointer;box-shadow:0 1px 4px rgba(0,0,0,.3);">✕</button>
  </div>`).join('');
}
// เบิกค่าทางด่วน — แยกประเภทจากเบิกเงินทั่วไป เบิกได้ทุกเมื่อ ไม่ผูกกับวันที่ 15 แต่บังคับต้องแนบรูปบิลอย่างน้อย 1 รูปก่อนถึงจะส่งได้
async function doAddTollCash(){
  if(!currentUser)return;
  const amount=parseFloat(document.getElementById('tollAmount').value);
  const reason=document.getElementById('tollReason').value.trim();
  if(!amount||amount<=0){document.getElementById('tollAmount').focus();return;}
  if(!_tollNewPhotos.length){alert('⚠️ กรุณาแนบรูปบิล/ใบเสร็จค่าทางด่วนอย่างน้อย 1 รูปก่อนส่งคำขอ');return;}
  if(window._fbConnected===false){alert('⚠️ ตอนนี้เน็ตหลุดอยู่ กรุณาเช็คสัญญาณอินเทอร์เน็ตก่อนส่งคำขอ');return;}
  const me=employees.find(e=>e.id===currentUser.id)||currentUser;
  showDocUploadPopup('กำลังส่งคำขอเบิกค่าทางด่วน',`กำลังอัปโหลดรูปบิล ${_tollNewPhotos.length} รูป กรุณารอสักครู่`);
  const photoIds=await uploadPhotos(_tollNewPhotos);
  cashRequests.unshift({
    id:'cash_'+Date.now(),
    empId:me.id,empName:me.name,plate:me.plate||'',
    amount,reason:reason?('🛣️ ค่าทางด่วน: '+reason):'🛣️ ค่าทางด่วน',status:'pending',requestType:'toll',photos:photoIds,
    createdAt:new Date().toISOString()
  });
  saveCash();
  document.getElementById('tollAmount').value='';
  document.getElementById('tollReason').value='';
  document.getElementById('tollPhotoInput').value='';
  _tollNewPhotos=[];
  renderNewTollPhotos();
  refreshCashViews();
  hideDocUploadPopup();
  alert('✅ ส่งคำขอเบิกค่าทางด่วนแล้ว รอแอดมินอนุมัติ');
}
function renderCashList(){
  const el=document.getElementById('cashList');
  if(!el||!currentUser)return;
  const mine=cashRequests.filter(s=>s.empId===currentUser.id).sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt));
  if(!mine.length){
    el.innerHTML='<div class="maint-empty"><div class="empty-icon">'+skeIcon('money')+'</div><div>ยังไม่มีรายการเบิกเงิน</div></div>';
    updateMaintBadges();
    return;
  }
  el.innerHTML=mine.map(s=>{
    const done=s.status==='done';
    return`<div class="maint-card ${done?'fixed':''}">
      <div style="display:flex;align-items:baseline;justify-content:space-between;gap:8px;">
        <div style="color:#F47920;font-size:19px;font-weight:900;">฿${fmtBaht(s.amount)}</div>
      </div>
      <div style="color:#666;font-size:12.5px;margin-top:4px;line-height:1.6;white-space:pre-wrap;">${esc(s.reason)}</div>
      ${_cashPhotosHTML(s,84)}
      <div style="display:flex;align-items:center;justify-content:space-between;margin-top:10px;">
        <span class="pill" style="background:${done?'#ECFDF5':'#FFFBEB'};color:${done?'#065F46':'#92400E'};border:1px solid ${done?'#6EE7B7':'#FCD34D'};">${done?'✅ จ่ายแล้ว':'⏳ รอดำเนินการ'}</span>
        <span style="color:#aaa;font-size:11px;">${fmt(s.createdAt)}</span>
      </div>
      <div class="row-btns" style="margin-top:10px;">
        <button class="btn btn-red btn-sm" style="flex:1;" onclick="doDelCash('${s.id}')">🗑️ ลบรายการ</button>
      </div>
    </div>`;
  }).join('');
  updateMaintBadges();
}
function doDelCash(id){
  if(!confirm('ลบรายการเบิกเงินนี้?'))return;
  cashRequests=cashRequests.filter(s=>s.id!==id);
  saveCash();refreshCashViews();
}
function toggleCashStatus(id){
  cashRequests=cashRequests.map(s=>s.id===id?{...s,status:s.status==='done'?'pending':'done'}:s);
  saveCash();refreshCashViews();
}
// รีเฟรชทุกหน้าที่อาจกำลังแสดงรายการเบิกเงินอยู่ (หน้าพนักงาน + แผงผู้ดูแล)
function refreshCashViews(){
  const empModal=document.getElementById('cashModal');
  if(empModal && !empModal.classList.contains('hidden')){renderCashDayNotice();renderCashList();}
  else updateMaintBadges();
  const adminPanel=document.getElementById('adminCashPanel');
  if(adminPanel && !adminPanel.classList.contains('hidden'))renderAdminCashList();
  else updateAdminCashBadge();
}

// ── อัพเดทตัวเลขสรุปบนการ์ดลัด แจ้งซ่อม/เปลี่ยนถ่าย/เบิกเงิน ในหน้าหลัก ────────
function updateMaintBadges(){
  if(!currentUser)return;
  const repSub=document.getElementById('repairSub');
  const repDot=document.getElementById('repairDot');
  if(repSub){
    const mineRep=repairs.filter(r=>r.empId===currentUser.id);
    const pending=mineRep.filter(r=>r.status!=='done').length;
    repSub.textContent=mineRep.length===0?'ไม่มีรายการ':(pending>0?`รอดำเนินการ ${pending} รายการ`:'ซ่อมเสร็จครบแล้ว');
    repSub.className='quick-card-sub'+(pending>0?' alert':'');
    if(repDot){
      if(pending>0){repDot.textContent=pending;repDot.classList.remove('hidden');}
      else repDot.classList.add('hidden');
    }
  }
  const fluSub=document.getElementById('fluidSub');
  if(fluSub){
    const mineFlu=fluidLogs.filter(f=>f.empId===currentUser.id).sort((a,b)=>new Date(b.changedAt)-new Date(a.changedAt));
    fluSub.textContent=mineFlu.length===0?'ยังไม่มีบันทึก':`ล่าสุด ${fmtDate(mineFlu[0].changedAt)}`;
  }
  const cashSub=document.getElementById('cashSub');
  const cashDot=document.getElementById('cashDot');
  if(cashSub){
    const mineCash=cashRequests.filter(s=>s.empId===currentUser.id);
    const pendingCash=mineCash.filter(s=>s.status!=='done').length;
    const dayOpen=isCashDayOpen();
    cashSub.textContent=pendingCash>0?`รอดำเนินการ ${pendingCash} รายการ`:(dayOpen?'📅 เปิดให้กรอกวันนี้!':(mineCash.length===0?'ยังไม่มีรายการ':'จ่ายครบแล้ว'));
    cashSub.className='quick-card-sub'+((pendingCash>0||dayOpen)?' alert':'');
    if(cashDot){
      if(pendingCash>0){cashDot.textContent=pendingCash;cashDot.classList.remove('hidden');}
      else cashDot.classList.add('hidden');
    }
  }
}

// ══════════════════════════════════════════════════════════════════════════
// ── ระบบ "seen" — badge แสดงเฉพาะรายการใหม่ที่ยังไม่เคยเปิดดู ────────────
// ══════════════════════════════════════════════════════════════════════════
const _SEEN_KEYS = { repair:'ske_seen_repair', cash:'ske_seen_cash', leave:'ske_seen_leave' };

function _loadSeen(type){ try{return new Set(JSON.parse(localStorage.getItem(_SEEN_KEYS[type])||'[]'));}catch{return new Set();} }
function _saveSeen(type,set){ localStorage.setItem(_SEEN_KEYS[type], JSON.stringify([...set])); }

// เรียกตอนเปิดหน้านั้น → mark รายการปัจจุบันทั้งหมดว่าเห็นแล้ว → badge หาย
function markSeenRepairs(){
  const seen=_loadSeen('repair');
  repairs.filter(r=>!isRepairResolved(r)).forEach(r=>seen.add(r.id));
  _saveSeen('repair',seen);
  updateAdminMaintBadge();
}
function markSeenCash(){
  const seen=_loadSeen('cash');
  cashRequests.filter(s=>s.status!=='done').forEach(s=>seen.add(s.id));
  _saveSeen('cash',seen);
  updateAdminCashBadge();
}
function markSeenLeave(){
  const seen=_loadSeen('leave');
  employees.filter(e=>e.onLeave).forEach(e=>seen.add(e.id+'_'+e.leaveAt));
  _saveSeen('leave',seen);
  updateLeaveBadge();
}

// นับเฉพาะรายการที่ยังไม่เคย seen
function _countNewRepairs(){
  const seen=_loadSeen('repair');
  return repairs.filter(r=>!isRepairResolved(r)&&!seen.has(r.id)).length;
}
function _countNewCash(){
  const seen=_loadSeen('cash');
  return cashRequests.filter(s=>s.status!=='done'&&!seen.has(s.id)).length;
}
function _countNewLeave(){
  const seen=_loadSeen('leave');
  return employees.filter(e=>e.onLeave&&!seen.has(e.id+'_'+e.leaveAt)).length;
}

// ══════════════════════════════════════════════════════════════════════════
let _adminMaintTab='repair';

// หาชื่อ/ทะเบียนล่าสุดของพนักงานจากรายชื่อปัจจุบัน เผื่อถูกแก้ไขชื่อภายหลัง
// (ถ้าพนักงานถูกลบไปแล้ว ใช้ชื่อ/ทะเบียนที่บันทึกไว้ตอนแจ้งแทน)
function _empLookup(empId,fallbackName,fallbackPlate){
  const e=employees.find(x=>x.id===empId);
  return{name:e?e.name:(fallbackName||'(พนักงานที่ถูกลบ)'),plate:e?e.plate:(fallbackPlate||'')};
}

function renderAdminMaint(){
  renderAdminRepairList();
  updateAdminMaintBadge();
}

// รายการซ่อมที่ "จัดการเสร็จแล้ว" = ซ่อมเสร็จ (done) หรือ ไม่อนุมัติ (rejected) → ย้ายไปเก็บในประวัติ
// ที่เหลือ (รออนุมัติ/รอใบเสนอราคา/อนุมัติแล้วกำลังซ่อม) ยังถือว่ากำลังดำเนินการ คงอยู่ในแท็บซ่อมบำรุง
function isRepairResolved(r){return r.status==='done'||r.approval==='rejected';}

function updateAdminMaintBadge(){
  const badge=document.getElementById('maintTabBadge');
  const navBadge=document.getElementById('navMaintNavBadge');
  const pending=_countNewRepairs();
  [badge,navBadge].forEach(b=>{if(!b)return;if(pending>0){b.textContent=pending;b.classList.remove('hidden');}else b.classList.add('hidden');});
  updateHistoryBadge();
}
function updateHistoryBadge(){
  const badge=document.getElementById('historyCountBadge');
  if(badge){
    const n=repairs.filter(isRepairResolved).length;
    if(n>0){badge.textContent=n;badge.classList.remove('hidden');}
    else badge.classList.add('hidden');
  }
  const fbadge=document.getElementById('fluidHistCountBadge');
  if(fbadge){
    if(fluidLogs.length>0){fbadge.textContent=fluidLogs.length;fbadge.classList.remove('hidden');}
    else fbadge.classList.add('hidden');
  }
}

// ── ฟังก์ชัน render การ์ดซ่อมแต่ละใบ (ดีไซน์ใหม่แบบสะอาด / อ่านง่าย) ──────────────────
function _repairCardHTML(r){
  const done=r.status==='done';
  const urg=r.urgency==='urgent';
  const pill=repairStatusPill(r);
  const approved=r.approval==='approved';
  const rejected=r.approval==='rejected';
  const checking=r.approval==='checking_price';
  const pending=!r.approval||r.approval==='pending';
  const info=_empLookup(r.empId,r.empName,r.plate);
  const emp=employees.find(e=>e.id===r.empId);
  const panelId='rpanel_'+r.id;
  const dateText=r.createdAt?new Date(r.createdAt).toLocaleDateString('th-TH',{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'}):'';
  const showActions=!done&&!rejected&&(pending||checking||approved);
  const statusOnly=approved&&!checking&&!pending;
  return `<div class="maint-card admin-maint-card-v2" data-repair-id="${r.id}" style="background:#fff;border:1px solid #EEF0F6;border-radius:16px;margin-bottom:10px;padding:0;overflow:hidden;box-shadow:0 4px 14px rgba(15,23,42,.06);">
    <div style="display:flex;gap:12px;padding:14px 14px 10px;cursor:pointer;align-items:flex-start;" onclick="toggleRepairPanel('${r.id}')">
      <div class="avatar" style="width:56px;height:56px;font-size:17px;flex-shrink:0;border-radius:50%;box-shadow:0 2px 8px rgba(0,0,0,.10);overflow:hidden;">${avatarImg(emp,56)||esc(info.name.charAt(0))}</div>
      <div style="flex:1;min-width:0;">
        <div style="display:flex;align-items:center;gap:7px;min-width:0;">
          <div style="font-size:15px;font-weight:900;color:#111827;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${esc(info.name)}</div>
          ${urg&&!done?`<span style="background:#FFF1F2;color:#E11D48;border:1px solid #FDA4AF;border-radius:999px;padding:2px 9px;font-size:11px;font-weight:900;white-space:nowrap;">ด่วน</span>`:''}
        </div>
        <div style="font-size:12px;color:#8B95A7;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">🚛 ${esc(info.plate||'-')}</div>
        <div style="font-size:13px;font-weight:700;color:#273044;line-height:1.55;margin-top:8px;">${esc(r.issue)}</div>
      </div>
      <div style="display:flex;align-items:center;gap:8px;flex-shrink:0;">
        <div style="font-size:12px;color:#8B95A7;white-space:nowrap;">${esc(dateText)}</div>
        <span id="rpanel_arrow_${r.id}" style="color:#8B95A7;font-size:24px;line-height:1;transition:transform .2s;">›</span>
      </div>
    </div>
    <div style="display:flex;align-items:center;gap:8px;padding:0 14px 14px;">
      <span class="pill" style="background:${pill.bg};color:${pill.color};border:1px solid ${pill.border};font-size:12px;font-weight:900;border-radius:999px;padding:6px 11px;">${pill.text}</span>
      <div style="flex:1;"></div>
      ${showActions?`
        ${approved?`<button class="btn btn-sm btn-green" style="min-width:118px;border-radius:10px;font-size:12px;padding:7px 10px;background:#fff;color:#16A34A;border:1.5px solid #22C55E;" onclick="toggleRepairStatus('${r.id}');event.stopPropagation()">✓ ซ่อมเสร็จ</button>`:''}
        ${!approved?`<button class="btn btn-sm btn-green" style="min-width:104px;border-radius:10px;font-size:12px;padding:7px 10px;background:#fff;color:#16A34A;border:1.5px solid #22C55E;" onclick="setRepairApproval('${r.id}','approved');event.stopPropagation()">✓ อนุมัติ</button>`:''}
        <button class="btn btn-sm btn-purple" style="min-width:104px;border-radius:10px;font-size:12px;padding:7px 10px;background:#fff;color:#5B2BE0;border:1.5px solid #A78BFA;" onclick="setRepairApproval('${r.id}','checking_price');event.stopPropagation()">🔍 เสนอราคา</button>
        <button class="btn btn-sm btn-red" style="min-width:104px;border-radius:10px;font-size:12px;padding:7px 10px;background:#fff;color:#EF4444;border:1.5px solid #F87171;" onclick="setRepairApproval('${r.id}','rejected');event.stopPropagation()">✕ ไม่อนุมัติ</button>
      `:''}
    </div>
    <div id="${panelId}" style="display:none;border-top:1px solid #F1F5F9;background:#FBFCFF;">
      ${(r.empPhotos&&r.empPhotos.length)?`<div style="padding:12px 14px 0;">
        <div style="font-size:11px;color:#F47920;font-weight:900;margin-bottom:7px;">📷 รูปจากพนักงาน</div>
        <div style="display:flex;gap:7px;flex-wrap:wrap;">
          ${r.empPhotos.map((p,i)=>`<img data-ph="${p}" loading="lazy" decoding="async" onclick="viewRepairPhoto('${r.id}',${i},'empPhotos')" style="width:70px;height:70px;object-fit:cover;border-radius:10px;border:1px solid #FED7AA;cursor:pointer;">`).join('')}
        </div>
      </div>`:''}
      ${r.reply?`<div style="margin:12px 14px 0;background:#EFF6FF;border:1px solid #BFDBFE;border-radius:12px;padding:10px 12px;">
        <div style="font-size:11px;color:#1E90D6;font-weight:900;margin-bottom:4px;">💬 ข้อความถึงพนักงาน${r.replyAt?` · ${fmt(r.replyAt)}`:''}</div>
        <div style="font-size:13px;color:#1a1a2e;line-height:1.55;white-space:pre-wrap;">${esc(r.reply)}</div>
      </div>`:''}
      ${(r.photos&&r.photos.length)?`<div style="padding:12px 14px 0;display:flex;gap:7px;flex-wrap:wrap;">
        ${r.photos.map((p,i)=>`<img data-ph="${p}" loading="lazy" decoding="async" onclick="viewRepairPhoto('${r.id}',${i})" style="width:70px;height:70px;object-fit:cover;border-radius:10px;border:1px solid #E8EAF0;cursor:pointer;">`).join('')}
      </div>`:''}
      <div style="padding:12px 14px;">
        <textarea class="inp" id="rep_reply_${r.id}" rows="2" placeholder="ส่งข้อความถึงพนักงาน เช่น นำรถเข้าศูนย์วันจันทร์ / สั่งอะไหล่แล้ว..." style="font-size:12.5px;margin-bottom:8px;">${esc(r.reply||'')}</textarea>
        <input type="file" id="rep_img_${r.id}" accept="image/*" multiple style="display:none;" onchange="addRepairPhotos('${r.id}',this)">
        <div class="row-btns" style="gap:8px;">
          <button class="btn btn-gray btn-sm" style="flex:1;border-radius:10px;" onclick="document.getElementById('rep_img_${r.id}').click()">📎 แนบรูป${(r.photos&&r.photos.length)?` (${r.photos.length})`:''}</button>
          <button class="btn btn-blue btn-sm" style="flex:2;border-radius:10px;" onclick="saveRepairReply('${r.id}')">💬 ${(r.reply||(r.photos&&r.photos.length))?'อัพเดท':'ส่งถึงพนักงาน'}</button>
          <button class="btn btn-red btn-sm" style="width:44px;border-radius:10px;padding:0;" onclick="doDelRepair('${r.id}')">🗑️</button>
        </div>
      </div>
    </div>
  </div>`;
}

// toggle accordion panel ของ repair card
function toggleRepairPanel(id){
  const panel=document.getElementById('rpanel_'+id);
  const arrow=document.getElementById('rpanel_arrow_'+id);
  if(!panel)return;
  const open=panel.style.display==='none'||panel.style.display==='';
  panel.style.display=open?'block':'none';
  if(arrow)arrow.style.transform=open?'rotate(90deg)':'rotate(0deg)';
}

let _repairStatusFilter='all';
let _repairSort='new';
let _adminRepairVisible=12;
function _sortActiveRepairs(items){
  const arr=[...items];
  if(_repairSort==='urgent'){
    arr.sort((a,b)=>(a.urgency==='urgent'?0:1)-(b.urgency==='urgent'?0:1)||new Date(b.createdAt)-new Date(a.createdAt));
  }else{
    arr.sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt));
  }
  return arr;
}
function setRepairSort(v){_repairSort=v||'new';_adminRepairVisible=12;switchRepairFilter(_repairStatusFilter);}
function switchRepairFilter(f,loadMore){
  if(!loadMore && f!==_repairStatusFilter)_adminRepairVisible=12;
  _repairStatusFilter=f;
  ['all','pending','checking_price','approved'].forEach(k=>{
    const b=document.getElementById('rfTab_'+k);
    if(!b)return;
    if(f===k){b.style.background='#5B2BE0';b.style.color='#fff';b.style.borderColor='#5B2BE0';b.style.fontWeight='900';}
    else{b.style.background='#fff';b.style.color='#5B6475';b.style.borderColor='#E8EAF0';b.style.fontWeight='700';}
  });
  const activeRepairs=repairs.filter(r=>!isRepairResolved(r));
  let filtered=activeRepairs;
  if(f==='pending')filtered=activeRepairs.filter(r=>!r.approval||r.approval==='pending');
  else if(f==='checking_price')filtered=activeRepairs.filter(r=>r.approval==='checking_price');
  else if(f==='approved')filtered=activeRepairs.filter(r=>r.approval==='approved');
  filtered=_sortActiveRepairs(filtered);
  const groupsEl=document.getElementById('adminRepairGroups');
  if(!groupsEl)return;
  if(!activeRepairs.length){groupsEl.innerHTML='<div class="empty-state"><div class="empty-icon">'+skeIcon('wrench')+'</div><div class="empty-text">ไม่มีรายการที่กำลังดำเนินการ<br><span style="font-size:11px;color:#aaa;">รายการที่เสร็จแล้วดูได้ในประวัติ</span></div></div>';return;}
  if(!filtered.length){groupsEl.innerHTML='<div style="text-align:center;padding:32px 0;color:#aaa;"><div style="font-size:32px;margin-bottom:8px;">🔍</div><div style="font-size:13px;">ไม่มีรายการในกลุ่มนี้</div></div>';return;}
  const title=f==='all'?'รายการแจ้งซ่อม':(f==='pending'?'รอตรวจสอบ':(f==='checking_price'?'รอใบเสนอราคา':'อนุมัติแล้ว'));
  const view=filtered.slice(0,_adminRepairVisible);
  groupsEl.innerHTML=`<div style="display:flex;align-items:center;justify-content:space-between;margin:4px 2px 10px;gap:10px;">
    <div style="font-weight:900;color:#111827;font-size:16px;">${title} (${filtered.length})</div>
    <select class="inp" onchange="setRepairSort(this.value)" style="width:auto;min-width:128px;padding:8px 12px;border-radius:12px;font-size:13px;background:#fff;">
      <option value="new" ${_repairSort==='new'?'selected':''}>ล่าสุดก่อน</option>
      <option value="urgent" ${_repairSort==='urgent'?'selected':''}>ด่วนก่อน</option>
    </select>
  </div>`+view.map(_repairCardHTML).join('')+(filtered.length>_adminRepairVisible?`<button class="btn btn-gray btn-full" style="margin-top:10px;border-radius:14px;" onclick="_adminRepairVisible+=12;switchRepairFilter(_repairStatusFilter,true)">โหลดเพิ่ม ${Math.min(12,filtered.length-_adminRepairVisible)} รายการ</button>`:'');
}

function renderAdminRepairList(){
  const statsEl=document.getElementById('adminRepairStats');
  const groupsEl=document.getElementById('adminRepairGroups');
  if(!statsEl||!groupsEl)return;
  const activeRepairs=repairs.filter(r=>!isRepairResolved(r));
  const nPending=activeRepairs.filter(r=>!r.approval||r.approval==='pending').length;
  const nChecking=activeRepairs.filter(r=>r.approval==='checking_price').length;
  const nApproved=activeRepairs.filter(r=>r.approval==='approved').length;
  const nUrgent=activeRepairs.filter(r=>r.urgency==='urgent').length;
  statsEl.innerHTML=`<div style="background:#fff;border:1px solid #E8EAF0;border-radius:16px;margin-bottom:14px;box-shadow:0 4px 14px rgba(15,23,42,.05);overflow:hidden;">
    <div style="display:grid;grid-template-columns:repeat(5,1fr);">
      <button id="rfTab_all" onclick="switchRepairFilter('all')" style="padding:12px 4px;border:0;border-right:1px solid #EDF0F5;background:#fff;cursor:pointer;">
        <div style="font-size:12px;font-weight:900;white-space:nowrap;">ทั้งหมด</div><div style="font-size:24px;font-weight:900;line-height:1.15;color:#5B2BE0;">${activeRepairs.length}</div>
      </button>
      <button id="rfTab_pending" onclick="switchRepairFilter('pending')" style="padding:12px 4px;border:0;border-right:1px solid #EDF0F5;background:#fff;cursor:pointer;">
        <div style="font-size:12px;color:#5B6475;white-space:nowrap;">🕐 รอตรวจสอบ</div><div style="font-size:24px;font-weight:900;line-height:1.15;color:#64748B;">${nPending}</div>
      </button>
      <button id="rfTab_checking_price" onclick="switchRepairFilter('checking_price')" style="padding:12px 4px;border:0;border-right:1px solid #EDF0F5;background:#fff;cursor:pointer;">
        <div style="font-size:12px;color:#5B6475;white-space:nowrap;">🔍 รอใบเสนอราคา</div><div style="font-size:24px;font-weight:900;line-height:1.15;color:#2563EB;">${nChecking}</div>
      </button>
      <button id="rfTab_approved" onclick="switchRepairFilter('approved')" style="padding:12px 4px;border:0;border-right:1px solid #EDF0F5;background:#fff;cursor:pointer;">
        <div style="font-size:12px;color:#5B6475;white-space:nowrap;">✅ อนุมัติแล้ว</div><div style="font-size:24px;font-weight:900;line-height:1.15;color:#16A34A;">${nApproved}</div>
      </button>
      <div style="padding:12px 4px;text-align:center;">
        <div style="font-size:12px;color:#5B6475;white-space:nowrap;">🔴 เร่งด่วน</div><div style="font-size:24px;font-weight:900;line-height:1.15;color:#EF4444;">${nUrgent}</div>
      </div>
    </div>
  </div>`;
  updateAdminMaintBadge();
  setTimeout(()=>switchRepairFilter(_repairStatusFilter),0);
}

// ── ประวัติการซ่อม — รายการที่ซ่อมเสร็จแล้ว หรือไม่อนุมัติ ──
function renderAdminHistory(){
  const el=document.getElementById('adminHistoryContent');
  if(!el)return;
  updateHistoryBadge();
  const resolved=repairs.filter(isRepairResolved);
  if(!resolved.length){
    el.innerHTML='<div class="empty-state"><div class="empty-icon">'+skeIcon('history')+'</div><div class="empty-text">ยังไม่มีประวัติ<br><span style="font-size:11px;color:#aaa;">รายการที่ซ่อมเสร็จหรือไม่อนุมัติจะมาแสดงที่นี่</span></div></div>';
    return;
  }
  const doneN=resolved.filter(r=>r.status==='done').length;
  const rejN=resolved.filter(r=>r.approval==='rejected'&&r.status!=='done').length;
  // จัดกลุ่มตามพนักงาน
  const byEmp={};
  resolved.forEach(r=>{(byEmp[r.empId]=byEmp[r.empId]||[]).push(r);});
  const groupArr=Object.entries(byEmp).map(([empId,items])=>{
    const info=_empLookup(empId,items[0].empName,items[0].plate);
    items.sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt));
    return{empId,name:info.name,plate:info.plate,items};
  }).sort((a,b)=>a.name.localeCompare(b.name,'th'));
  const stats=`<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-bottom:14px;">
    <div style="background:#fff;border-radius:14px;padding:10px 6px;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,.06);border:1.5px solid #E8EAF0;">
      <div style="font-size:22px;font-weight:900;color:#475569;">${resolved.length}</div>
      <div style="font-size:10px;color:#888;margin-top:2px;">📜 ทั้งหมด</div>
    </div>
    <div style="background:#F0FDF4;border-radius:14px;padding:10px 6px;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,.06);border:1.5px solid #86EFAC;">
      <div style="font-size:22px;font-weight:900;color:#10B981;">${doneN}</div>
      <div style="font-size:10px;color:#888;margin-top:2px;">✅ ซ่อมเสร็จ</div>
    </div>
    <div style="background:#FEF2F2;border-radius:14px;padding:10px 6px;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,.06);border:1.5px solid #FCA5A5;">
      <div style="font-size:22px;font-weight:900;color:#DC2626;">${rejN}</div>
      <div style="font-size:10px;color:#888;margin-top:2px;">❌ ไม่อนุมัติ</div>
    </div>
  </div>`;
  el.innerHTML=stats+groupArr.map(g=>`<div class="card" style="margin-bottom:12px;padding:14px;">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;">
        <div class="avatar" style="width:36px;height:36px;font-size:15px;">${esc(g.name.charAt(0))}</div>
        <div style="flex:1;min-width:0;">
          <div style="font-weight:700;color:#1a1a2e;font-size:13.5px;">${esc(g.name)}</div>
          <div style="color:#888;font-size:11px;">🚛 ${esc(g.plate||'-')}</div>
        </div>
        <span class="pill" style="background:#F1F5F9;color:#475569;border:1px solid #CBD5E1;">${g.items.length} รายการ</span>
      </div>
      ${g.items.map(r=>{
        const pill=repairStatusPill(r);
        return`<div class="maint-card fixed" style="margin-bottom:8px;opacity:.95;">
          <div style="color:#1a1a2e;font-size:13px;font-weight:600;line-height:1.5;">${esc(r.issue)}</div>
          ${(r.empPhotos&&r.empPhotos.length)?`<div style="margin-top:8px;display:flex;gap:6px;flex-wrap:wrap;">
            ${r.empPhotos.map((p,i)=>`<img data-ph="${p}" loading="lazy" decoding="async" onclick="viewRepairPhoto('${r.id}',${i},'empPhotos')" style="width:62px;height:62px;object-fit:cover;border-radius:8px;border:1px solid #FED7AA;cursor:pointer;">`).join('')}
          </div>`:''}
          ${r.reply?`<div style="margin-top:8px;background:#F1F5F9;border:1px solid #CBD5E1;border-radius:10px;padding:8px 10px;">
            <div style="font-size:10.5px;color:#475569;font-weight:700;margin-bottom:2px;">💬 ข้อความถึงพนักงาน</div>
            <div style="font-size:12.5px;color:#1a1a2e;line-height:1.5;white-space:pre-wrap;">${esc(r.reply)}</div>
          </div>`:''}
          ${(r.photos&&r.photos.length)?`<div style="margin-top:8px;display:flex;gap:6px;flex-wrap:wrap;">
            ${r.photos.map((p,i)=>`<img data-ph="${p}" loading="lazy" decoding="async" onclick="viewRepairPhoto('${r.id}',${i})" style="width:62px;height:62px;object-fit:cover;border-radius:8px;border:1px solid #E8EAF0;cursor:pointer;">`).join('')}
          </div>`:''}
          <div style="display:flex;align-items:center;justify-content:space-between;margin-top:8px;">
            <span class="pill" style="background:${pill.bg};color:${pill.color};border:1px solid ${pill.border};">${pill.text}</span>
            <span style="color:#aaa;font-size:10.5px;">${fmt(r.createdAt)}</span>
          </div>
          <div class="row-btns" style="margin-top:8px;">
            <button class="btn btn-gray btn-sm" style="flex:1;" onclick="restoreRepair('${r.id}')">↺ นำกลับมาดำเนินการ</button>
            <button class="btn btn-red btn-sm" onclick="doDelRepair('${r.id}')">🗑️</button>
          </div>
        </div>`;
      }).join('')}
    </div>`).join('');
}
// นำรายการในประวัติกลับมาที่แท็บซ่อมบำรุง (รีเซ็ตสถานะให้กลับมารอดำเนินการ)
function restoreRepair(id){
  const r=repairs.find(x=>x.id===id);if(!r)return;
  if(!confirm('นำรายการนี้กลับมาที่แท็บซ่อมบำรุงเพื่อดำเนินการต่อ?'))return;
  const patch={status:'open',approval:r.approval==='rejected'?'pending':r.approval,updatedAt:new Date().toISOString()};
  repairs=repairs.map(x=>x.id===id?{...x,...patch}:x);
  _cacheSet('ske_repairs', repairs);
  _patchRepair(id,patch);refreshRepairViews();
}

// ── ประวัติการเปลี่ยนถ่ายของเหลว (ผู้ดูแล) ─────────────────────────────────
function renderAdminFluidHistory(){
  const el=document.getElementById('adminFluidHistoryContent');
  if(!el)return;
  // อัปเดต badge
  const badge=document.getElementById('fluidHistCountBadge');
  if(badge){
    if(fluidLogs.length>0){badge.textContent=fluidLogs.length;badge.classList.remove('hidden');}
    else badge.classList.add('hidden');
  }
  if(!fluidLogs.length){
    el.innerHTML='<div class="empty-state"><div class="empty-icon">🛢️</div><div class="empty-text">ยังไม่มีบันทึกการเปลี่ยนถ่าย</div></div>';
    return;
  }
  // จัดกลุ่มตามพนักงาน
  const byEmp={};
  fluidLogs.forEach(f=>{(byEmp[f.empId]=byEmp[f.empId]||[]).push(f);});
  const groupArr=Object.entries(byEmp).map(([empId,items])=>{
    const info=_empLookup(empId,items[0].empName,items[0].plate);
    items.sort((a,b)=>new Date(b.changedAt)-new Date(a.changedAt));
    return{empId,name:info.name,plate:info.plate,items};
  }).sort((a,b)=>a.name.localeCompare(b.name,'th'));
  // stats summary
  const total=fluidLogs.length;
  const typeCount={};
  fluidLogs.forEach(f=>{typeCount[f.fluidType]=(typeCount[f.fluidType]||0)+1;});
  const topType=Object.entries(typeCount).sort((a,b)=>b[1]-a[1])[0];
  const topFt=topType?FLUID_TYPES[topType[0]]||FLUID_TYPES.other:null;
  const stats=`<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:14px;">
    <div style="background:#fff;border-radius:14px;padding:10px 8px;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,.06);border:1.5px solid #E8EAF0;">
      <div style="font-size:22px;font-weight:900;color:#7B2FBE;">${total}</div>
      <div style="font-size:10px;color:#888;margin-top:2px;">🛢️ บันทึกทั้งหมด</div>
    </div>
    <div style="background:#F5F3FF;border-radius:14px;padding:10px 8px;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,.06);border:1.5px solid #D8B4FE;">
      <div style="font-size:22px;font-weight:900;color:#7B2FBE;">${groupArr.length}</div>
      <div style="font-size:10px;color:#888;margin-top:2px;">👷 พนักงาน</div>
    </div>
  </div>
  ${topFt?`<div style="background:#FFFBEB;border:1px solid #FDE68A;border-radius:10px;padding:9px 12px;margin-bottom:14px;font-size:12px;color:#92400E;">
    🏆 เปลี่ยนถ่ายบ่อยที่สุด: <b>${topFt.emoji} ${topFt.label}</b> (${topType[1]} ครั้ง)
  </div>`:''}`;
  el.innerHTML=stats+groupArr.map(g=>`<div class="card" style="margin-bottom:12px;padding:14px;">
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;">
      <div class="avatar" style="width:36px;height:36px;font-size:15px;">${avatarImg(employees.find(e=>e.id===g.empId),36)||esc(g.name.charAt(0))}</div>
      <div style="flex:1;min-width:0;">
        <div style="font-weight:700;color:#1a1a2e;font-size:13.5px;">${esc(g.name)}</div>
        <div style="color:#888;font-size:11px;">🚛 ${esc(g.plate||'-')}</div>
      </div>
      <span class="pill" style="background:#F5F3FF;color:#7B2FBE;border:1px solid #D8B4FE;">${g.items.length} รายการ</span>
    </div>
    ${g.items.map(f=>{
      const ft=FLUID_TYPES[f.fluidType]||FLUID_TYPES.other;
      return`<div class="maint-card" style="margin-bottom:8px;">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;">
          <div style="color:#1a1a2e;font-size:13px;font-weight:700;">${ft.emoji} ${esc(ft.label)}</div>
          <span style="color:#7B2FBE;font-size:11px;font-weight:700;flex-shrink:0;">📅 ${fmtDate(f.changedAt)}</span>
        </div>
        ${f.odometer?`<div style="color:#888;font-size:12px;margin-top:5px;">🧭 เลขไมล์: <b>${esc(f.odometer)}</b> กม.</div>`:''}
        ${f.note?`<div style="color:#666;font-size:12px;margin-top:4px;">${skeIcon('note')} ${esc(f.note)}</div>`:''}
        ${(f.photos&&f.photos.length)?`<div style="margin-top:8px;display:flex;gap:6px;flex-wrap:wrap;">
          ${f.photos.map((p,i)=>`<img data-ph="${p}" onclick="viewFluidPhoto('${f.id}',${i})" style="width:68px;height:68px;object-fit:cover;border-radius:8px;border:1px solid #E8EAF0;cursor:pointer;">`).join('')}
        </div>`:''}
        <div style="display:flex;align-items:center;justify-content:space-between;margin-top:7px;">
          <span style="color:#aaa;font-size:10.5px;">บันทึกเมื่อ ${fmt(f.createdAt)}</span>
          <span style="color:#16A34A;font-size:10.5px;font-weight:700;white-space:nowrap;">✅ เปลี่ยนถ่ายแล้ว</span>
        </div>
      </div>`;
    }).join('')}
  </div>`).join('');
}

// หมายเหตุ: renderAdminFluidList() (แท็บ "เปลี่ยนถ่าย" คู่กับแจ้งซ่อม) ถูกลบออกแล้ว
// รายการเปลี่ยนถ่ายของเหลวดูได้ที่เดียวคือ "ประวัติการเปลี่ยนถ่าย" (renderAdminFluidHistory) เท่านั้น
// เพราะเป็นเหตุการณ์ที่เกิดขึ้นแล้วเสมอ ไม่มีสถานะค้าง/รอดำเนินการแบบแจ้งซ่อม

// ══════════════════════════════════════════════════════════════════════════
// ── แผงผู้ดูแล: รายการเบิกเงินพนักงานทุกคน ────────────────────────────────────
// ══════════════════════════════════════════════════════════════════════════
function updateAdminCashBadge(){
  const badge=document.getElementById('cashTabBadge');
  const navBadge=document.getElementById('navCashNavBadge');
  const pending=_countNewCash();
  [badge,navBadge].forEach(b=>{if(!b)return;if(pending>0){b.textContent=pending;b.classList.remove('hidden');}else b.classList.add('hidden');});
}

// ── ประวัติการเบิกเงินที่จ่ายครบแล้ว — แยกจากหน้าหลัก จัดกลุ่มตามเดือน ──
function renderCashHistory(){
  const el=document.getElementById('cashHistoryContent');
  if(!el)return;
  const done=cashRequests.filter(s=>s.status==='done').sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt));
  if(!done.length){
    el.innerHTML='<div class="empty-state"><div class="empty-icon">'+skeIcon('money')+'</div><div class="empty-text">ยังไม่มีประวัติการเบิกเงินที่จ่ายแล้ว</div></div>';
    return;
  }
  const byMonth={};
  done.forEach(s=>{
    const d=new Date(s.createdAt);
    const mk=isNaN(d.getTime())?'ไม่ระบุวันที่':`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`;
    (byMonth[mk]=byMonth[mk]||[]).push(s);
  });
  const monthKeys=Object.keys(byMonth).sort().reverse();
  const canDel=adminRole!=='viewer';
  el.innerHTML=monthKeys.map(mk=>{
    const items=byMonth[mk];
    const total=items.reduce((sum,s)=>sum+(Number(s.amount)||0),0);
    const label=mk==='ไม่ระบุวันที่'?mk:fmtJobMonthLabel(mk);
    return `<div style="margin-bottom:18px;">
      <div style="background:#F5F3FF;border-radius:10px;padding:10px 14px;margin-bottom:8px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px;">
        <span style="font-weight:800;color:#6C3FE8;font-size:13px;">🗓️ ${label}</span>
        <span style="font-weight:800;color:#F47920;font-size:13px;">฿${fmtBaht(total)} (${items.length} รายการ)</span>
      </div>
      ${items.map(s=>`<div class="maint-card fixed" style="margin-bottom:8px;">
        <div style="font-weight:700;color:#1a1a2e;font-size:13px;">${esc(s.empName||'-')} <span style="color:#888;font-weight:400;">· 🚛 ${esc(s.plate||'-')}</span></div>
        <div style="color:#F47920;font-size:16px;font-weight:900;margin-top:2px;">฿${fmtBaht(s.amount)}</div>
        <div style="color:#666;font-size:12px;margin-top:3px;line-height:1.6;white-space:pre-wrap;">${esc(s.reason)}</div>
        ${_cashPhotosHTML(s,72)}
        <div style="display:flex;align-items:center;justify-content:space-between;margin-top:8px;">
          <span class="pill" style="background:#ECFDF5;color:#065F46;border:1px solid #6EE7B7;">✅ จ่ายแล้ว</span>
          <span style="color:#aaa;font-size:10.5px;">${fmt(s.createdAt)}</span>
        </div>
        ${canDel?`<button class="btn btn-gray btn-sm btn-full" style="margin-top:8px;" onclick="toggleCashStatus('${s.id}');switchAdminTab('cash');">↺ เปิดอีกครั้ง (แก้ไขผิดพลาด)</button>`:''}
      </div>`).join('')}
    </div>`;
  }).join('');
}

// ลบรูปบิล/ใบเสร็จที่แนบไว้ในคำขอเบิกเงินทั้งหมดทีเดียว — ใช้หลังตรวจสอบแล้ว เพื่อประหยัดพื้นที่เก็บรูป
// ไม่ลบตัวรายการเบิกเงินออก แค่ลบรูปที่แนบออกจากคลังรูปเท่านั้น ข้อมูลจำนวนเงิน/เหตุผล/สถานะยังอยู่ครบ
async function doDeleteAllCashPhotos(){
  const withPhoto=cashRequests.filter(r=>r.photo||(Array.isArray(r.photos)&&r.photos.length));
  if(!withPhoto.length){alert('ไม่มีรูปบิลที่แนบไว้ในระบบตอนนี้');return;}
  const photoIds=withPhoto.flatMap(r=>[...(r.photo?[r.photo]:[]),...(Array.isArray(r.photos)?r.photos:[])]);
  if(!confirm(`ลบรูปบิล/ใบเสร็จที่แนบไว้ทั้งหมด ${photoIds.length} รูป (จาก ${withPhoto.length} รายการ)? (ข้อมูลรายการเบิกเงินยังอยู่ครบ ลบแค่รูปเท่านั้น ย้อนกลับไม่ได้)`))return;
  cashRequests=cashRequests.map(r=>(r.photo||(Array.isArray(r.photos)&&r.photos.length))?{...r,photo:'',photos:[]}:r);
  saveCash();
  if(window.fbDeletePhotos)window.fbDeletePhotos(photoIds);
  renderAdminCashList();
  renderCashHistory();
  alert(`✅ ลบรูปบิล ${photoIds.length} รูปเรียบร้อยแล้ว`);
}
function renderAdminCashList(){
  const statsEl=document.getElementById('adminCashStats');
  const groupsEl=document.getElementById('adminCashGroups');
  if(!statsEl||!groupsEl)return;
  const pendingItems=cashRequests.filter(s=>s.status!=='done');
  const totalPending=pendingItems.length;
  const totalPendingAmount=pendingItems.reduce((sum,s)=>sum+(Number(s.amount)||0),0);
  const dayOpen=isCashDayOpen();
  statsEl.innerHTML=`<div style="background:${dayOpen?'#ECFDF5':'#F5F6FA'};border:1.5px solid ${dayOpen?'#6EE7B7':'#E8EAF0'};border-radius:14px;padding:12px 14px;margin-bottom:12px;font-size:12.5px;color:${dayOpen?'#065F46':'#666'};">
      ${dayOpen?'✅ วันนี้เปิดให้พนักงานกรอกคำขอเบิกเงิน':'🔒 เปิดให้กรอกเฉพาะวันที่ 15 ของทุกเดือน — รอบถัดไป '+nextCashDateLabel()}
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:14px;">
      <div style="background:#fff;border-radius:14px;padding:12px;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,.06);border:1.5px solid ${totalPending>0?'#FCD34D':'#E8EAF0'};">
        <div style="font-size:26px;font-weight:900;color:${totalPending>0?'#92400E':'#1E90D6'};">${totalPending}</div>
        <div style="font-size:11px;color:#888;margin-top:2px;">⏳ รอดำเนินการ</div>
      </div>
      <div style="background:#fff;border-radius:14px;padding:12px;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,.06);border:1.5px solid ${totalPending>0?'#FCD34D':'#E8EAF0'};">
        <div style="font-size:20px;font-weight:900;color:${totalPending>0?'#92400E':'#1E90D6'};">฿${fmtBaht(totalPendingAmount)}</div>
        <div style="font-size:11px;color:#888;margin-top:2px;">${skeIcon('money')} ยอดรอจ่าย</div>
      </div>
    </div>`;
  updateAdminCashBadge();
  if(!cashRequests.length){groupsEl.innerHTML='<div class="empty-state"><div class="empty-icon">'+skeIcon('money')+'</div><div class="empty-text">ยังไม่มีรายการเบิกเงิน</div></div>';return;}

  // แสดงเฉพาะรายการที่ "ยังไม่จ่าย" ในหน้านี้ — รายการที่จ่ายครบแล้วจะถูกตัดออกไปเก็บไว้ที่ "ดูประวัติการเบิกเงิน" แทน
  const byEmp={};
  cashRequests.filter(s=>s.status!=='done').forEach(s=>{(byEmp[s.empId]=byEmp[s.empId]||[]).push(s);});
  const groupArr=Object.entries(byEmp).map(([empId,reqs])=>{
    const info=_empLookup(empId,reqs[0].empName,reqs[0].plate);
    reqs.sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt));
    return{empId,name:info.name,plate:info.plate,reqs,pending:reqs.length};
  }).sort((a,b)=>b.pending-a.pending||a.name.localeCompare(b.name,'th'));

  if(!groupArr.length){groupsEl.innerHTML='<div class="empty-state"><div class="empty-icon">✅</div><div class="empty-text">ไม่มีรายการค้างจ่าย<br><span style="font-size:11px;color:#aaa;">รายการที่จ่ายแล้วดูได้ที่ปุ่ม "ดูประวัติการเบิกเงิน" ด้านบน</span></div></div>';return;}

  groupsEl.innerHTML=groupArr.map(g=>`<div class="card" style="margin-bottom:12px;padding:14px;">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;">
        <div class="avatar" style="width:36px;height:36px;font-size:15px;">${esc(g.name.charAt(0))}</div>
        <div style="flex:1;min-width:0;">
          <div style="font-weight:700;color:#1a1a2e;font-size:13.5px;">${esc(g.name)}</div>
          <div style="color:#888;font-size:11px;">🚛 ${esc(g.plate||'-')}</div>
        </div>
        <span class="pill" style="background:#FFFBEB;color:#92400E;border:1px solid #FCD34D;">${g.pending} ค้าง</span>
      </div>
      ${g.reqs.map(s=>{
        return`<div class="maint-card" style="margin-bottom:8px;">
          <div style="color:#F47920;font-size:17px;font-weight:900;">฿${fmtBaht(s.amount)}</div>
          <div style="color:#666;font-size:12.5px;margin-top:3px;line-height:1.6;white-space:pre-wrap;">${esc(s.reason)}</div>
          ${_cashPhotosHTML(s,84)}
          <div style="display:flex;align-items:center;justify-content:space-between;margin-top:8px;">
            <span class="pill" style="background:#FFFBEB;color:#92400E;border:1px solid #FCD34D;">⏳ รอดำเนินการ</span>
            <span style="color:#aaa;font-size:10.5px;">${fmt(s.createdAt)}</span>
          </div>
          <div class="row-btns" style="margin-top:8px;">
            <button class="btn btn-green btn-sm" style="flex:1;" onclick="toggleCashStatus('${s.id}')">✓ จ่ายแล้ว</button>
            <button class="btn btn-red btn-sm" onclick="doDelCash('${s.id}')">🗑️</button>
          </div>
        </div>`;
      }).join('')}
    </div>`).join('');
}

// ── ปุ่มรีเฟรชหน้าจอผู้ดูแล ──────────────────────────────────────────────────
function refreshAdmin(){
  const btn=document.getElementById('adminRefreshBtn');
  if(btn){btn.style.transition='transform .6s ease';btn.style.transform='rotate(360deg)';setTimeout(()=>{btn.style.transition='';btn.style.transform='';},650);}
  const done=()=>{
    try{
      const f=JSON.parse(localStorage.getItem('ske_emp')||'[]');
      if(Array.isArray(f)&&f.length)employees=f;
    }catch(e){}
    renderAdmin();
  };
  if(window.fbForceRefresh)window.fbForceRefresh(done);
  else done();
}

// ── Province HTML ─────────────────────────────────────────────────────────────
function provHTML(sid,curProv){
  const titles={
    standby:`${skeIcon('pin')} จังหวัดที่สแตนบาย`,
    traveling:`🏁 จังหวัดปลายทาง`,
    returning:`🔁 จังหวัดที่กำลังไหลกลับผ่าน/ปลายทางขากลับ`,
    done:`${skeIcon('pin')} จังหวัดที่ว่างงาน`
  };
  const phs={
    standby:'พิมพ์ค้นหาจังหวัด...',
    traveling:'พิมพ์ค้นหาปลายทาง...',
    returning:'พิมพ์ค้นหาจังหวัด...',
    done:'พิมพ์ค้นหาจังหวัด...'
  };
  if(!titles[sid])return'';
  // ใช้ input+datalist แทน select เดิม เพื่อให้พิมพ์ค้นหาจังหวัดได้ (native select ธรรมดาเลื่อนหาอย่างเดียว)
  return`<div class="province-box"><div class="province-title">${titles[sid]}</div>
    <input class="province-sel inp" id="provSel" list="provinceDatalist" autocomplete="off"
      value="${esc(curProv||'')}" placeholder="${phs[sid]}"
      oninput="_selProv=this.value" onchange="_selProv=this.value"></div>`;
}
// สร้าง <datalist> รายชื่อจังหวัดทั้งหมดไว้ใช้ร่วมกันครั้งเดียว (ไม่ต้องสร้างซ้ำทุกครั้งที่เปิดฟอร์ม)
(function ensureProvinceDatalist(){
  if(document.getElementById('provinceDatalist'))return;
  const dl=document.createElement('datalist');
  dl.id='provinceDatalist';
  dl.innerHTML=PROVINCES.map(p=>`<option value="${p}"></option>`).join('');
  (document.body||document.documentElement).appendChild(dl);
})();
function isValidProvince(v){return PROVINCES.includes(String(v||'').trim());}

// ── Dashboard ─────────────────────────────────────────────────────────────────


// ══ MONTHLY DOCUMENT SUBMISSION (Employee page + Admin approval) ══
function _docMonthKey(d=new Date()){
  const y=d.getFullYear();
  const m=String(d.getMonth()+1).padStart(2,'0');
  return `${y}-${m}`;
}
function _docMonthTH(monthKey=_docMonthKey()){
  const [y,m]=(monthKey||_docMonthKey()).split('-').map(Number);
  return new Date(y,m-1,1).toLocaleDateString('th-TH',{month:'long',year:'numeric'});
}
function _docId(empId,monthKey=_docMonthKey()){return `${empId||'unknown'}_${monthKey}`;}
function isMonthlyDocWindowOpen(){const d=new Date().getDate();return d>=1&&d<=15;}
function getMonthlyDocSubmission(empId,monthKey=_docMonthKey()){
  return (monthlyDocs||[]).find(x=>x&&x.id===_docId(empId,monthKey))||null;
}
function getMonthlyDocStatus(empId,monthKey=_docMonthKey()){
  const r=getMonthlyDocSubmission(empId,monthKey);
  return r?String(r.status||'pending'):'missing';
}
function _docStatusPill(status){
  if(status==='approved')return {text:'✅ ส่วนกลางตรวจสอบเอกสารเรียบร้อยแล้ว',bg:'#ECFDF5',bd:'#10B981',color:'#065F46'};
  if(status==='rejected')return {text:'❌ เอกสารถูกไม่อนุมัติ กรุณาแนบรูปส่งใหม่',bg:'#FEF2F2',bd:'#EF4444',color:'#991B1B'};
  if(status==='pending')return {text:'🕐 รอส่วนกลางตรวจสอบเอกสาร',bg:'#FFFBEB',bd:'#F59E0B',color:'#92400E'};
  return {text:'🚨 ยังไม่ได้ส่งเอกสาร',bg:'#FEF2F2',bd:'#EF4444',color:'#991B1B'};
}
function renderMonthlyDocAlert(me){
  if(!me)return'';
  // เตือน/ให้ส่งเอกสารเฉพาะตำแหน่ง "พนักงานขับรถ" เท่านั้น — ตำแหน่งอื่นไม่ต้องส่งเอกสารเข้าส่วนกลาง เลยไม่ต้องเห็นป้ายนี้เลย
  if(!isDrivingPosition(me.position))return'';
  const monthKey=_docMonthKey();
  const rec=getMonthlyDocSubmission(me.id,monthKey);
  const monthTH=_docMonthTH(monthKey);
  const status=rec?String(rec.status||'pending'):'missing';
  // แสดงแจ้งเตือน/ส่งเอกสารเฉพาะวันที่ 1-15 ของทุกเดือนเท่านั้น
  // วันที่ 16 เป็นต้นไปจะไม่ขึ้นแถบแจ้งเตือนในหน้าพนักงาน
  if(!isMonthlyDocWindowOpen()) return '';
  const pill=_docStatusPill(status);
  const img=rec?.photo?`<div style="margin-top:8px;"><img data-ph="${rec.photo}" alt="รูปหลักฐานการส่งเอกสาร" style="max-width:100%;max-height:190px;border-radius:10px;border:1px solid ${pill.bd};object-fit:cover;"></div>`:'';
  if(status==='approved'){
    // อนุมัติแล้ว — ไม่ต้องเตือน/โชว์การ์ดซ้ำอีก ให้หายไปจากหน้าพนักงานเลย
    return '';
  }
  if(status==='pending'){
    return `<div style="margin-top:10px;padding:10px 12px;border-radius:12px;background:${pill.bg};border:1.5px solid ${pill.bd};color:${pill.color};">
      <div style="font-weight:900;font-size:13px;">${pill.text} (${esc(monthTH)})</div>
      <div style="font-size:12.5px;line-height:1.6;margin-top:4px;">แนบรูปแล้ว รอส่วนกลางกดอนุมัติ หากรูปไม่ชัดสามารถเปลี่ยนรูปใหม่ได้</div>
      <div style="font-size:12px;margin-top:3px;">ส่งเมื่อ: ${fmt(rec.submittedAt||rec.at||Date.now())}</div>
      ${img}
      <label class="btn btn-gray btn-full" style="margin-top:8px;font-size:12px;display:block;text-align:center;cursor:pointer;">เปลี่ยน/เลือกรูปจากแกลลอรี่<input type="file" accept="image/*" style="display:none;" onchange="handleMonthlyDocPhoto(event)"></label>
    </div>`;
  }
  const rejectedMsg=status==='rejected'?`<div style="font-weight:900;margin-top:5px;color:#DC2626;">❌ ส่วนกลางไม่อนุมัติ กรุณาแนบรูปใหม่</div>${rec?.rejectReason?`<div style="font-size:12px;margin-top:3px;">เหตุผล: ${esc(rec.rejectReason)}</div>`:''}`:'';
  return `<div class="emp-alert-compact">
    <div style="font-size:26px;line-height:1;">⚠️</div>
    <div class="alert-main">
      <div class="alert-title">แจ้งเตือน: ส่งเอกสารเข้าส่วนกลาง</div>
      <div class="alert-sub">กรุณาส่งเอกสารภายในวันที่ <b>1-15 ของทุกเดือน</b> และแนบรูปหลักฐานให้ครบถ้วน</div>
      ${rejectedMsg}
      <div style="font-size:11.5px;margin-top:4px;color:${isMonthlyDocWindowOpen()?'#B45309':'#DC2626'};font-weight:900;">${isMonthlyDocWindowOpen()?'อยู่ในช่วงส่งเอกสาร':'เลยกำหนดส่งเอกสารแล้ว'}</div>
      ${img}
    </div>
    <label class="emp-upload-btn">☁️ อัปโหลดหลักฐาน<input type="file" accept="image/*" style="display:none;" onchange="handleMonthlyDocPhoto(event)"></label>
  </div>`;
}
function showDocUploadPopup(title='กำลังอัปโหลดรูปเอกสาร', sub='กรุณารอสักครู่ อย่าเพิ่งปิดหน้านี้'){
  let el=document.getElementById('docUploadPopup');
  if(!el){
    el=document.createElement('div');
    el.id='docUploadPopup';
    el.className='doc-upload-pop';
    document.body.appendChild(el);
  }
  el.innerHTML=`<div class="doc-upload-card"><div class="doc-upload-spinner"></div><div class="doc-upload-title">${esc(title)}</div><div class="doc-upload-sub">${esc(sub)}</div></div>`;
  el.classList.remove('hidden');
}
function updateDocUploadPopup(title,sub){
  const el=document.getElementById('docUploadPopup');
  if(!el)return;
  const t=el.querySelector('.doc-upload-title');
  const s=el.querySelector('.doc-upload-sub');
  if(t)t.textContent=title||'';
  if(s)s.textContent=sub||'';
}
function hideDocUploadPopup(){
  const el=document.getElementById('docUploadPopup');
  if(el)el.classList.add('hidden');
}
function showDocUploadToast(msg,ok=true){
  let el=document.getElementById('docUploadToast');
  if(!el){el=document.createElement('div');el.id='docUploadToast';document.body.appendChild(el);}
  el.className='doc-upload-toast '+(ok?'ok':'err');
  el.textContent=msg;
  setTimeout(()=>{ if(el)el.remove(); }, ok?2600:4200);
}
async function compressMonthlyDocImage(file, maxSide=1280, quality=.78){
  const d=await _decodeImage(file);
  try{
    const w=d.w,h=d.h;
    if(!w||!h)throw new Error('ไฟล์รูปนี้เปิดอ่านไม่ได้ กรุณาลองเลือกรูปใหม่');
    const scale=Math.min(1, maxSide/Math.max(w,h));
    const canvas=document.createElement('canvas');
    canvas.width=Math.max(1,Math.round(w*scale));
    canvas.height=Math.max(1,Math.round(h*scale));
    canvas.getContext('2d').drawImage(d.src,0,0,canvas.width,canvas.height);
    let out=canvas.toDataURL('image/jpeg', quality);
    // ถ้ายังใหญ่เกินไป ลดขนาด/คุณภาพอีกรอบ เพื่อให้ Firebase RTDB บันทึกนิ่งขึ้นบนมือถือ
    if(out.length>900000){
      const scale2=Math.min(1, 950/Math.max(w,h));
      canvas.width=Math.max(1,Math.round(w*scale2));
      canvas.height=Math.max(1,Math.round(h*scale2));
      canvas.getContext('2d').drawImage(d.src,0,0,canvas.width,canvas.height);
      out=canvas.toDataURL('image/jpeg', .68);
    }
    return out;
  }finally{d.close();}
}
async function handleMonthlyDocPhoto(ev){
  const input=ev&&ev.target;
  try{
    if(!isMonthlyDocWindowOpen()){
      alert('ระบบเปิดให้ส่งเอกสารเฉพาะวันที่ 1-15 ของทุกเดือนเท่านั้น');
      if(input)input.value='';
      return;
    }
    const file=input?.files?.[0];
    if(!file)return;
    if(!file.type||!file.type.startsWith('image/')){alert('กรุณาแนบไฟล์รูปภาพเท่านั้น');return;}
    if(file.size>12*1024*1024){alert('รูปภาพมีขนาดใหญ่เกินไป กรุณาเลือกรูปไม่เกิน 12 MB');return;}
    const me=employees.find(e=>e.id===currentUser?.id)||currentUser;
    if(!me){alert('ไม่พบข้อมูลพนักงาน');return;}
    if(window._fbConnected===false){
      alert('⚠️ ตอนนี้เน็ตหลุดอยู่ กรุณาเช็คสัญญาณอินเทอร์เน็ตก่อนส่งเอกสาร');
      if(input)input.value='';
      return;
    }

    showDocUploadPopup('กำลังเตรียมรูปเอกสาร','กำลังบีบอัดรูปให้เหมาะกับการบันทึก');
    const photoData=await compressMonthlyDocImage(file);
    updateDocUploadPopup('กำลังส่งรูปขึ้นคลัง','กำลังส่งรูปไป Firebase กรุณารอสักครู่');
    const photoId=await uploadPhoto(photoData); // เข้าคลังรูป — ข้อมูลหลักเก็บแค่รหัส
    updateDocUploadPopup('กำลังบันทึกลงระบบ','อีกนิดเดียว กรุณารอสักครู่');

    const monthKey=_docMonthKey();
    const id=_docId(me.id,monthKey);
    const old=getMonthlyDocSubmission(me.id,monthKey)||{};
    const oldPhoto=old.photo; // รูปรอบก่อน (กรณีส่งซ้ำ/ถูกตีกลับ) — เดี๋ยวลบทิ้งจากคลังหลังบันทึกใหม่สำเร็จ
    const rec={...old,id,empId:me.id,empName:me.name||'',plate:me.plate||'',phone:me.phone||'',lineId:me.lineId||'',monthKey,photo:photoId,photoSize:photoData.length,submittedAt:Date.now(),status:'pending',reviewedAt:null,reviewedBy:null,rejectReason:''};

    if(window.fbUpsertMonthlyDoc){
      monthlyDocs=await window.fbUpsertMonthlyDoc(rec);
    }else{
      monthlyDocs=(monthlyDocs||[]).filter(x=>x&&x.id!==id).concat([rec]);
      await saveMonthlyDocs();
    }
    if(oldPhoto&&oldPhoto!==photoId&&window.fbDeletePhotos)window.fbDeletePhotos([oldPhoto]);

    hideDocUploadPopup();
    showDocUploadToast('✅ อัปโหลดสำเร็จ รอส่วนกลางตรวจสอบ', true);
    renderDashboard();
    if(document.getElementById('admin')&&!document.getElementById('admin').classList.contains('hidden'))renderAdmin();
  }catch(err){
    console.error('monthly doc upload error', err);
    hideDocUploadPopup();
    showDocUploadToast('❌ อัปโหลดไม่สำเร็จ: '+(err?.message||'กรุณาลองใหม่'), false);
  }finally{
    if(input)input.value='';
  }
}



// คำนวณจุดตัดข้อมูลบันทึกเที่ยววิ่ง — เก็บเป็น "เดือนปฏิทินจริง" ย้อนหลัง 3 เดือนรวมเดือนปัจจุบัน
// (เดิมนับถอยหลัง 60 วันดิบๆ ไม่ตรงรอบเดือนจริง ทำให้ข้อมูลกลางเดือนหายไปแบบงงๆ ไม่ตรงกับที่พนักงานเข้าใจ)
function _runLogCutoff(){
  const d=new Date();
  d.setDate(1);d.setHours(0,0,0,0);
  d.setMonth(d.getMonth()-2); // ถอยจากต้นเดือนนี้ไป 2 เดือนเต็ม = รวมเป็น 3 เดือนปฏิทิน (เดือนนี้ + 2 เดือนก่อนหน้าเต็มเดือน)
  return d.getTime();
}
// ── บันทึกวิ่งงานของพนักงาน ──
// บันทึกถาวรลง runLogs ทุกครั้งที่พนักงานเปลี่ยนสถานะเป็น "ออกเดินทาง" (traveling)
// พร้อมหมายเหตุที่มีคำว่า 6W (บรรทัดใหม่ที่ยังไม่เคยถูกนับ) — เก็บไว้ถาวร ไม่หายแม้สถานะจะเปลี่ยนไปแล้วในภายหลัง
function countSixWTrips(text){
  const m=String(text||'').match(/6W/gi);
  return m?m.length:0;
}
// เรียกตอนบันทึกสถานะ (ทั้งพนักงานเองและแอดมินแก้แทน) — ถ้าหมายเหตุมีคำว่า 6W ให้ถือว่าทั้งหมายเหตุคือ 1 บันทึกวิ่งงาน
// เก็บข้อความทั้งหมดในหมายเหตุ (ไม่ตัดเฉพาะบรรทัดที่มี 6W) กันบันทึกซ้ำเมื่อหมายเหตุไม่เปลี่ยน
function recordRunLogIfNeeded(prevEmp,newStatus,newNote,empId,plate,name){
  if(newStatus!=='traveling')return;
  const note=String(newNote||'').trim();
  if(!note||!/6W/i.test(note))return;
  // ถือว่า "หมายเหตุเดิม" มีความหมายเฉพาะตอนที่สถานะก่อนหน้าเป็นออกเดินทางอยู่แล้วเท่านั้น
  // (ถ้าเพิ่งเปลี่ยนมาเป็นออกเดินทางใหม่ ให้บันทึกทันที แม้ข้อความจะซ้ำกับเที่ยวเก่าในอดีตก็ตาม)
  const prevNote=(prevEmp&&prevEmp.status==='traveling')?String(prevEmp.note||'').trim():'';
  if(note===prevNote)return; // หมายเหตุไม่เปลี่ยน ไม่บันทึกซ้ำ
  const now=new Date().toISOString();
  runLogs.unshift({
    id:'rl_'+Date.now()+'_'+Math.random().toString(36).slice(2,8),
    empId,name:name||'',plate:plate||'',
    detail:note,
    trips:countSixWTrips(note)||1,
    createdAt:now
  });
  // เก็บย้อนหลังแบบเดือนปฏิทินจริง — ไว้ให้พนักงานตรวจเที่ยววิ่งของตัวเองเฉยๆ ไม่ต้องเก็บนาน (แอดมิน export เก็บถาวรได้จากเมนู "เครื่องมือระบบ")
  const cutoff=_runLogCutoff();
  runLogs=runLogs.filter(r=>!r.createdAt||new Date(r.createdAt).getTime()>=cutoff);
  saveRunLogs();
}
// ── กู้เที่ยวที่ตกหล่น ──
// เผื่อกรณีพนักงานเปลี่ยนเป็น "ออกเดินทาง" + หมายเหตุ 6W ไปแล้วตั้งแต่ก่อนอัพเดทระบบนี้ขึ้นเว็บจริง
// ทำงานครั้งเดียวตอนแอปโหลดเสร็จ — สแกนเฉพาะพนักงานที่ "สถานะปัจจุบันเป็นออกเดินทาง" เท่านั้น (เดิมสแกนทุกคนไม่สนสถานะ ทำให้บันทึกผิดตอนรถยังไม่ออก)
// ถ้าหมายเหตุมี 6W และยังไม่เคยถูกบันทึกไว้เลย (เทียบข้อความทั้งหมด) จะเก็บเข้าประวัติให้อัตโนมัติ
function backfillMissedRunLogs(){
  if(!Array.isArray(employees)||!employees.length)return;
  const now=new Date().toISOString();
  let added=false;
  employees.forEach(e=>{
    if(e?.status!=='traveling')return; // ต้องเป็นสถานะออกเดินทางเท่านั้น
    const note=String(e?.note||'').trim();
    if(!note||!/6W/i.test(note))return;
    const existing=new Set((runLogs||[]).filter(r=>r.empId===e.id).map(r=>r.detail));
    if(existing.has(note))return;
    runLogs.unshift({
      id:'rl_'+Date.now()+'_'+Math.random().toString(36).slice(2,8),
      empId:e.id,name:e.name||'',plate:e.plate||'',
      detail:note,
      trips:countSixWTrips(note)||1,
      createdAt:e.updatedAt||now
    });
    added=true;
  });
  if(added){
    const cutoff=_runLogCutoff();
    runLogs=runLogs.filter(r=>!r.createdAt||new Date(r.createdAt).getTime()>=cutoff);
    saveRunLogs();
  }
}
function getRunLogEntriesForEmployee(e){
  if(!e)return[];
  const cutoff=_runLogCutoff(); // แสดงเฉพาะย้อนหลัง 3 เดือนปฏิทิน (เดือนนี้ + 2 เดือนก่อนหน้า)
  return (runLogs||[])
    .filter(r=>r.empId===e.id&&(!r.createdAt||new Date(r.createdAt).getTime()>=cutoff))
    .sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt))
    .map((r,idx)=>({
      no:idx+1,
      id:r.id,
      detail:r.detail,
      trips:r.trips,
      updatedAt:r.createdAt,
      status:'traveling',
      plate:r.plate||e.plate||'',
      name:r.name||e.name||''
    }));
}
function renderEmployeeRunLogCard(me){
  const entries=getRunLogEntriesForEmployee(me);
  const total=entries.reduce((s,x)=>s+(Number(x.trips)||0),0);
  const latest=entries.slice(0,3).map(x=>`<div style="display:flex;gap:8px;align-items:flex-start;background:#fff;border:1px solid #BBF7D0;border-radius:12px;padding:9px 10px;margin-top:8px;">
    <span style="flex-shrink:0;width:24px;height:24px;border-radius:50%;background:#DCFCE7;color:#047857;font-size:12px;font-weight:900;display:flex;align-items:center;justify-content:center;">${x.no}</span>
    <div style="flex:1;min-width:0;">
      <div style="font-size:13px;font-weight:900;color:#064E3B;word-break:break-word;line-height:1.45;white-space:pre-wrap;">${esc(x.detail)}</div>
      <div style="font-size:10.8px;color:#64748B;margin-top:3px;">${skeIcon('note')} รายละเอียดงานจากหมายเหตุ · 🕐 ${fmt(x.updatedAt)}</div>
    </div>
    <div style="text-align:right;flex-shrink:0;display:flex;flex-direction:column;align-items:flex-end;gap:6px;">
      <div class="rl-entry-num" data-trips="${x.trips}" data-revealed="0" onclick="toggleRunLogEntryCount(this,event)" style="font-size:12px;font-weight:900;color:#047857;white-space:nowrap;cursor:pointer;">🙈 •••</div>
      <div style="display:flex;gap:6px;">
        <button onclick="openEditRunLogEntry('${esc(x.id)}')" title="แก้ไขรายการนี้" style="width:24px;height:24px;border-radius:50%;background:#EFF6FF;color:#1E90D6;font-size:12px;border:1px solid #BFDBFE;">✏️</button>
        <button onclick="doDeleteRunLogEntry('${esc(x.id)}')" title="ลบรายการนี้" style="width:24px;height:24px;border-radius:50%;background:#FEF2F2;color:#DC2626;font-size:12px;border:1px solid #FECACA;">🗑️</button>
      </div>
    </div>
  </div>`).join('');
  return `<div style="margin-top:10px;background:#F0FDF4;border:1.5px solid #86EFAC;border-radius:16px;padding:12px 14px;box-shadow:0 6px 18px rgba(34,197,94,.10);">
    <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;">
      <div style="display:flex;align-items:center;gap:10px;min-width:0;">
        <div style="width:42px;height:42px;border-radius:50%;background:#DCFCE7;display:flex;align-items:center;justify-content:center;font-size:25px;">🚚</div>
        <div style="min-width:0;">
          <div style="font-size:14px;font-weight:900;color:#065F46;">บันทึกวิ่งงาน</div>
          <div style="font-size:11.5px;color:#64748B;line-height:1.35;">นับเฉพาะสถานะออกเดินทาง + หมายเหตุมีคำว่า 6W</div>
        </div>
      </div>
      <div class="rl-total-box" data-total="${total}" data-revealed="0" onclick="toggleRunLogTotal(this)" style="text-align:center;color:#047857;font-weight:900;font-size:22px;line-height:1;cursor:pointer;min-width:64px;">🙈<div class="rl-hint" style="font-size:10.5px;margin-top:3px;font-weight:700;">แตะเพื่อดู</div></div>
    </div>
    ${entries.length?latest:`<div style="margin-top:10px;background:#fff;border:1px dashed #BBF7D0;border-radius:12px;padding:10px;color:#64748B;font-size:12px;line-height:1.55;">ยังไม่พบเที่ยววิ่งที่นับได้<br>ต้องเป็นสถานะ <b>ออกเดินทาง</b> และในหมายเหตุมีคำว่า <b>6W</b></div>`}
    <button class="btn btn-green btn-full" style="margin-top:10px;font-size:13px;" onclick="openEmployeeRunLogModal()">ดูเที่ยวงานของฉันทั้งหมด</button>
  </div>`;
}
// สลับซ่อน/แสดงจำนวนเที่ยวรวม — ค่าเริ่มต้นซ่อนไว้เสมอทุกครั้งที่หน้าโหลดใหม่ (ป้องกันหลุดผ่านสกรีนช็อตที่แชร์กลุ่ม)
function toggleRunLogTotal(el){
  const revealed=el.dataset.revealed==='1';
  el.dataset.revealed=revealed?'0':'1';
  const hint=el.querySelector('.rl-hint');
  el.innerHTML=revealed?`🙈<div class="rl-hint" style="font-size:10.5px;margin-top:3px;font-weight:700;">แตะเพื่อดู</div>`:`${esc(el.dataset.total)}<div class="rl-hint" style="font-size:10.5px;margin-top:3px;font-weight:700;">เที่ยว (แตะเพื่อซ่อน)</div>`;
}
function toggleRunLogEntryCount(el,ev){
  if(ev)ev.stopPropagation();
  const revealed=el.dataset.revealed==='1';
  el.dataset.revealed=revealed?'0':'1';
  el.textContent=revealed?'🙈 •••':el.dataset.trips+' เที่ยว';
}
function openEmployeeRunLogModal(){
  const me=employees.find(e=>e.id===currentUser?.id)||currentUser;
  if(!me)return;
  const entries=getRunLogEntriesForEmployee(me);
  const total=entries.reduce((s,x)=>s+(Number(x.trips)||0),0);
  const old=document.getElementById('employeeRunLogModal'); if(old)old.remove();
  const modal=document.createElement('div');
  modal.id='employeeRunLogModal';
  modal.style.cssText='position:fixed;inset:0;z-index:10000;background:rgba(0,0,0,.45);display:flex;align-items:flex-end;justify-content:center;';
  const list=entries.length?entries.map(x=>`<div style="background:#fff;border:1px solid #E2E8F0;border-radius:14px;padding:12px;margin-top:10px;">
    <div style="display:flex;justify-content:space-between;gap:8px;align-items:flex-start;">
      <div style="font-size:14px;font-weight:900;color:#0F172A;line-height:1.45;word-break:break-word;white-space:pre-wrap;">${esc(x.detail)}</div>
      <div class="rl-entry-num" data-trips="${x.trips}" data-revealed="0" onclick="toggleRunLogEntryCount(this,event)" style="color:#047857;font-size:13px;font-weight:900;white-space:nowrap;cursor:pointer;">🙈 •••</div>
    </div>
    <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-top:6px;">
      <div style="font-size:11px;color:#64748B;line-height:1.5;">🚛 ${esc(x.plate||'-')} · สถานะ: ออกเดินทาง · 🕐 ${fmt(x.updatedAt)}</div>
      <div style="display:flex;gap:6px;flex-shrink:0;">
        <button class="btn btn-blue btn-sm" style="padding:5px 10px;font-size:10.5px;white-space:nowrap;" onclick="openEditRunLogEntry('${esc(x.id)}')">✏️ แก้ไข</button>
        <button class="btn btn-red btn-sm" style="padding:5px 10px;font-size:10.5px;white-space:nowrap;" onclick="doDeleteRunLogEntry('${esc(x.id)}')">🗑️ ลบ</button>
      </div>
    </div>
  </div>`).join(''):`<div style="text-align:center;color:#64748B;font-size:13px;padding:24px 10px;background:#F8FAFC;border:1px dashed #CBD5E1;border-radius:14px;margin-top:12px;">ยังไม่มีบันทึกเที่ยววิ่ง<br>ระบบจะนับเมื่อสถานะเป็น <b>ออกเดินทาง</b> และหมายเหตุมีคำว่า <b>6W</b></div>`;
  modal.innerHTML=`<div style="width:min(560px,100%);max-height:82vh;overflow:auto;background:#fff;border-radius:24px 24px 0 0;padding:16px;box-shadow:0 -18px 50px rgba(15,23,42,.22);">
    <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:8px;">
      <div><div style="font-size:18px;font-weight:900;color:#0F172A;">🚚 บันทึกวิ่งงานของฉัน</div><div style="font-size:12px;color:#64748B;margin-top:2px;">${esc(me.name||'-')} · ${esc(me.plate||'-')}</div></div>
      <button onclick="closeEmployeeRunLogModal()" style="width:36px;height:36px;border-radius:50%;background:#F1F5F9;color:#334155;font-size:20px;font-weight:900;">×</button>
    </div>
    <div style="background:#ECFDF5;border:1px solid #BBF7D0;border-radius:14px;padding:12px;color:#065F46;font-weight:900;display:flex;justify-content:space-between;align-items:center;">
      <span>รวมเที่ยววิ่งที่นับได้</span><span class="rl-total-box" data-total="${total}" data-revealed="0" onclick="toggleRunLogTotal(this)" style="font-size:16px;cursor:pointer;">🙈 แตะเพื่อดู</span>
    </div>
    ${list}
  </div>`;
  document.body.appendChild(modal);
}
function closeEmployeeRunLogModal(){document.getElementById('employeeRunLogModal')?.remove();}
// ── ลบเที่ยววิ่งที่บันทึกไว้ 1 รายการ (พนักงานลบของตัวเองได้) ──
function doDeleteRunLogEntry(id){
  const log=(runLogs||[]).find(r=>r.id===id);
  if(!log)return;
  if(!confirm('ลบเที่ยววิ่งนี้?\n\n'+(log.detail||'')))return;
  runLogs=runLogs.filter(r=>r.id!==id);
  saveRunLogs();
  renderDashboard();
  if(document.getElementById('employeeRunLogModal'))openEmployeeRunLogModal();
}
// ── แก้ไขรายละเอียดเที่ยววิ่งที่บันทึกไว้ 1 รายการ (พนักงานแก้ของตัวเองได้) ──
function openEditRunLogEntry(id){
  const log=(runLogs||[]).find(r=>r.id===id);
  if(!log)return;
  const old=document.getElementById('editRunLogModal'); if(old)old.remove();
  const modal=document.createElement('div');
  modal.id='editRunLogModal';
  modal.style.cssText='position:fixed;inset:0;z-index:10001;background:rgba(0,0,0,.5);display:flex;align-items:center;justify-content:center;padding:16px;';
  modal.innerHTML=`<div style="width:min(480px,100%);background:#fff;border-radius:20px;padding:16px;box-shadow:0 20px 60px rgba(15,23,42,.3);">
    <div style="font-size:16px;font-weight:900;color:#0F172A;margin-bottom:10px;">✏️ แก้ไขรายละเอียดเที่ยววิ่ง</div>
    <textarea id="editRunLogText" class="inp" rows="5" style="width:100%;box-sizing:border-box;">${esc(log.detail||'')}</textarea>
    <div style="font-size:11px;color:#64748B;margin-top:6px;line-height:1.5;">ระบบจะนับจำนวนเที่ยวจากคำว่า "6W" ที่พบในข้อความนี้ให้อัตโนมัติ</div>
    <div style="display:flex;gap:8px;margin-top:14px;">
      <button class="btn btn-gray btn-full" onclick="closeEditRunLogModal()">ยกเลิก</button>
      <button class="btn btn-green btn-full" onclick="saveEditRunLogEntry('${esc(id)}')">✓ บันทึก</button>
    </div>
  </div>`;
  document.body.appendChild(modal);
}
function closeEditRunLogModal(){document.getElementById('editRunLogModal')?.remove();}
function saveEditRunLogEntry(id){
  const ta=document.getElementById('editRunLogText');
  const newText=(ta?.value||'').trim();
  if(!newText){alert('กรุณากรอกรายละเอียดเที่ยววิ่ง');ta?.focus();return;}
  runLogs=runLogs.map(r=>r.id===id?{...r,detail:newText,trips:countSixWTrips(newText)||1}:r);
  saveRunLogs();
  closeEditRunLogModal();
  renderDashboard();
  if(document.getElementById('employeeRunLogModal'))openEmployeeRunLogModal();
}

function renderDashboard(){
  // sync currentUser จาก employees (กันกรณี localStorage เก่า)
  if(currentUser){
    const fresh=employees.find(e=>e.id===currentUser.id);
    if(fresh)currentUser={...currentUser,...fresh};
  }
  const me=employees.find(e=>e.id===currentUser?.id)||currentUser;
  if(!me){show('login');renderEmpList();return;}
  const s=getS(me.status);const lbl=getFullLabel(me);
  if(!editOpen&&!document.getElementById('statusEditModal')){
    // ซิงค์ค่าที่กำลังเลือกจากข้อมูลล่าสุดเฉพาะตอนยังไม่ได้เปิดแผงแก้ไขอยู่จริงๆ (เช็ค 2 ชั้น: ทั้ง flag และ DOM จริง)
    // (ป้องกันไม่ให้ realtime update จากพนักงานคนอื่นมาทับสถานะ/จังหวัดที่เพิ่งพิมพ์ไว้แต่ยังไม่ได้กดบันทึก)
    _selStatus=me.status;_selProv=me.province||'';
  }
  const leavePill=me.onLeave?leaveApprovalPill(me):null;
  const queueInfo=getQueuePosition(me);

  document.getElementById('adminBadge').classList.toggle('hidden',!adminMode);
  document.getElementById('navAdmin').style.display=adminMode?'flex':'none';


  const mc=document.getElementById('myCard');
  mc.style.background='#fff';
  mc.style.border='1.5px solid #E8EAF0';
  mc.style.boxShadow='0 8px 28px rgba(17,24,39,.08)';
  mc.innerHTML=`
    <div class="emp-profile-head">
      <div class="avatar">${avatarImg(me,62)}${leaveIcon(me)}</div>
      <div style="flex:1;min-width:0;">
        <div class="emp-name">${esc(me.name)} <span style="font-size:14px;color:#6D28D9;">(คุณ)</span></div>
        <div class="emp-meta">🚛 ${esc(me.plate||'-')}${phoneLink(me.phone)}</div>
      </div>
      <button id="editBtn" class="emp-edit-btn" onclick="openStatusModal()">✎ แก้ไขสถานะ</button>
    </div>
    <div class="emp-status-strip">
      <div class="emp-status-left"><span style="font-size:26px;">${skeIcon(s.ic)}</span><span style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${lbl}</span></div>
      <span class="emp-status-badge">${me.status==='standby'?'รอขึ้นงาน':s.label}</span>
    </div>
    ${(me.status==='got_job'&&me.note)?`<div style="margin-top:10px;background:#EEF2FF;border:2px solid #A5B4FC;border-radius:12px;padding:12px 14px;">
      <div style="font-size:12px;font-weight:800;color:#4F46E5;margin-bottom:5px;">📦 รายละเอียดงานที่ได้รับ</div>
      <div style="font-size:14.5px;color:#1a1a2e;font-weight:700;line-height:1.6;white-space:pre-wrap;">${esc(me.note)}</div>
    </div>`:''}
    ${(me.note&&me.note.includes('ถูกยกเลิก'))?`<div style="margin-top:10px;background:#FEF2F2;border:2px solid #FCA5A5;border-radius:12px;padding:12px 14px;">
      <div style="font-size:12px;font-weight:800;color:#DC2626;margin-bottom:5px;">🚫 แจ้งเตือนงาน</div>
      <div style="font-size:14.5px;color:#B91C1C;font-weight:700;line-height:1.6;white-space:pre-wrap;">${esc(me.note)}</div>
    </div>`:''}
    ${queueInfo?`<div style="display:flex;align-items:center;gap:9px;margin-top:8px;padding:9px 12px;background:#ECFDF5;border-radius:10px;border:1.5px solid #6EE7B7;">
      <span style="flex-shrink:0;width:26px;height:26px;border-radius:50%;background:#065F46;color:#fff;font-size:13px;font-weight:800;display:flex;align-items:center;justify-content:center;">${queueInfo.pos}</span>
      <div style="flex:1;">
        <div style="font-size:13px;font-weight:800;color:#065F46;">คุณอยู่คิวที่ ${queueInfo.pos} จาก ${queueInfo.total} คัน</div>
        <div style="font-size:11px;color:#888;">${queueInfo.prov!=='ไม่ระบุจังหวัด'?`${skeIcon('pin')} ${esc(queueInfo.prov)} · `:''}${queueInfo.pos===1?'คิวต่อไปที่ควรได้งานก่อน':'รอคิวก่อนหน้าได้งานก่อน'}</div>
      </div>
    </div>`:''}
    ${me.province?`<div id="weatherWidget" class="emp-weather">
      <span style="font-size:24px;">☁️</span>
      <div style="flex:1;"><div style="font-size:12px;color:#64748B;font-weight:700;">กำลังโหลดสภาพอากาศ...</div></div>
      <button onclick="updateWeatherWidget('${esc(me.province)}')" style="color:#7B2FBE;font-size:12px;font-weight:900;background:transparent;">↻ รีเฟรชข้อมูล</button>
    </div>`:''}
    ${renderMonthlyDocAlert(me)}
    ${renderEmployeeRunLogCard(me)}
    ${renderSameStandbyEmployees(me)}
    ${(me.note&&me.status!=='got_job'&&!me.note.includes('ถูกยกเลิก'))?`<div style="color:#666;font-size:12px;margin-top:8px;">${skeIcon('note')} ${esc(me.note)}</div>`:''}
    ${me.status==='standby'&&me.standbyAt?`<div style="color:#7B2FBE;font-size:12px;font-weight:700;margin-top:6px;padding:5px 10px;background:#F5F3FF;border-radius:8px;border:1px solid #C4B5FD;">⏱️ สแตนบายตั้งแต่: ${fmt(me.standbyAt)}</div>`:''}
    ${me.updatedAt?`<div style="color:#aaa;font-size:11px;margin-top:4px;">🕐 อัพเดท: ${fmt(me.updatedAt)}</div>`:''}
    <div style="margin-top:12px;padding-top:12px;border-top:1px solid rgba(0,0,0,.08);">
      ${me.onLeave?`
        <div style="color:#475569;font-size:12px;font-weight:700;padding:8px 10px;background:#F1F5F9;border-radius:8px;border:1px solid #CBD5E1;">🌴 แจ้งลา: ${fmtLeaveRange(me)}</div>
        ${me.leaveNote?`<div style="color:#666;font-size:12px;margin-top:6px;">${skeIcon('note')} ${esc(me.leaveNote)}</div>`:''}
        <div style="margin-top:8px;display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap;">
          <span class="pill" style="background:${leavePill.bg};color:${leavePill.color};border:1px solid ${leavePill.border};">${leavePill.text}</span>
          <button class="btn btn-gray btn-sm" onclick="doCancelLeave()">✕ ยกเลิกการลา</button>
        </div>
        ${me.leaveReply?`<div style="margin-top:10px;background:#EFF6FF;border:1px solid #BFDBFE;border-radius:12px;padding:10px 12px;">
          <div style="font-size:11px;color:#1E90D6;font-weight:700;margin-bottom:3px;">💬 ข้อความจากผู้ดูแล${me.leaveReplyAt?` · ${fmt(me.leaveReplyAt)}`:''}</div>
          <div style="font-size:13px;color:#1a1a2e;line-height:1.6;white-space:pre-wrap;">${esc(me.leaveReply)}</div>
        </div>`:''}
      `:`
        ${renderApprovedLeaveNoticeForEmployees(me.id)}
        <div style="background:#EFF6FF;border:1.5px solid #BFDBFE;border-radius:12px;padding:10px 12px;margin-top:10px;font-size:12px;color:#1E40AF;">📌 กรอกคำขอลาได้ทุกเมื่อ แต่เลือก<b>วันที่ลาได้เฉพาะวันที่ 16-25 ของเดือน</b>เท่านั้น</div>
        <button class="btn btn-gray btn-full" style="font-size:13px;margin-top:10px;" onclick="toggleLeaveForm()">${leaveFormOpen?'✕ ยกเลิก':skeIcon('leave')+' แจ้งลา'}</button>
        <div id="leaveFormWrap" class="${leaveFormOpen?'':'hidden'}" style="margin-top:10px;">
          <div class="province-box">
            <div class="province-title">📅 ลาตั้งแต่วันที่ (16-25 เท่านั้น)</div>
            <input type="date" class="inp" id="leaveFromInp" value="${_selLeaveAt||''}">
            <div class="province-title" style="margin-top:10px;">📅 ถึงวันที่ (16-25 เท่านั้น)</div>
            <input type="date" class="inp" id="leaveToInp" value="${_selLeaveTo||''}">
            <div class="province-title" style="margin-top:10px;">${skeIcon('note')} หมายเหตุการลา</div>
            <textarea class="inp" id="leaveNoteInp2" rows="2" placeholder="เช่น ลากิจ, ลาป่วย, ลาพักร้อน...">${esc(_selLeaveNote||'')}</textarea>
          </div>
          <button class="btn btn-blue btn-full" style="margin-top:10px;" onclick="doRequestLeave()">✓ ส่งคำขอลา</button>
        </div>
      `}
    </div>`;

  if(me.province)updateWeatherWidget(me.province);
  updateMaintBadges();
}
// แสดงช่วงวันที่ลาแบบอ่านง่าย (ถ้าวันเริ่ม-สิ้นสุดเป็นวันเดียวกันโชว์วันเดียว)
function fmtLeaveRange(e){
  if(!e.leaveFrom)return'-';
  const fmtD=d=>new Date(d).toLocaleDateString('th-TH',{day:'numeric',month:'short',year:'numeric'});
  if(e.leaveTo&&e.leaveTo!==e.leaveFrom)return`${fmtD(e.leaveFrom)} — ${fmtD(e.leaveTo)}`;
  return fmtD(e.leaveFrom);
}

// เช็กว่าพนักงานคนนี้อยู่ในช่วงวันลาวันนี้จริงหรือไม่ (รวมวันเริ่มและวันสิ้นสุด)
function _dateInLeaveRange(fromVal,toVal){
  if(!fromVal)return false;
  const today=new Date(todayStr()+'T00:00:00');
  const from=new Date(String(fromVal).slice(0,10)+'T00:00:00');
  const to=new Date(String(toVal||fromVal).slice(0,10)+'T00:00:00');
  return today>=from && today<=to;
}
// หมายเหตุ: เดิมมีฟังก์ชัน _isLeaveCleared/_markLeaveCleared เก็บสถานะ "เคลียร์ลาแล้ว" ไว้ใน localStorage
// ของเครื่องเดียว ทำให้อุปกรณ์อื่นมองไม่เห็นว่าเคลียร์แล้ว (สถานะลาเด้งกลับมา) — ถูกแทนที่ด้วยฟิลด์ cleared
// บน leaveLogs ที่ซิงก์ผ่าน Firebase แทนแล้ว (ดู adminClearLeaveToNormal และ activeApprovedLeaveLogForEmployee)
function activeApprovedLeaveLogForEmployee(e){
  if(!e)return null;
  // จับคู่ด้วย empId ก่อนเป็นหลักเสมอถ้าบันทึกนั้นมี empId อยู่แล้ว (สร้างตอนอนุมัติลาจะมี empId ติดมาด้วยทุกครั้ง)
  // ใช้ทะเบียนรถ/ชื่อ เป็นตัวสำรองเฉพาะบันทึกเก่าที่ไม่มี empId เท่านั้น — ป้องกันจับผิดคนตอนพนักงาน 2 คนใช้รถทะเบียนเดียวกัน (ผลัดกันขับ)
  const sameEmp=l=>l.empId?(String(l.empId)===String(e.id||'')):(((l.plate||'')&&e.plate&&String(l.plate).trim()===String(e.plate).trim()) || ((l.empName||'')&&e.name&&String(l.empName).trim()===String(e.name).trim()));
  return (leaveLogs||[]).find(l=>sameEmp(l)&&_dateInLeaveRange(l.leaveFrom,l.leaveTo)&&!l.cleared)||null;
}
function isLeaveActiveToday(e){
  // แสดงสถานะลาเฉพาะที่อนุมัติแล้วเท่านั้น (onLeave/leaveApproval ถูกซิงก์ผ่าน Firebase อยู่แล้ว
  // เมื่อผู้ดูแลกด "ทำงานปกติ" ค่าจะถูกล้างที่นี่โดยตรง จึงไม่ต้องพึ่ง localStorage ซึ่งไม่ซิงก์ข้ามอุปกรณ์)
  if(!e)return false;
  if(e.onLeave&&e.leaveApproval==='approved'&&_dateInLeaveRange(e.leaveFrom,e.leaveTo))return true;
  return !!activeApprovedLeaveLogForEmployee(e);
}
function getApprovedLeaveListForEmployees(){
  const map=new Map();
  const add=(item)=>{
    if(!item||!item.leaveFrom)return;
    // จับคู่ด้วย empId ก่อนเป็นหลักเสมอ ใช้ทะเบียนรถ/ชื่อเป็นตัวสำรองเฉพาะกรณีไม่มี empId (บันทึกเก่า)
    // ป้องกันจับผิดคนตอนพนักงาน 2 คนใช้รถทะเบียนเดียวกัน
    let emp=item.empId?employees.find(e=>String(e.id)===String(item.empId)):null;
    if(!emp)emp=employees.find(e=>(item.plate&&e.plate&&String(item.plate).trim()===String(e.plate).trim()) || (item.empName&&e.name&&String(item.empName).trim()===String(e.name).trim()));
    const id=emp?.id||item.empId||item.plate||item.empName;
    const from=String(item.leaveFrom).slice(0,10), to=String(item.leaveTo||item.leaveFrom).slice(0,10);
    if(item.cleared)return;
    const end=new Date(to+'T23:59:59');
    if(end < new Date(todayStr()+'T00:00:00'))return;
    const key=String(id)+'_'+from+'_'+to;
    if(map.has(key))return;
    map.set(key,{empId:id,empName:emp?.name||item.empName||'-',plate:emp?.plate||item.plate||'-',leaveFrom:from,leaveTo:to,leaveNote:item.leaveNote||''});
  };
  employees.filter(e=>e.onLeave&&e.leaveApproval==='approved').forEach(add);
  (leaveLogs||[]).forEach(add);
  return [...map.values()].sort((a,b)=>(a.leaveFrom||'').localeCompare(b.leaveFrom||'') || (a.empName||'').localeCompare(b.empName||''));
}
function renderApprovedLeaveNoticeForEmployees(currentEmpId){
  const list=getApprovedLeaveListForEmployees().filter(x=>String(x.empId)!==String(currentEmpId||''));
  if(!list.length)return '';
  return `<div style="margin-top:10px;background:#FFFBEB;border:1.5px solid #FCD34D;border-radius:12px;padding:10px 12px;">
    <div style="font-size:13px;font-weight:900;color:#92400E;margin-bottom:6px;">📌 วันที่มีพนักงานลาแล้ว — ตรวจสอบก่อนแจ้งลา</div>
    <div style="display:flex;flex-direction:column;gap:6px;max-height:170px;overflow:auto;">
      ${list.map(x=>`<div style="background:#fff;border:1px solid #FDE68A;border-radius:10px;padding:7px 9px;">
        <div style="font-size:12.5px;font-weight:800;color:#1a1a2e;">🌴 ${esc(x.empName)} <span style="color:#64748B;font-weight:600;">🚛 ${esc(x.plate||'-')}</span></div>
        <div style="font-size:11.5px;color:#92400E;font-weight:800;margin-top:2px;">📅 ${fmtLeaveRange(x)}</div>
        ${x.leaveNote?`<div style="font-size:11px;color:#64748B;margin-top:2px;">${skeIcon('note')} ${esc(x.leaveNote)}</div>`:''}
      </div>`).join('')}
    </div>
    <div style="font-size:10.5px;color:#92400E;margin-top:6px;">แสดงเฉพาะรายการที่ผู้ดูแลอนุมัติแล้ว เพื่อไม่ให้ลาซ้ำวันพร้อมกัน</div>
  </div>`;
}
function getActiveLeaveRange(e){
  const log=activeApprovedLeaveLogForEmployee(e);
  if(log)return{leaveFrom:log.leaveFrom,leaveTo:log.leaveTo};
  return e;
}
function leaveTodayBadge(e){
  if(!isLeaveActiveToday(e))return'';
  return `<div style="margin-top:4px;display:inline-flex;align-items:center;gap:4px;background:#FFF7ED;color:#C2410C;border:1px solid #FDBA74;border-radius:999px;padding:2px 8px;font-size:10.5px;font-weight:800;">🌴 ลาอยู่วันนี้ ${fmtLeaveRange(getActiveLeaveRange(e))}</div>`;
}
function adminClearLeaveToNormal(id){
  const emp=employees.find(e=>e.id===id);
  if(!emp)return;
  if(!confirm('เปลี่ยนจากลาอยู่ เป็นทำงานปกติ?'))return;
  const activeLog=activeApprovedLeaveLogForEmployee(emp);
  // ทำเครื่องหมาย "เคลียร์แล้ว" บนบันทึกประวัติการลาโดยตรง แล้วซิงก์ขึ้น Firebase
  // (เดิมเก็บไว้ใน localStorage ของเครื่องเดียว ทำให้อุปกรณ์/เบราว์เซอร์อื่นมองไม่เห็นว่าเคลียร์แล้ว สถานะลาจึงเด้งกลับมา)
  if(activeLog){
    leaveLogs=leaveLogs.map(l=>l.id===activeLog.id?{...l,cleared:true}:l);
    saveLeaveLogs();
  }
  const patch={onLeave:false,leaveFrom:null,leaveTo:null,leaveNote:null,leaveApproval:null,leaveReply:null,leaveReplyAt:null};
  employees=employees.map(e=>e.id===id?{...e,...patch}:e);
  _cacheSet('ske_emp', employees);
  if(window.fbUpdateEmployeeFields){
    fbPatchEmployee(id,patch);
  }else if(window.fbSaveEmployees){
    window.fbSaveEmployees(employees);
  }
  renderAdmin();
}

function toggleLeaveForm(){
  leaveFormOpen=!leaveFormOpen;
  renderDashboard();
}
// วันที่ลาต้องเป็นวันที่ 16-25 ของเดือนนั้นๆ เท่านั้น (ไม่เกี่ยวกับวันนี้เป็นวันที่เท่าไหร่ — กรอกล่วงหน้าได้ทุกเมื่อ)
function _isLeaveDayAllowed(dateStr){
  if(!dateStr)return false;
  const d=new Date(dateStr+'T00:00:00');
  if(isNaN(d.getTime()))return false;
  const day=d.getDate();
  return day>=16&&day<=25;
}
function doRequestLeave(){
  if(!currentUser)return;
  const fromEl=document.getElementById('leaveFromInp');
  const toEl=document.getElementById('leaveToInp');
  const noteEl=document.getElementById('leaveNoteInp2');
  const from=fromEl?.value||'';
  if(!from){fromEl?.focus();return;}
  const to=toEl?.value||from;
  if(!_isLeaveDayAllowed(from)){alert('⚠️ เลือกวันเริ่มลาได้เฉพาะวันที่ 16-25 ของเดือนเท่านั้น');fromEl?.focus();return;}
  if(!_isLeaveDayAllowed(to)){alert('⚠️ เลือกวันสิ้นสุดลาได้เฉพาะวันที่ 16-25 ของเดือนเท่านั้น');toEl?.focus();return;}
  const fd=new Date(from+'T00:00:00'),td=new Date(to+'T00:00:00');
  if(td<fd){alert('⚠️ วันสิ้นสุดการลาต้องไม่ก่อนวันเริ่มลา');toEl?.focus();return;}
  if(fd.getFullYear()!==td.getFullYear()||fd.getMonth()!==td.getMonth()){alert('⚠️ วันเริ่มและวันสิ้นสุดการลาต้องอยู่ในเดือนเดียวกัน (ช่วง 16-25)');return;}
  const noteVal=noteEl?.value||'';
  const patch={onLeave:true,leaveFrom:from,leaveTo:to,leaveNote:noteVal,leaveApproval:'pending'};
  employees=employees.map(e=>e.id===currentUser.id?{...e,...patch}:e);
  currentUser={...currentUser,...patch};
  saveU();leaveFormOpen=false;_selLeaveAt='';_selLeaveTo='';_selLeaveNote='';renderDashboard();
  _cacheSet('ske_emp', employees);
  if(window.fbUpdateEmployeeFields){
    fbPatchEmployee(currentUser.id,patch);
  } else if(window.fbSaveEmployees){
    window.fbSaveEmployees(employees);
  }
}
function doCancelLeave(){
  if(!currentUser)return;
  if(!confirm('ยกเลิกการลานี้?'))return;
  const patch={onLeave:false,leaveReply:null,leaveReplyAt:null};
  employees=employees.map(e=>e.id===currentUser.id?{...e,...patch}:e);
  currentUser={...currentUser,...patch};
  saveU();renderDashboard();
  _cacheSet('ske_emp', employees);
  if(window.fbUpdateEmployeeFields){
    fbPatchEmployee(currentUser.id,patch);
  } else if(window.fbSaveEmployees){
    window.fbSaveEmployees(employees);
  }
}


function buildSummaryHTML(){
  if(!employees.length){
    return '<div class="empty-state"><div class="empty-icon">'+skeIcon('overview')+'</div><div class="empty-text">ยังไม่มีข้อมูลพนักงาน</div></div>';
  }

  // นับแต่ละสถานะ (ไม่นับรวมคนที่ลาอยู่วันนี้ — รถของคนลาไม่ถือว่าอยู่ในสถานะปกติ, ไม่นับคนที่ถูกสลับคนขับออกแล้ว — status==='inactive',
  // และตัดรายการที่ทะเบียนซ้ำกัน — เหลือแค่คนที่อัปเดตสถานะล่าสุดของทะเบียนนั้นเท่านั้น ไม่งั้นตัวเลขสรุปจะไม่ตรงกับที่แสดงในลิสต์)
  const dedupedEmployees=_dedupByPlate(employees);
  const counts={};
  STATUSES.forEach(st=>counts[st.id]=0);
  dedupedEmployees.forEach(e=>{if(isLeaveActiveToday(e)||e.status==='inactive')return;if(counts[e.status]!==undefined)counts[e.status]++;else counts['standby']++;});

  // สรุปบนสุด — "รถทั้งหมด" นับจากรายการรถจริง (vehicles) ตรงๆ แยกขาดจากพนักงาน/คนขับโดยสิ้นเชิง
  // แจ้งเตือนเฉพาะสถานะที่กำลังทำงานอยู่ที่ช่อง (4 สถานะ) เกิน ALERT_HOURS ชม.
  const total=vehicles.filter(v=>v.active!==false).length;
  const stale=dedupedEmployees.filter(e=>!isLeaveActiveToday(e)&&ALERT_STATUSES.includes(e.status)&&(!e.updatedAt||(Date.now()-new Date(e.updatedAt))/3600000>=ALERT_HOURS)).length;

  let html=`
  <div style="text-align:center;margin-bottom:10px;padding:8px 14px;background:linear-gradient(135deg,#6C3FE8,#1E90D6);border-radius:12px;box-shadow:0 2px 8px rgba(108,63,232,.25);">
    <div style="font-size:15px;font-weight:800;color:#fff;letter-spacing:0.5px;">${new Date().toLocaleDateString('en-GB',{day:'2-digit',month:'2-digit',year:'numeric'}).replace(/\//g,' / ')}</div>
    <div style="font-size:10.5px;color:rgba(255,255,255,.75);margin-top:1px;">${new Date().toLocaleDateString('th-TH',{weekday:'long',day:'numeric',month:'long',year:'numeric'})}</div>
  </div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px;">
    <div style="background:#fff;border-radius:14px;padding:12px;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,.06);border:1.5px solid #E8EAF0;">
      <div style="font-size:28px;font-weight:900;color:#1E90D6;">${total}</div>
      <div style="font-size:11px;color:#888;margin-top:2px;">🚛 รถทั้งหมด</div>
    </div>
    <div style="background:${stale>0?'#FFF5F5':'#F0FDF4'};border-radius:14px;padding:12px;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,.06);border:1.5px solid ${stale>0?'#FCA5A5':'#86EFAC'};">
      <div style="font-size:28px;font-weight:900;color:${stale>0?'#EF4444':'#10B981'};">${stale}</div>
      <div style="font-size:11px;color:#888;margin-top:2px;">${stale>0?skeIcon('alert')+' ยังไม่อัพเดท':skeIcon('check')+' อัพเดทครบ'}</div>
    </div>
  </div>
  <div style="background:#fff;border:1.5px solid #BFDBFE;border-radius:14px;padding:10px 12px;margin-bottom:12px;box-shadow:0 2px 8px rgba(0,0,0,.05);">
    <input id="adminQuickSearch" type="text" placeholder="🔍 ค้นหาชื่อ / ทะเบียนรถ แล้วกดรายการเพื่อเลื่อนไปหา" oninput="renderAdminQuickSearch()" style="width:100%;padding:11px 12px;border:2px solid #1E90D6;border-radius:12px;font-size:13.5px;box-sizing:border-box;outline:none;">
    <div id="adminQuickSearchResults" style="display:none;margin-top:8px;flex-direction:column;gap:6px;"></div>
  </div>`;

  // รายชื่อพนักงานที่ยังไม่อัพเดทเกิน 24 ชม. (ทุกสถานะ — แจ้งเตือนผู้ดูแลแบบภาพรวม)
  // ไม่รวมคนที่ลาอยู่ (ลาที่อนุมัติแล้วและอยู่ในช่วงวันลา) เพราะไม่ควรต้องอัพเดทสถานะระหว่างลา
  // ไม่รวมตำแหน่งที่ไม่ใช่พนักงานขับรถ (เช่น แอดมิน/ฝ่ายบุคคล/ช่างซ่อม) เพราะไม่ต้องแจ้งสถานะรถอยู่แล้ว ไม่ควรถูกนับว่า "ค้าง"
  const stale24List=employees.filter(e=>isDrivingPosition(e.position)&&!isLeaveActiveToday(e)&&(!e.updatedAt||(Date.now()-new Date(e.updatedAt))/3600000>=STALE_ALL_HOURS));
  if(stale24List.length){
    stale24List.sort((a,b)=>{const av=a.updatedAt?new Date(a.updatedAt).getTime():0,bv=b.updatedAt?new Date(b.updatedAt).getTime():0;return av-bv;});
    html+=`<div style="background:#FEF2F2;border:2px solid #F87171;border-radius:14px;padding:12px 14px;margin-bottom:14px;">
      <div style="color:#B91C1C;font-weight:800;font-size:13.5px;margin-bottom:8px;">${skeIcon('alert')} ไม่อัพเดทสถานะเกิน ${STALE_ALL_HOURS} ชม. — ทุกสถานะ (${stale24List.length} คน)</div>
      <div style="display:flex;flex-direction:column;gap:6px;">`;
    stale24List.forEach(e=>{
      const s=getS(e.status);const never=!e.updatedAt;
      html+=`<div style="display:flex;align-items:center;gap:8px;padding:6px 8px;background:#fff;border-radius:8px;border:1px solid #FECACA;">
        <div class="avatar" style="width:30px;height:30px;font-size:13px;">${esc(e.name.charAt(0))}${leaveIcon(e)}</div>
        <div style="flex:1;min-width:0;">
          <div style="font-size:13px;font-weight:700;color:#1a1a2e;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${esc(e.name)}</div>
          <div style="font-size:11px;color:#888;">${esc(e.plate||'-')}${phoneLink(e.phone)}${lineLink(e.lineId)}</div>
          <span class="pill" style="background:${s.bg};color:${s.color};border:1px solid ${s.border};font-size:9.5px;margin-top:3px;display:inline-block;">${skeIcon(s.ic)} ${esc(s.label)}</span>
        </div>
        <span style="font-size:10px;color:#DC2626;font-weight:700;white-space:nowrap;text-align:right;">${_elapsedLabel(e.updatedAt)}</span>
      </div>`;
    });
    html+='</div></div>';
  }

  // ── สรุปย่อ "ต้องติดตามด่วน" (บนสุด) ──
  // ครอบคลุมทุกสถานะเร่งด่วนใน ALERT_STATUSES (ขึ้น/ลงสินค้า + สแตนบาย) รวมเป็นกล่องเดียว
  // ออกแบบเป็น "รายชื่อย่อ" (ไม่มีเบอร์โทร/ปุ่มติดต่อ) เพราะรายละเอียดเต็มมีอยู่แล้วเป็นการ์ดไฮไลต์แดงในลิสต์ "สรุปสถานะรถ" ด้านล่าง
  // เดิมเคยแสดงเป็นการ์ดเต็มซ้ำกับด้านล่าง 2 รอบ — รวมเหลือจุดเดียวต่อคน กันสับสนว่าเป็นคนละปัญหา
  const staleAll=dedupedEmployees.filter(e=>isDrivingPosition(e.position)&&ALERT_STATUSES.includes(e.status)&&(!e.updatedAt||(Date.now()-new Date(e.updatedAt))/3600000>=ALERT_HOURS));
  if(staleAll.length){
    staleAll.sort((a,b)=>{const av=a.updatedAt?new Date(a.updatedAt).getTime():0,bv=b.updatedAt?new Date(b.updatedAt).getTime():0;return av-bv;});
    html+=`<div style="background:#FEF2F2;border:1.5px solid #F87171;border-radius:14px;padding:12px 14px;margin-bottom:14px;">
      <div style="color:#DC2626;font-weight:700;font-size:13px;margin-bottom:8px;">${skeIcon('alert')} ต้องติดตามด่วน — ไม่อัพเดทเกิน ${ALERT_HOURS} ชม. (${staleAll.length} คน)</div>
      <div style="display:flex;flex-direction:column;gap:4px;">
        ${staleAll.map(e=>{
          const s=getS(e.status);const never=!e.updatedAt;
          return `<div style="display:flex;align-items:center;gap:8px;padding:4px 2px;">
            <span style="font-size:12px;flex-shrink:0;">${skeIcon(s.ic)}</span>
            <span style="font-size:12.5px;font-weight:700;color:#1a1a2e;flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${esc(e.name)}</span>
            <span style="font-size:10.5px;color:#DC2626;font-weight:700;white-space:nowrap;">${esc(s.label)} · ${_elapsedLabel(e.updatedAt)}</span>
          </div>`;
        }).join('')}
      </div>
    </div>`;
  }

  // สถานะแต่ละประเภท
  html+=`<div style="color:#999;font-size:11px;font-weight:700;letter-spacing:1px;margin-bottom:8px;">สรุปสถานะรถ</div>`;
  STATUSES.forEach(st=>{
    const cnt=counts[st.id]||0;
    if(cnt===0)return;
    html+=`<div style="background:#fff;border-radius:12px;padding:11px 14px;margin-bottom:8px;box-shadow:0 2px 8px rgba(0,0,0,.05);border:1.5px solid ${st.border};">
      <div style="display:flex;align-items:center;gap:10px;">
        <span style="font-size:22px;color:${st.color};">${skeIcon(st.ic)}</span>
        <div style="flex:1;">
          <div style="font-weight:700;color:${st.color};font-size:13px;">${st.label}</div>
        </div>
        <div style="background:${st.bg};border:1.5px solid ${st.border};border-radius:20px;padding:3px 12px;font-weight:800;color:${st.color};font-size:15px;">${cnt} คัน</div>
      </div>
      ${st.id==='standby'?renderStandbyByProv():''}
      ${st.id==='traveling'?renderTravelingByProv():''}
      ${st.id==='returning'?renderReturningByProv():''}
      ${st.id==='done'?renderDoneByProv():''}
      ${(st.id!=='standby'&&st.id!=='traveling'&&st.id!=='returning'&&st.id!=='done')?renderStatusEmployeeList(st):''}
    </div>`;
  });

  // ── พนักงานที่ลาอยู่วันนี้ — แยกไว้ด้านล่างสุด เป็นสัดส่วนของตัวเอง ไม่ปนกับสถานะรถปกติ ──
  const activeLeaveList=employees.filter(e=>isLeaveActiveToday(e));
  if(activeLeaveList.length){
    activeLeaveList.sort((a,b)=>(a.leaveFrom||'').localeCompare(b.leaveFrom||''));
    html+=`<div style="background:#fff;border-radius:12px;padding:11px 14px;margin-bottom:8px;box-shadow:0 2px 8px rgba(0,0,0,.05);border:1.5px solid #FDBA74;">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;">
        <span style="font-size:22px;">🌴</span>
        <div style="flex:1;">
          <div style="font-weight:700;color:#C2410C;font-size:13px;">ลา — ห้ามรับงานให้ก่อนเคลียร์สถานะ</div>
        </div>
        <div style="background:#FFF7ED;border:1.5px solid #FDBA74;border-radius:20px;padding:3px 12px;font-weight:800;color:#C2410C;font-size:15px;">${activeLeaveList.length} คัน</div>
      </div>
      <div style="display:flex;flex-direction:column;gap:6px;">`;
    activeLeaveList.forEach(e=>{
      const s=getS(e.status);
      html+=`<div style="display:flex;align-items:flex-start;gap:8px;padding:8px;background:#FFF7ED;border-radius:10px;border:1px solid #FDBA74;">
        <span style="font-size:18px;">🌴</span>
        <div style="flex:1;min-width:0;">
          <div style="font-size:13px;font-weight:900;color:#1a1a2e;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${esc(e.name)}</div>
          <div style="font-size:11px;color:#64748B;">🚘 ${esc(e.plate||'-')}${phoneLink(e.phone)}${lineLink(e.lineId)}</div>
          <div style="font-size:11.5px;color:#C2410C;font-weight:800;margin-top:2px;">📅 ${fmtLeaveRange(getActiveLeaveRange(e))}</div>
          <span class="pill" style="background:${s.bg};color:${s.color};border:1px solid ${s.border};font-size:9.5px;margin-top:3px;display:inline-block;">สถานะเดิม: ${skeIcon(s.ic)} ${esc(s.label)}</span>
        </div>
        ${adminRole==='viewer'?'':`<button class="btn btn-sm btn-green" style="padding:6px 9px;font-size:10.5px;white-space:nowrap;" onclick="adminClearLeaveToNormal('${e.id}')">✅ ทำงานปกติ</button>`}
      </div>`;
    });
    html+='</div></div>';
  }

  return html;
}

// ── แท็บ "ลา" แยกต่างหาก — รวมรายชื่อพนักงานที่แจ้งลาทั้งหมด พร้อมปุ่มอนุมัติ/ไม่อนุมัติ ──
function buildLeaveHTML(){
  const isViewer=adminRole==='viewer';
  const onLeaveList=employees.filter(e=>e.onLeave);
  const pending=onLeaveList.filter(e=>!e.leaveApproval||e.leaveApproval==='pending').length;
  const approved=onLeaveList.filter(e=>e.leaveApproval==='approved').length;
  // แสดง "ทุกสถานะ" ในหน้านี้ (รออนุมัติ/อนุมัติแล้ว/ไม่อนุมัติ) — เพื่อให้แอดมินเห็นภาพรวมว่าใครลาวันไหนบ้าง แม้กดอนุมัติไปแล้วก็ยังเห็นสถานะอยู่ในหน้าเดิม
  // (เดิมซ่อนรายการที่อนุมัติแล้วออกจากหน้านี้ ทำให้พอกดอนุมัติปุ๊บ รายการหายไปทันที ต้องไปหาที่ "ดูประวัติการลา" ซึ่งเป็นคนละชุดข้อมูล/มุมมอง)
  // เรียงให้ "รออนุมัติ" ขึ้นก่อนเสมอ (ต้องรีบดำเนินการ) ตามด้วยเรียงตามวันที่เริ่มลาล่าสุด
  // เรียงตามวันที่เริ่มลา จากใกล้ถึงก่อนไปหลังสุด (วันที่น้อยกว่าอยู่บน) — ไม่ระบุวันที่ให้ไปอยู่ท้ายสุด
  const visibleList=onLeaveList.slice().sort((a,b)=>{
    if(!a.leaveFrom&&!b.leaveFrom)return 0;
    if(!a.leaveFrom)return 1;
    if(!b.leaveFrom)return -1;
    return a.leaveFrom<b.leaveFrom?-1:a.leaveFrom>b.leaveFrom?1:0;
  });
  if(!onLeaveList.length){
    return '<div class="empty-state"><div class="empty-icon">'+skeIcon('leave')+'</div><div class="empty-text">ไม่มีพนักงานลาในขณะนี้</div></div>';
  }
  let html=`
  <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-bottom:14px;">
    <div style="background:#fff;border-radius:14px;padding:10px 6px;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,.06);border:1.5px solid #E8EAF0;">
      <div style="font-size:22px;font-weight:900;color:#475569;">${onLeaveList.length}</div>
      <div style="font-size:10px;color:#888;margin-top:2px;">${skeIcon('leave')} ลาทั้งหมด</div>
    </div>
    <div style="background:${pending>0?'#FFFBEB':'#fff'};border-radius:14px;padding:10px 6px;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,.06);border:1.5px solid ${pending>0?'#FCD34D':'#E8EAF0'};">
      <div style="font-size:22px;font-weight:900;color:${pending>0?'#92400E':'#1E90D6'};">${pending}</div>
      <div style="font-size:10px;color:#888;margin-top:2px;">🕐 รออนุมัติ</div>
    </div>
    <div style="background:#F0FDF4;border-radius:14px;padding:10px 6px;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,.06);border:1.5px solid #86EFAC;">
      <div style="font-size:22px;font-weight:900;color:#10B981;">${approved}</div>
      <div style="font-size:10px;color:#888;margin-top:2px;">✅ อนุมัติแล้ว</div>
    </div>
  </div>
  <div style="display:flex;flex-direction:column;gap:8px;">
    ${visibleList.map(e=>{
      const pill=leaveApprovalPill(e);
      const hasReply=!!e.leaveReply;
      return`<div class="card" style="padding:12px;">
        <div style="display:flex;align-items:flex-start;gap:10px;">
          <div class="avatar" style="width:36px;height:36px;font-size:15px;flex-shrink:0;">${esc(e.name.charAt(0))}${leaveIcon(e)}</div>
          <div style="flex:1;min-width:0;">
            <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;">
              <span style="font-size:13.5px;font-weight:700;color:#1a1a2e;">${esc(e.name)}</span>
              <span class="pill" style="background:${pill.bg};color:${pill.color};border:1px solid ${pill.border};font-size:9px;padding:1px 7px;">${pill.text}</span>
            </div>
            <div style="font-size:11px;color:#888;margin-top:2px;">🚘 ${esc(e.plate||'-')}${phoneLink(e.phone)}${lineLink(e.lineId)}</div>
            <div style="font-size:12px;color:#475569;margin-top:3px;">📅 ${fmtLeaveRange(getActiveLeaveRange(e))}${e.leaveNote?` · ${skeIcon('note')} ${esc(e.leaveNote)}`:''}</div>
          </div>
        </div>
        ${isViewer?'':`<div style="display:flex;gap:6px;margin-top:10px;">
          <button class="btn btn-sm ${e.leaveApproval==='approved'?'btn-green':'btn-gray'}" style="flex:1;font-size:11.5px;" onclick="setLeaveApproval('${e.id}','approved')">✅ อนุมัติ</button>
          <button class="btn btn-sm ${e.leaveApproval==='rejected'?'btn-red':'btn-gray'}" style="flex:1;font-size:11.5px;" onclick="setLeaveApproval('${e.id}','rejected')">❌ ไม่อนุมัติ</button>
        </div>`}
        <div style="margin-top:9px;border-top:1px solid #F1F5F9;padding-top:8px;">
          ${isViewer?
            (hasReply?`<div style="font-size:11px;color:#1E90D6;font-weight:600;">💬 ${esc(e.leaveReply)}<span style="color:#aaa;font-weight:400;"> · ${fmt(e.leaveReplyAt)}</span></div>`:'')
          :`
          <button type="button" style="background:none;border:none;padding:0;width:100%;display:flex;align-items:center;gap:5px;cursor:pointer;color:#1E90D6;font-size:11.5px;font-weight:700;" onclick="const b=document.getElementById('lrbox_${e.id}');b.classList.toggle('hidden');this.querySelector('.lrarrow').style.transform=b.classList.contains('hidden')?'rotate(0deg)':'rotate(180deg)';">
            <span>${skeIcon('note')}</span>
            <span style="flex:1;text-align:left;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${hasReply?esc(e.leaveReply):'ส่งข้อความถึงพนักงาน'}</span>
            ${hasReply?`<span style="color:#aaa;font-weight:400;flex-shrink:0;">${fmt(e.leaveReplyAt)}</span>`:''}
            <span class="lrarrow" style="transition:.2s;flex-shrink:0;">▾</span>
          </button>
          <div id="lrbox_${e.id}" class="hidden" style="margin-top:8px;">
            <textarea class="inp" id="lr_${e.id}" rows="2" placeholder="เช่น อนุมัติแล้ว กลับมาตรงเวลานะครับ / ติดต่อหัวหน้าก่อนกลับ..." style="font-size:12.5px;">${esc(e.leaveReply||'')}</textarea>
            <button class="btn btn-blue btn-sm btn-full" style="margin-top:6px;" onclick="saveLeaveReply('${e.id}')">💬 ${hasReply?'อัพเดทข้อความ':'ส่งข้อความถึงพนักงาน'}</button>
          </div>`}
        </div>
      </div>`;
    }).join('')}
  </div>`;
  return html;
}

// ── ตัวเลขแจ้งเตือนบนแท็บ "ลา" — จำนวนพนักงานที่กำลังลาอยู่ตอนนี้ ──
function updateLeaveBadge(){
  const badge=document.getElementById('leaveTabBadge');
  const navBadge=document.getElementById('navLeaveNavBadge');
  const moreBadge=document.getElementById('adminMoreLeaveBadge');
  const n=_countNewLeave();
  [badge,navBadge,moreBadge].forEach(b=>{if(!b)return;if(n>0){b.textContent=n;b.classList.remove('hidden');}else b.classList.add('hidden');});
}

// รายชื่อพนักงานแบบเรียบ (ไม่จัดกลุ่มจังหวัด) ใช้กับสถานะอื่นๆ ที่ไม่ใช่ standby/traveling
function renderStatusEmployeeList(st){
  const todayISO=todayStrJP();
  const list=_dedupByPlate(employees).filter(e=>{
    if(e.status!==st.id||isLeaveActiveToday(e))return false;
    // รถร่วมในสถานะ "ได้งานแล้ว" — ถ้าวันที่ของงานที่จ่ายไปไม่ตรงกับวันนี้อีกต่อไป (ผ่านไปแล้ว) ให้หายจากลิสต์นี้ไปเลย
    // เพราะรถร่วมไม่ได้ใช้แอปเอง ไม่มีทางอัพเดทสถานะตัวเองเมื่อจบงานแล้ว ถ้าไม่กรองจะค้างโชว์เป็นข้อมูลเก่าเรื่อยๆ
    // (ไม่แตะ/ไม่เปลี่ยนสถานะจริงในฐานข้อมูลเลย แค่ไม่นำมาแสดงในลิสต์นี้เท่านั้น ยังดูได้จากหน้าจัดการพนักงานตามปกติ)
    if(st.id==='got_job'&&e.position==='รถร่วม'&&e.jobWorkDate&&e.jobWorkDate!==todayISO)return false;
    return true;
  });
  if(!list.length)return'';
  list.sort((a,b)=>(b.updatedAt||'')>(a.updatedAt||'')?1:-1);
  let html=`<div style="margin-top:8px;padding-top:8px;border-top:1px solid #E8EAF0;display:flex;flex-direction:column;gap:6px;">`;
  list.forEach(e=>{
    const t=e.updatedAt;
    const timeStr=t?fmt(t):'ไม่ระบุ';
    html+=`<div style="display:flex;align-items:flex-start;gap:6px;padding:5px 8px;background:${st.bg};border-radius:7px;border:1.5px solid ${st.border};">
      <span style="font-size:14px;color:${st.color};">${skeIcon(st.ic)}</span>
      <div style="flex:1;min-width:0;">
        <div style="font-size:12px;font-weight:700;color:${st.color};white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${esc(e.name)}</div>
        <div style="font-size:11px;color:#888;">🚘 ${esc(e.plate||'-')}${phoneLink(e.phone)}${lineLink(e.lineId)}</div>
        ${leaveTodayBadge(e)}${e.note?`<div style="font-size:11px;color:${st.color};margin-top:1px;">${skeIcon('note')} ${esc(e.note)}</div>`:''}
      </div>
      <span style="font-size:10px;color:#888;white-space:nowrap;">🕐 ${timeStr}</span>
    </div>`;
  });
  html+='</div>';
  return html;
}

function renderStandbyByProv(){
  const standby=_dedupByPlate(employees).filter(e=>e.status==='standby'&&!isLeaveActiveToday(e));
  if(!standby.length)return'';
  const byProv={};
  standby.forEach(e=>{const p=e.province||'ไม่ระบุจังหวัด';if(!byProv[p])byProv[p]=[];byProv[p].push(e);});
  // เรียงตามเวลาแสตนบาย (เก่าสุดก่อน = ลำดับคิวต้น)
  Object.values(byProv).forEach(list=>list.sort((a,b)=>(a.standbyAt||a.updatedAt||'')>(b.standbyAt||b.updatedAt||'')?1:-1));
  const sorted=Object.entries(byProv).sort((a,b)=>b[1].length-a[1].length);
  let html='<div style="margin-top:8px;padding-top:8px;border-top:1px solid #E8EAF0;display:flex;flex-direction:column;gap:6px;">';
  sorted.forEach(([prov,list])=>{
    html+=`<div style="margin-bottom:4px;">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px;">
        <span style="color:#6D28D9;font-size:12px;font-weight:700;">${skeIcon('pin')} ${prov}</span>
        <span style="background:#F5F3FF;color:#7B2FBE;border-radius:12px;padding:2px 10px;font-size:11px;font-weight:700;">${list.length} คัน</span>
      </div>`;
    list.forEach((e,i)=>{
      const t=e.standbyAt||e.updatedAt;
      const timeStr=t?fmt(t):'ไม่ระบุ';
      html+=`<div style="display:flex;align-items:flex-start;gap:6px;padding:5px 8px;background:${i===0?'#F5F3FF':'#fafafa'};border-radius:7px;border:1.5px solid ${i===0?'#C4B5FD':'#E8EAF0'};">
        <span style="font-size:11px;font-weight:800;color:${i===0?'#7B2FBE':'#aaa'};min-width:16px;padding-top:1px;">#${i+1}</span>
        <div style="flex:1;min-width:0;">
          <div style="font-size:12px;color:#333;font-weight:${i===0?'700':'400'};">${esc(e.name)} · ${esc(e.plate||'-')}${phoneLink(e.phone)}${lineLink(e.lineId)}</div>
          ${leaveTodayBadge(e)}${e.note?`<div style="font-size:11px;color:#7B2FBE;margin-top:1px;">${skeIcon('note')} ${esc(e.note)}</div>`:''}
        </div>
        <span style="font-size:10px;color:#888;white-space:nowrap;padding-top:1px;">⏱️ ${timeStr}</span>
      </div>`;
    });
    html+='</div>';
  });
  html+='</div>';
  return html;
}


function openStatusModal(){
  if(!currentUser)return;
  const me=employees.find(e=>e.id===currentUser.id)||currentUser;
  if(!me)return;
  _selStatus=me.status;
  _selProv=me.province||'';
  closeStatusModal(false);
  editOpen=true; // สำคัญ: กันไม่ให้ renderDashboard (ที่ทำงานพื้นหลังตอนมีข้อมูลอัพเดทจากคนอื่น) มาทับค่าที่กำลังกรอกอยู่ในฟอร์มนี้
  const modal=document.createElement('div');
  modal.id='statusEditModal';
  modal.className='status-modal';
  modal.innerHTML=`
    <div class="status-sheet" onclick="event.stopPropagation()">
      <div class="status-sheet-head">
        <div>
          <div class="status-sheet-title">แก้ไขสถานะรถ</div>
          <div class="status-sheet-sub">${esc(me.name)} · ${esc(me.plate||'-')}</div>
        </div>
        <button class="status-close" onclick="closeStatusModal()">✕</button>
      </div>
      <div class="inp-label">เลือกสถานะ</div>
      <div class="status-grid">${STATUSES.map(st=>{
        const meOffice=!isDrivingPosition(me.position);
        const disabled=meOffice&&st.id==='standby';
        return`
        <button type="button" class="status-opt ${_selStatus===st.id?'sel':''}" id="sopt_${st.id}" ${disabled?'disabled':''}
          style="border-color:${_selStatus===st.id?st.color:'#E8EAF0'};color:${disabled?'#CBD5E1':(_selStatus===st.id?st.color:'#888')};background:${disabled?'#F8FAFC':(_selStatus===st.id?st.bg:'#F5F6FA')};${disabled?'cursor:not-allowed;':''}"
          ${disabled?'':`onclick="selStat('${st.id}')"`}><span class="status-emoji" style="color:${disabled?'#CBD5E1':st.color}">${skeIcon(st.ic)}</span><br>${st.label}</button>`;}).join('')}</div>
      <div id="provWrap">${(!isDrivingPosition(me.position)||!me.plate)?'<div style="font-size:11.5px;color:#94A3B8;background:#F8FAFC;border:1px dashed #CBD5E1;border-radius:8px;padding:8px 10px;">📍 ไม่ต้องระบุจังหวัดสแตนบาย (พนักงานออฟฟิศ)</div>':provHTML(_selStatus,_selProv)}</div>
      <div class="inp-label" style="margin-top:10px;">หมายเหตุ</div>
      <textarea id="noteInp" rows="2" class="inp" style="width:100%;" placeholder="หมายเหตุ (ไม่บังคับ)">${esc(me.note||'')}</textarea>
      <button class="btn btn-blue btn-full" style="margin-top:12px;" onclick="doSave()">✓ บันทึกสถานะ</button>
    </div>`;
  modal.addEventListener('click',()=>closeStatusModal());
  document.body.appendChild(modal);
}
function closeStatusModal(reset=true){
  const m=document.getElementById('statusEditModal');
  if(m)m.remove();
  if(reset){editOpen=false;}
}

function showEmployeeStatusSavedPopup(){
  const old=document.getElementById('empStatusSavedPopup');
  if(old)old.remove();
  const pop=document.createElement('div');
  pop.id='empStatusSavedPopup';
  pop.className='emp-success-pop';
  pop.innerHTML=`
    <div class="emp-success-card" onclick="event.stopPropagation()">
      <div class="emp-success-icon">✓</div>
      <div class="emp-success-title">บันทึกสำเร็จ</div>
      <div class="emp-success-sub">สถานะรถของคุณอัปเดตเรียบร้อยแล้ว</div>
      <button class="emp-success-btn" onclick="closeEmployeeStatusSavedPopup()">ตกลง</button>
    </div>`;
  pop.addEventListener('click',closeEmployeeStatusSavedPopup);
  document.body.appendChild(pop);
  clearTimeout(window._empStatusSavedTimer);
  window._empStatusSavedTimer=setTimeout(closeEmployeeStatusSavedPopup,2200);
}
function closeEmployeeStatusSavedPopup(){
  const pop=document.getElementById('empStatusSavedPopup');
  if(!pop)return;
  pop.classList.add('hide');
  clearTimeout(window._empStatusSavedTimer);
  setTimeout(()=>{const p=document.getElementById('empStatusSavedPopup');if(p)p.remove();},190);
}

function toggleEdit(){openStatusModal();}

function selStat(id){
  // อ่านค่าจังหวัดจาก dropdown ก่อน re-render เพื่อไม่ให้หาย
  const curSel=document.getElementById('provSel');
  if(curSel)_selProv=curSel.value;
  _selStatus=id;
  STATUSES.forEach(st=>{
    const b=document.getElementById('sopt_'+st.id);if(!b)return;
    b.style.borderColor=id===st.id?st.color:'#E8EAF0';
    b.style.color=id===st.id?st.color:'#888';
    b.style.background=id===st.id?st.bg:'#F5F6FA';
    b.classList.toggle('sel',id===st.id); // สำคัญ: ต้อง toggle class จริงด้วย ไม่ใช่แค่ inline style กันตอนบันทึกตรวจปุ่มที่เลือกอยู่จริงผิดพลาด
  });
  const w=document.getElementById('provWrap');
  if(w){
    const isOffice=!isDrivingPosition(currentUser?.position)||!(currentUser&&currentUser.plate);
    w.innerHTML=isOffice?'<div style="font-size:11.5px;color:#94A3B8;background:#F8FAFC;border:1px dashed #CBD5E1;border-radius:8px;padding:8px 10px;">📍 ไม่ต้องระบุจังหวัดสแตนบาย (พนักงานออฟฟิศ)</div>':provHTML(id,(id==='standby'||id==='traveling'||id==='returning'||id==='done')?_selProv:'');
  }
}

async function doSave(){
  // อ่านสถานะที่กำลังเลือกอยู่จริงจากปุ่มที่ถูกไฮไลต์บนจอเป็นหลัก ไม่พึ่งตัวแปร _selStatus เพียงอย่างเดียว
  // (กันกรณีข้อมูลพื้นหลังอัพเดทมาทับตัวแปรระหว่างที่ฟอร์มเปิดค้างอยู่ ทำให้บันทึกสถานะ/จังหวัดผิดไปจากที่เห็นบนจอจริง)
  const selectedBtn=document.querySelector('#statusEditModal .status-opt.sel');
  if(selectedBtn?.id)_selStatus=selectedBtn.id.replace('sopt_','');
  const note=document.getElementById('noteInp')?.value||'';
  const provSel=document.getElementById('provSel');
  // พนักงานตำแหน่งออฟฟิศ (เช่นแอดมิน) หรือไม่มีทะเบียนรถผูกอยู่ ไม่ต้องเลือกจังหวัดสแตนบาย
  const isOffice=!isDrivingPosition(currentUser?.position)||!(currentUser&&currentUser.plate);
  if(isOffice&&_selStatus==='standby'){
    alert('⚠️ ตำแหน่งนี้ไม่สามารถเลือกสถานะ "สแตนบายรอขึ้นงาน" ได้');
    return;
  }
  const needProv=!isOffice&&(_selStatus==='standby'||_selStatus==='traveling'||_selStatus==='returning'||_selStatus==='done');
  const prov=needProv?(provSel?provSel.value:_selProv)||'':'';
  if(needProv&&!prov){
    alert('⚠️ กรุณาเลือกจังหวัดก่อนบันทึกสถานะ');
    if(provSel){provSel.focus();provSel.style.borderColor='#DC2626';provSel.style.boxShadow='0 0 0 2px #FCA5A5';}
    return;
  }
  if(needProv&&!isValidProvince(prov)){
    alert('⚠️ ไม่พบจังหวัดนี้ในรายชื่อ กรุณาเลือกจากรายการที่พิมพ์ขึ้นมา (พิมพ์แล้วแตะเลือกจากลิสต์)');
    if(provSel){provSel.focus();provSel.style.borderColor='#DC2626';provSel.style.boxShadow='0 0 0 2px #FCA5A5';}
    return;
  }
  const now=new Date().toISOString();
  // บันทึก standbyAt เมื่อเปลี่ยนมาเป็น standby ครั้งแรก
  const prev=employees.find(e=>e.id===currentUser.id);
  const standbyAt=(_selStatus==='standby'&&prev?.status!=='standby')?now:(prev?.standbyAt||null);
  const patch={status:_selStatus,province:prov,note,updatedAt:now,standbyAt:_selStatus==='standby'?standbyAt:null};
  recordRunLogIfNeeded(prev,_selStatus,note,currentUser.id,prev?.plate||currentUser.plate,prev?.name||currentUser.name);
  employees=employees.map(e=>e.id===currentUser.id?{...e,...patch}:e);
  currentUser={...currentUser,...patch};
  saveU();editOpen=false;closeStatusModal(false);renderDashboard();
  _cacheSet('ske_emp', employees);
  // รอผลการบันทึกจริงก่อนแจ้งผล — เดิมยิงแบบไม่รอผลแล้วโชว์ "บันทึกสำเร็จ" ทันที
  // ทำให้เน็ตสะดุดแล้วพนักงานเห็น "สำเร็จ" ทั้งที่ยังไม่ถึงเซิร์ฟเวอร์จริง ต้องกดซ้ำหลายรอบกว่าจะติด
  try{
    if(window.fbUpdateEmployeeFields){
      await fbPatchEmployee(currentUser.id,patch);
    } else if(window.fbSaveEmployees){
      await window.fbSaveEmployees(employees);
    }
    showEmployeeStatusSavedPopup();
  }catch(e){
    // เน็ตช้า/หลุด — ข้อมูลถูกคิวไว้ใน outbox แล้ว (ระบบส่งซ้ำอัตโนมัติทุก 8 วิ) ไม่ต้องให้กดซ้ำ กันสถานะซ้อนกัน
    console.warn('doSave: บันทึกไม่สำเร็จในทันที รอคิวส่งซ้ำอัตโนมัติ',e);
    showDocUploadToast('⚠️ เน็ตช้า/หลุดอยู่ — ระบบจะส่งสถานะนี้ต่อให้อัตโนมัติเมื่อสัญญาณกลับมา ไม่ต้องกดซ้ำ',false);
  }
  // reset timer หลังอัพเดทสถานะ
  startAlertTimer();
}

// ══ Export บันทึกเที่ยววิ่งเป็น CSV (สำหรับแอดมินเก็บถาวรก่อนข้อมูลถูกลบอัตโนมัติตามอายุ 3 เดือน) ══
function exportRunLogsCSV(){
  if(!runLogs||!runLogs.length){alert('ยังไม่มีข้อมูลบันทึกเที่ยววิ่งให้ดาวน์โหลด');return;}
  const rows=[['วันที่-เวลา','ชื่อพนักงาน','ทะเบียนรถ','จำนวนเที่ยว','รายละเอียด']];
  runLogs.slice().sort((a,b)=>new Date(a.createdAt)-new Date(b.createdAt)).forEach(r=>{
    rows.push([r.createdAt?fmt(r.createdAt):'',r.name||'',r.plate||'',r.trips||1,String(r.detail||'').replace(/\r?\n/g,' | ')]);
  });
  const esc2=v=>{const s=String(v);return /[",\n]/.test(s)?'"'+s.replace(/"/g,'""')+'"':s;};
  const csv='\uFEFF'+rows.map(row=>row.map(esc2).join(',')).join('\r\n'); // \uFEFF = BOM กัน Excel อ่านภาษาไทยเพี้ยน
  const blob=new Blob([csv],{type:'text/csv;charset=utf-8;'});
  const url=URL.createObjectURL(blob);
  const a=document.createElement('a');
  a.href=url;a.download='บันทึกเที่ยววิ่ง_'+new Date().toISOString().slice(0,10)+'.csv';
  document.body.appendChild(a);a.click();a.remove();
  setTimeout(()=>URL.revokeObjectURL(url),3000);
}

// ══ เครื่องมือย้ายรูปเก่าเข้าคลังรูปใหม่ (รันครั้งเดียวโดยผู้ดูแล หลังอัพเดทระบบ) ══
// เดินไล่ทุกรายการที่ยังฝังรูป base64 อยู่ในข้อมูลหลัก → อัพรูปเข้าคลัง photos/ → แทนที่ด้วยรหัส
// จบแล้วบันทึกข้อมูลหลัก (ตอนนี้เหลือแต่ข้อความ เบามาก) ขึ้น Firebase หนึ่งรอบ
async function migratePhotosToStore(){
  if(!confirm('ย้ายรูปทั้งหมดไปคลังรูปแบบใหม่?\n\n• ใช้ครั้งเดียวหลังอัพเดทระบบ\n• แนะนำให้ทำบน WiFi\n• ห้ามปิดแอพระหว่างทำ'))return;
  showDocUploadPopup('กำลังย้ายรูปเข้าคลังใหม่','ห้ามปิดหน้านี้จนกว่าจะเสร็จ');
  let moved=0;
  const conv=async v=>{
    if(v&&String(v).startsWith('data:')){
      const pid=await uploadPhoto(v);
      moved++;
      updateDocUploadPopup('กำลังย้ายรูปเข้าคลังใหม่','ย้ายแล้ว '+moved+' รูป...');
      return pid;
    }
    return v;
  };
  try{
    for(const e of employees){ if(e&&e.photo)e.photo=await conv(e.photo); }
    for(const r of repairs){
      if(!r)continue;
      if(Array.isArray(r.photos))for(let i=0;i<r.photos.length;i++)r.photos[i]=await conv(r.photos[i]);
      if(Array.isArray(r.empPhotos))for(let i=0;i<r.empPhotos.length;i++)r.empPhotos[i]=await conv(r.empPhotos[i]);
    }
    for(const f of fluidLogs){ if(f&&Array.isArray(f.photos))for(let i=0;i<f.photos.length;i++)f.photos[i]=await conv(f.photos[i]); }
    for(const d of (monthlyDocs||[])){ if(d&&d.photo)d.photo=await conv(d.photo); }
    updateDocUploadPopup('กำลังบันทึกข้อมูลหลัก','ย้ายรูปครบ '+moved+' รูป — กำลังบันทึกโครงสร้างใหม่');
    _cacheSet('ske_emp',employees);
    _cacheSet('ske_repairs',repairs);
    _cacheSet('ske_fluid',fluidLogs);
    _cacheSet('ske_monthly_docs',monthlyDocs||[]);
    if(window.fbSaveEmployees)await window.fbSaveEmployees(employees);
    if(window.fbSaveRepairs)await window.fbSaveRepairs(repairs);
    if(window.fbSaveFluidLogs)await window.fbSaveFluidLogs(fluidLogs);
    if(window.fbSaveMonthlyDocs)await window.fbSaveMonthlyDocs(monthlyDocs||[]);
    hideDocUploadPopup();
    alert('✅ เสร็จเรียบร้อย! ย้ายรูปเข้าคลังใหม่แล้ว '+moved+' รูป\nตั้งแต่ตอนนี้แอพจะโหลดเบาลงและประหยัดเน็ตมาก');
    location.reload();
  }catch(e){
    console.error('migrate error',e);
    hideDocUploadPopup();
    alert('❌ ย้ายไม่สำเร็จ: '+(e&&e.message?e.message:'เน็ตอาจหลุดกลางทาง')+'\n\nกดปุ่มเดิมเพื่อทำต่อได้เลย — รูปที่ย้ายไปแล้ว ('+moved+' รูป) จะไม่ถูกย้ายซ้ำ');
  }
}

// ── Admin ─────────────────────────────────────────────────────────────────────
function goAdmin(){show('admin');renderAdmin();switchAdminTab('summary');applyAdminRoleUI();startAdminAlertTimer();}
function goBack(){
  // ปุ่ม "กลับ" ต้องไม่ทำให้ออกจากระบบเด็ดขาด
  // ถ้ามีพนักงาน login อยู่ → กลับไปหน้าหลักของพนักงานคนนั้น
  if(currentUser){stopAdminAlertTimer();show('dashboard');renderDashboard();return;}
  // ถ้าเข้ามาแบบผู้ดูแลอย่างเดียว (ไม่มี currentUser) → อยู่ในแผงผู้ดูแลต่อ ไม่เด้งไปหน้า login
  if(adminMode){show('admin');renderAdmin();switchAdminTab('summary');applyAdminRoleUI();startAdminAlertTimer();return;}
  // กรณีอื่นๆ (ไม่ได้ login เลยจริงๆ) ค่อยกลับไปหน้าเลือกชื่อ
  stopAdminAlertTimer();
  show('login');renderEmpList();showMode('select');
}


function getMonthlyDocCounts(monthKey=_docMonthKey()){
  const docs=(monthlyDocs||[]).filter(x=>x&&x.monthKey===monthKey);
  const pending=docs.filter(x=>(x.status||'pending')==='pending').length;
  const approved=docs.filter(x=>x.status==='approved').length;
  const rejected=docs.filter(x=>x.status==='rejected').length;
  // ตรวจสอบเอกสารเฉพาะตำแหน่ง "พนักงานขับรถ" เท่านั้น — ตำแหน่งอื่น (รถร่วม/แอดมิน/ฝ่ายบุคคล/ช่างซ่อม) ไม่ต้องส่งเอกสารเข้าส่วนกลาง
  const missing=employees.filter(e=>isDrivingPosition(e.position)&&!getMonthlyDocSubmission(e.id,monthKey)).length;
  return {pending,approved,rejected,missing,total:docs.length};
}
function updateAdminDocBadge(){
  const n=getMonthlyDocCounts().pending;
  const b=document.getElementById('navDocNavBadge');
  if(!b)return;
  if(n>0){b.textContent=n;b.classList.remove('hidden');}else b.classList.add('hidden');
}
function renderAdminDocPanel(){
  const stats=document.getElementById('adminDocStats');
  const listEl=document.getElementById('adminDocList');
  if(!stats||!listEl)return;
  const monthKey=_docMonthKey();
  const c=getMonthlyDocCounts(monthKey);
  stats.innerHTML=`<div class="section-label">📄 เอกสารส่วนกลาง ${esc(_docMonthTH(monthKey))}</div>
    <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:8px;margin-bottom:12px;">
      <div style="background:#FFFBEB;border:1.5px solid #F59E0B;border-radius:12px;padding:10px;text-align:center;"><div style="font-size:20px;font-weight:900;color:#92400E;">${c.pending}</div><div style="font-size:11px;color:#92400E;">รอตรวจ</div></div>
      <div style="background:#ECFDF5;border:1.5px solid #10B981;border-radius:12px;padding:10px;text-align:center;"><div style="font-size:20px;font-weight:900;color:#065F46;">${c.approved}</div><div style="font-size:11px;color:#065F46;">อนุมัติแล้ว</div></div>
      <div style="background:#FEF2F2;border:1.5px solid #EF4444;border-radius:12px;padding:10px;text-align:center;"><div style="font-size:20px;font-weight:900;color:#991B1B;">${c.rejected}</div><div style="font-size:11px;color:#991B1B;">ไม่อนุมัติ</div></div>
      <div style="background:#F8FAFC;border:1.5px solid #CBD5E1;border-radius:12px;padding:10px;text-align:center;cursor:pointer;" onclick="document.getElementById('adminDocMissingAnchor')?.scrollIntoView({behavior:'smooth',block:'start'})"><div style="font-size:20px;font-weight:900;color:#475569;">${c.missing}</div><div style="font-size:11px;color:#475569;">ยังไม่ส่ง</div></div>
    </div>`;
  const docs=[...(monthlyDocs||[]).filter(x=>x&&x.monthKey===monthKey)].sort((a,b)=>{
    const rank={pending:0,rejected:1,approved:2};
    return (rank[a.status||'pending']??9)-(rank[b.status||'pending']??9) || (b.submittedAt||0)-(a.submittedAt||0);
  });
  // รายชื่อพนักงานที่ "ยังไม่ส่ง" เอกสารเดือนนี้ — เฉพาะตำแหน่ง "พนักงานขับรถ" เท่านั้น ตำแหน่งอื่นไม่ต้องส่งเอกสารเข้าส่วนกลาง
  const missingEmps=(employees||[]).filter(e=>isDrivingPosition(e.position)&&!getMonthlyDocSubmission(e.id,monthKey)).sort((a,b)=>String(a.name||'').localeCompare(String(b.name||''),'th'));
  const missingHTML=missingEmps.length?`
    <div id="adminDocMissingAnchor" class="section-label" style="margin-top:18px;color:#475569;">📭 ยังไม่ส่งเอกสาร (${missingEmps.length} คน)</div>
    <div style="display:flex;flex-direction:column;gap:6px;margin-bottom:10px;">
      ${missingEmps.map(e=>`<div class="card" style="padding:9px 12px;border:1.5px solid #CBD5E1;background:#F8FAFC;">
        <div style="font-size:13px;font-weight:900;color:#1a1a2e;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${esc(e.name||'-')}</div>
      </div>`).join('')}
    </div>` : '';
  if(!docs.length){listEl.innerHTML='<div class="empty">ยังไม่มีพนักงานส่งเอกสารเดือนนี้</div>'+missingHTML;return;}
  listEl.innerHTML=docs.map(d=>{
    const emp=employees.find(e=>e.id===d.empId)||{};
    const st=_docStatusPill(d.status||'pending');
    if(d.status==='approved'){
      // อนุมัติแล้ว — ย่อเหลือแถวเดียวเพื่อให้เห็นครบทุกคนในหน้าเดียวโดยไม่ต้องเลื่อนเยอะ
      return `<div class="card" style="margin-bottom:8px;padding:9px 12px;border:1.5px solid ${st.bd};display:flex;align-items:center;gap:8px;">
        <div style="min-width:0;flex:1;">
          <div style="font-size:13px;font-weight:900;color:#1a1a2e;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${esc(d.empName||emp.name||'-')}</div>
          <div style="font-size:11px;color:#888;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">🚛 ${esc(d.plate||emp.plate||'-')}</div>
        </div>
        <span style="font-size:10.5px;font-weight:900;padding:3px 9px;border-radius:999px;background:${st.bg};color:${st.color};border:1px solid ${st.bd};white-space:nowrap;flex-shrink:0;">✅ อนุมัติแล้ว</span>
        ${d.photo?`<button class="btn btn-gray btn-sm" style="flex-shrink:0;padding:5px 8px;font-size:11px;" onclick="openPhotoViewer('${d.photo}')">🖼️</button>`:''}
      </div>`;
    }
    return `<div class="card" style="margin-bottom:10px;border:1.5px solid ${st.bd};">
      <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:8px;">
        <div style="min-width:0;flex:1;"><div style="font-size:14px;font-weight:900;color:#1a1a2e;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${esc(d.empName||emp.name||'-')}</div>
        <div style="font-size:12px;color:#666;">🚛 ${esc(d.plate||emp.plate||'-')}${phoneLink(d.phone||emp.phone)}${lineLink(d.lineId||emp.lineId)}</div>
        <div style="font-size:11px;color:#888;margin-top:2px;">ส่งเมื่อ: ${fmt(d.submittedAt||d.at)}</div></div>
        <span style="font-size:11px;font-weight:900;padding:4px 8px;border-radius:999px;background:${st.bg};color:${st.color};border:1px solid ${st.bd};white-space:nowrap;">${st.text.replace('ส่วนกลางตรวจสอบเอกสารเรียบร้อยแล้ว','อนุมัติแล้ว').replace('เอกสารถูกไม่อนุมัติ กรุณาแนบรูปส่งใหม่','ไม่อนุมัติ').replace('รอส่วนกลางตรวจสอบเอกสาร','รอตรวจ')}</span>
      </div>
      ${d.photo?`<div style="margin-top:9px;"><img data-ph="${d.photo}" style="width:100%;max-height:220px;object-fit:cover;border-radius:12px;border:1px solid #E5E7EB;" onclick="openPhotoViewer('${d.photo}')"></div>`:''}
      ${d.rejectReason?`<div style="font-size:12px;color:#991B1B;margin-top:6px;background:#FEF2F2;border-radius:8px;padding:7px;">เหตุผลไม่อนุมัติ: ${esc(d.rejectReason)}</div>`:''}
      <div style="display:flex;gap:8px;margin-top:10px;">
        <button class="btn btn-green" style="flex:1;font-size:12px;" onclick="approveMonthlyDoc('${d.id}')">✅ อนุมัติ</button>
        <button class="btn btn-red" style="flex:1;font-size:12px;" onclick="rejectMonthlyDoc('${d.id}')">❌ ไม่อนุมัติ</button>
      </div>
    </div>`;
  }).join('')+missingHTML;
}
async function approveMonthlyDoc(id){
  const r=(monthlyDocs||[]).find(x=>x&&x.id===id);
  if(!r){alert('ไม่พบรายการเอกสาร');return;}
  if(!confirm('ยืนยันอนุมัติเอกสารนี้?'))return;
  const patch={status:'approved',reviewedAt:Date.now(),reviewedBy:'admin',rejectReason:''};
  try{
    if(window.fbUpdateMonthlyDocFields){
      await window.fbUpdateMonthlyDocFields(id,patch).catch(async()=>{
        monthlyDocs=monthlyDocs.map(x=>x&&x.id===id?{...x,...patch}:x);
        await saveMonthlyDocs();
      });
    }else{
      monthlyDocs=monthlyDocs.map(x=>x&&x.id===id?{...x,...patch}:x);
      await saveMonthlyDocs();
    }
    renderAdminDocPanel();updateAdminDocBadge();
    if(currentUser&&r.empId===currentUser.id)renderDashboard();
    alert('✅ อนุมัติเอกสารเรียบร้อยแล้ว');
  }catch(e){console.error(e);alert('❌ บันทึกอนุมัติไม่สำเร็จ กรุณาลองใหม่');}
}
async function rejectMonthlyDoc(id){
  const r=(monthlyDocs||[]).find(x=>x&&x.id===id);
  if(!r){alert('ไม่พบรายการเอกสาร');return;}
  const reason=prompt('ระบุเหตุผลที่ไม่อนุมัติ (เช่น รูปไม่ชัด / เอกสารไม่ครบ)')||'';
  const patch={status:'rejected',reviewedAt:Date.now(),reviewedBy:'admin',rejectReason:reason};
  try{
    if(window.fbUpdateMonthlyDocFields){
      await window.fbUpdateMonthlyDocFields(id,patch).catch(async()=>{
        monthlyDocs=monthlyDocs.map(x=>x&&x.id===id?{...x,...patch}:x);
        await saveMonthlyDocs();
      });
    }else{
      monthlyDocs=monthlyDocs.map(x=>x&&x.id===id?{...x,...patch}:x);
      await saveMonthlyDocs();
    }
    renderAdminDocPanel();updateAdminDocBadge();
    if(currentUser&&r.empId===currentUser.id)renderDashboard();
    alert('❌ บันทึกไม่อนุมัติแล้ว พนักงานต้องแนบรูปใหม่');
  }catch(e){console.error(e);alert('❌ บันทึกไม่อนุมัติไม่สำเร็จ กรุณาลองใหม่');}
}

function renderAdmin(){
  renderAdminEmpList();
  renderSysInfo();
  const el=document.getElementById('adminSummaryContent');
  if(el)el.innerHTML=buildSummaryHTML();
  const lc=document.getElementById('adminLeaveContent');
  if(lc)lc.innerHTML=buildLeaveHTML();
  updateAdminMaintBadge();
  updateAdminCashBadge();
  updateStaleBadge();
  updateLeaveBadge();
  updateAdminDocBadge();
  const dp=document.getElementById('adminDocPanel');
  if(dp && !dp.classList.contains('hidden'))renderAdminDocPanel();
  const mp=document.getElementById('adminMaintPanel');
  if(mp && !mp.classList.contains('hidden'))renderAdminMaint();
  const sp=document.getElementById('adminCashPanel');
  if(sp && !sp.classList.contains('hidden'))renderAdminCashList();
}

// ── ตัวเลขแจ้งเตือนบนแท็บ "ภาพรวม" — จำนวนพนักงานที่ไม่อัพเดทสถานะเกิน 24 ชม. (ทุกสถานะ) ──
function updateStaleBadge(){
  const badge=document.getElementById('staleTabBadge');
  const navBadge=document.getElementById('navStaleNavBadge');
  const n=employees.filter(e=>!isLeaveActiveToday(e)&&(!e.updatedAt||(Date.now()-new Date(e.updatedAt))/3600000>=STALE_ALL_HOURS)).length;
  [badge,navBadge].forEach(b=>{if(!b)return;if(n>0){b.textContent=n;b.classList.remove('hidden');}else b.classList.add('hidden');});
}

function renderSysInfo(){
  const el=document.getElementById('sysInfo');
  if(!el)return;
  const now=new Date();
  el.innerHTML=`พนักงานทั้งหมด: <b>${employees.length}</b> คน<br>เวอร์ชันแอพ: <b style="color:#7C3AED;">${SKE_APP_VERSION}</b><br>เวลาปัจจุบัน: <b>${now.toLocaleString('th-TH')}</b><br>ประวัติซ่อมบำรุง: <b>เก็บไว้ 12 เดือน แล้วลบอัตโนมัติ</b><br>รูปภาพแนบ: <b>ลบอัตโนมัติเมื่ออายุเกิน 12 เดือน (ข้อมูลรายการยังอยู่)</b><br>บันทึกเที่ยววิ่ง (6W): <b>เก็บ 3 เดือนปฏิทินล่าสุด แล้วลบอัตโนมัติ — export เก็บถาวรได้ที่ปุ่มด้านบน</b><br>เบิกเงินพนักงาน: <b>เปิดให้กรอกเฉพาะวันที่ 15 ของทุกเดือน</b>`;
}

function renderTravelingByProv(){
  const traveling=_dedupByPlate(employees).filter(e=>e.status==='traveling'&&!isLeaveActiveToday(e));
  if(!traveling.length)return'';
  const byProv={};
  traveling.forEach(e=>{const p=e.province||'ไม่ระบุปลายทาง';if(!byProv[p])byProv[p]=[];byProv[p].push(e);});
  // เรียงตามเวลาออกเดินทาง
  Object.values(byProv).forEach(list=>list.sort((a,b)=>(a.updatedAt||'')>(b.updatedAt||'')?1:-1));
  const sorted=Object.entries(byProv).sort((a,b)=>b[1].length-a[1].length);
  let html='<div style="margin-top:8px;padding-top:8px;border-top:1px solid #E8EAF0;display:flex;flex-direction:column;gap:6px;">';
  sorted.forEach(([prov,list])=>{
    html+=`<div style="margin-bottom:4px;">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px;">
        <span style="color:#0E7490;font-size:12px;font-weight:700;">🏁 ${prov}</span>
        <span style="background:#ECFEFF;color:#0E7490;border-radius:12px;padding:2px 10px;font-size:11px;font-weight:700;">${list.length} คัน</span>
      </div>`;
    list.forEach(e=>{
      const t=e.updatedAt;
      const timeStr=t?fmt(t):'ไม่ระบุ';
      html+=`<div style="display:flex;align-items:flex-start;gap:6px;padding:5px 8px;background:#F0FDFE;border-radius:7px;border:1px solid #A5F3FC;">
        <span style="font-size:14px;">🚛</span>
        <div style="flex:1;min-width:0;">
          <div style="font-size:12px;font-weight:700;color:#0E7490;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${esc(e.name)}</div>
          <div style="font-size:11px;color:#888;">🚘 ${esc(e.plate||'-')}${phoneLink(e.phone)}${lineLink(e.lineId)}</div>
          ${leaveTodayBadge(e)}${e.note?`<div style="font-size:11px;color:#0E7490;margin-top:1px;">${skeIcon('note')} ${esc(e.note)}</div>`:''}
        </div>
        <span style="font-size:10px;color:#888;white-space:nowrap;">🕐 ${timeStr}</span>
      </div>`;
    });
    html+='</div>';
  });
  html+='</div>';
  return html;
}

function renderReturningByProv(){
  const returning=_dedupByPlate(employees).filter(e=>e.status==='returning'&&!isLeaveActiveToday(e));
  if(!returning.length)return'';
  const byProv={};
  returning.forEach(e=>{const p=e.province||'ไม่ระบุจังหวัด';if(!byProv[p])byProv[p]=[];byProv[p].push(e);});
  // เรียงตามเวลาที่เริ่มไหลกลับ
  Object.values(byProv).forEach(list=>list.sort((a,b)=>(a.updatedAt||'')>(b.updatedAt||'')?1:-1));
  const sorted=Object.entries(byProv).sort((a,b)=>b[1].length-a[1].length);
  let html='<div style="margin-top:8px;padding-top:8px;border-top:1px solid #E8EAF0;display:flex;flex-direction:column;gap:6px;">';
  sorted.forEach(([prov,list])=>{
    html+=`<div style="margin-bottom:4px;">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px;">
        <span style="color:#0F766E;font-size:12px;font-weight:700;">🔁 ${esc(prov)}</span>
        <span style="background:#F0FDFA;color:#0F766E;border-radius:12px;padding:2px 10px;font-size:11px;font-weight:700;">${list.length} คัน</span>
      </div>`;
    list.forEach(e=>{
      const t=e.updatedAt;
      const timeStr=t?fmt(t):'ไม่ระบุ';
      html+=`<div style="display:flex;align-items:flex-start;gap:6px;padding:5px 8px;background:#F0FDFA;border-radius:7px;border:1px solid #5EEAD4;">
        <span style="font-size:14px;">🚛</span>
        <div style="flex:1;min-width:0;">
          <div style="font-size:12px;font-weight:700;color:#0F766E;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${esc(e.name)}</div>
          <div style="font-size:11px;color:#888;">🚘 ${esc(e.plate||'-')}${phoneLink(e.phone)}${lineLink(e.lineId)}</div>
          ${leaveTodayBadge(e)}${e.note?`<div style="font-size:11px;color:#0F766E;margin-top:1px;">${skeIcon('note')} ${esc(e.note)}</div>`:''}
        </div>
        <span style="font-size:10px;color:#888;white-space:nowrap;">🕐 ${timeStr}</span>
      </div>`;
    });
    html+='</div>';
  });
  html+='</div>';
  return html;
}

function renderDoneByProv(){
  const done=_dedupByPlate(employees).filter(e=>e.status==='done'&&!isLeaveActiveToday(e));
  if(!done.length)return'';
  const byProv={};
  done.forEach(e=>{const p=e.province||'ไม่ระบุจังหวัด';if(!byProv[p])byProv[p]=[];byProv[p].push(e);});
  // รันคิวตามเวลาที่เริ่มว่างงาน (updatedAt) จากนานสุด→ใหม่สุด — ใครว่างงานนานสุดคือคิวที่ 1 (คิวต่อไปที่ควรได้งานก่อน)
  // ลำดับนี้จะ "คงที่" จนกว่าคนนั้นจะเปลี่ยนสถานะไปจากว่างงานจริงๆ เพราะอิงจาก updatedAt ที่ไม่ขยับถ้าไม่มีการบันทึกสถานะใหม่
  Object.values(byProv).forEach(list=>list.sort((a,b)=>(a.updatedAt||'')>(b.updatedAt||'')?1:-1));
  const sorted=Object.entries(byProv).sort((a,b)=>b[1].length-a[1].length);
  let html='<div style="margin-top:8px;padding-top:8px;border-top:1px solid #E8EAF0;display:flex;flex-direction:column;gap:6px;">';
  sorted.forEach(([prov,list])=>{
    html+=`<div style="margin-bottom:4px;">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px;">
        <span style="color:#065F46;font-size:12px;font-weight:700;">${skeIcon('pin')} ${esc(prov)}</span>
        <span style="background:#ECFDF5;color:#065F46;border-radius:12px;padding:2px 10px;font-size:11px;font-weight:700;">${list.length} คัน</span>
      </div>`;
    list.forEach((e,idx)=>{
      const t=e.updatedAt;
      const timeStr=t?fmt(t):'ไม่ระบุ';
      const q=idx+1;
      html+=`<div style="display:flex;align-items:flex-start;gap:8px;padding:5px 8px;background:#F0FDF4;border-radius:7px;border:1px solid #6EE7B7;">
        <span title="คิวที่ ${q}" style="flex-shrink:0;width:22px;height:22px;border-radius:50%;background:#065F46;color:#fff;font-size:11px;font-weight:800;display:flex;align-items:center;justify-content:center;margin-top:1px;">${q}</span>
        <div style="flex:1;min-width:0;">
          <div style="font-size:12px;font-weight:700;color:#065F46;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${esc(e.name)}</div>
          <div style="font-size:11px;color:#888;">🚘 ${esc(e.plate||'-')}${phoneLink(e.phone)}${lineLink(e.lineId)}</div>
          ${leaveTodayBadge(e)}${e.note?`<div style="font-size:11px;color:#065F46;margin-top:1px;">${skeIcon('note')} ${esc(e.note)}</div>`:''}
        </div>
        <span style="font-size:10px;color:#888;white-space:nowrap;">🕐 ${timeStr}</span>
      </div>`;
    });
    html+='</div>';
  });
  html+='</div>';
  return html;
}


function _adminNormText(v){return String(v||'').toLowerCase().replace(/\s+/g,'').trim();}
function renderAdminQuickSearch(){
  const inp=document.getElementById('adminQuickSearch');
  const box=document.getElementById('adminQuickSearchResults');
  if(!inp||!box)return;
  const q=inp.value.trim();
  const nq=_adminNormText(q);
  if(!nq){box.style.display='none';box.innerHTML='';return;}
  const found=employees.filter(e=>_adminNormText(e.name).includes(nq)||_adminNormText(e.plate).includes(nq)).slice(0,20);
  if(!found.length){
    box.style.display='flex';
    box.innerHTML='<div style="padding:10px;border-radius:10px;background:#F8FAFC;color:#64748B;font-size:12px;text-align:center;">ไม่พบชื่อหรือทะเบียนรถที่ค้นหา</div>';
    return;
  }
  box.style.display='flex';
  box.innerHTML=found.map(e=>{
    const s=getS(e.status);
    return `<button type="button" onclick="focusAdminEmployee('${e.id}')" style="width:100%;text-align:left;border:1px solid #DBEAFE;background:#F8FBFF;border-radius:10px;padding:8px 10px;display:flex;align-items:center;gap:8px;">
      <div class="avatar" style="width:30px;height:30px;font-size:13px;">${esc((e.name||'?').charAt(0))}</div>
      <div style="flex:1;min-width:0;">
        <div style="font-size:13px;font-weight:800;color:#1a1a2e;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${esc(e.name||'-')}</div>
        <div style="font-size:11px;color:#64748B;">🚘 ${esc(e.plate||'-')} · ${esc(s.label||'')}</div>
      </div>
      <span style="color:#1E90D6;font-size:12px;font-weight:700;">ไปหา</span>
    </button>`;
  }).join('');
}
function focusAdminEmployee(empId){
  const e=employees.find(x=>x.id===empId);
  if(!e)return;

  // ซ่อนผลลัพธ์ค้นหา เพื่อไม่ให้เด้งกลับมาที่ช่องค้นหาเอง
  const box=document.getElementById('adminQuickSearchResults');
  if(box){box.style.display='none';box.innerHTML='';}

  // ให้หน้าอยู่ที่แท็บภาพรวมก่อน
  try{
    document.getElementById('adminSummaryPanel')?.classList.remove('hidden');
    document.getElementById('adminMaintPanel')?.classList.add('hidden');
    document.getElementById('adminCashPanel')?.classList.add('hidden');
    document.getElementById('adminLeavePanel')?.classList.add('hidden');
    document.getElementById('adminDocPanel')?.classList.add('hidden');
    document.getElementById('adminSettingsPanel')?.classList.add('hidden');
  }catch(_){}

  setTimeout(()=>{
    const panel=document.getElementById('adminSummaryPanel')||document.body;
    const searchWrap=document.getElementById('adminQuickSearch')?.closest('div');
    const name=(e.name||'').trim();
    const plate=(e.plate||'').trim();

    // หาเฉพาะการ์ดรายการจริง ไม่เอากล่องผลลัพธ์ค้นหาด้านบน
    const candidates=Array.from(panel.querySelectorAll('div')).filter(el=>{
      if(searchWrap && searchWrap.contains(el)) return false;
      if(el.closest('#adminQuickSearchResults')) return false;
      if(el.offsetParent===null) return false;
      const txt=(el.textContent||'').trim();
      if(!txt) return false;
      if(name && !txt.includes(name) && plate && !txt.includes(plate)) return false;
      if(name && !txt.includes(name) && !plate) return false;
      if(plate && !txt.includes(plate) && !name) return false;
      const r=el.getBoundingClientRect();
      return r.height>=24 && r.height<=260 && r.width>120;
    });

    // เลือกการ์ดที่เล็กที่สุดที่มีชื่อ/ทะเบียน จะตรงรายการจริงที่สุด
    let target=candidates.sort((a,b)=>{
      const ar=a.getBoundingClientRect(), br=b.getBoundingClientRect();
      return (ar.height*ar.width)-(br.height*br.width);
    })[0];

    // ถ้ายังหาไม่เจอ ให้เลื่อนไปหัวข้อสถานะของรถคันนั้น
    if(!target){
      const s=getS(e.status);
      target=Array.from(panel.querySelectorAll('div')).find(el=>{
        if(searchWrap && searchWrap.contains(el)) return false;
        return (el.textContent||'').includes(s.label);
      });
    }

    if(target){
      target.scrollIntoView({behavior:'smooth',block:'center'});
      const oldBox=target.style.boxShadow, oldTrans=target.style.transform, oldBg=target.style.backgroundColor;
      target.style.boxShadow='0 0 0 3px #F47920, 0 8px 24px rgba(244,121,32,.32)';
      target.style.transform='scale(1.015)';
      setTimeout(()=>{
        target.style.boxShadow=oldBox;
        target.style.transform=oldTrans;
        target.style.backgroundColor=oldBg;
      },2600);
    }
  },120);
}

function openAdminMoreMenu(){
  document.getElementById('adminMoreModal')?.classList.remove('hidden');
  document.getElementById('navAdminMore')?.classList.add('active');
  updateLeaveBadge();
}
function closeAdminMoreMenu(){
  document.getElementById('adminMoreModal')?.classList.add('hidden');
  const activeMain=['summary','maint','cash','doc'].some(t=>document.getElementById('navAdmin'+(t==='summary'?'Sum':t==='maint'?'Maint':t==='cash'?'Cash':'Doc'))?.classList.contains('active'));
  if(activeMain)document.getElementById('navAdminMore')?.classList.remove('active');
}

function switchAdminTab(t){
  if(adminRole==='viewer'&&t!=='summary'&&t!=='leave'&&t!=='leaveHistory'&&t!=='jobPlan')t='summary';
  // เก็บตำแหน่ง scroll ของแท็บเดิมไว้ก่อนสลับ เพื่อให้กลับมาที่เดิมได้เวลาสลับกลับมาแท็บนี้อีก
  const prevTab=window._currentAdminTab;
  const prevScrollEl=document.querySelector('#admin .list-area');
  if(prevTab&&prevScrollEl){
    window._adminTabScrollPos=window._adminTabScrollPos||{};
    window._adminTabScrollPos[prevTab]=prevScrollEl.scrollTop;
  }
  window._currentAdminTab=t; // ใช้เช็คก่อนเด้งแจ้งเตือน — เด้งเฉพาะตอนอยู่หน้า "ภาพรวม" เท่านั้น
  document.getElementById('adminEmpPanel').classList.add('hidden');
  document.getElementById('adminVehiclePanel')?.classList.add('hidden');
  document.getElementById('adminLeaveHistoryPanel')?.classList.add('hidden');
  document.getElementById('adminCashHistoryPanel')?.classList.add('hidden');
  document.getElementById('adminHistoryPanel')?.classList.toggle('hidden',t!=='history');
  document.getElementById('adminFluidHistoryPanel')?.classList.toggle('hidden',t!=='fluidHistory');
  if((t==='history'||t==='leaveHistory'||t==='fluidHistory'||t==='cashHistory')&&adminRole!=='viewer'){document.getElementById('adminTabBar')?.classList.add('hidden');}
  else{document.getElementById('adminTabBar')?.classList.remove('hidden');}
  document.getElementById('adminSummaryPanel').classList.toggle('hidden',t!=='summary');
  document.getElementById('adminMaintPanel').classList.toggle('hidden',t!=='maint');
  document.getElementById('adminCashPanel').classList.toggle('hidden',t!=='cash');
  document.getElementById('adminLeavePanel').classList.toggle('hidden',t!=='leave');
  document.getElementById('adminDocPanel')?.classList.toggle('hidden',t!=='doc');
  document.getElementById('adminJobPlanPanel')?.classList.toggle('hidden',t!=='jobPlan');
  document.getElementById('adminSettingsPanel').classList.toggle('hidden',t!=='settings');
  if(t==='leaveHistory')document.getElementById('adminLeaveHistoryPanel')?.classList.remove('hidden');
  if(t==='cashHistory')document.getElementById('adminCashHistoryPanel')?.classList.remove('hidden');
  document.getElementById('tabSummaryTop')?.classList.toggle('active',t==='summary');
  document.getElementById('tabMaintTop')?.classList.toggle('active',t==='maint');
  document.getElementById('tabCashTop')?.classList.toggle('active',t==='cash'||t==='cashHistory');
  document.getElementById('tabLeaveTop')?.classList.toggle('active',t==='leave');
  document.getElementById('tabSettings')?.classList.toggle('active',t==='settings'||t==='history'||t==='leaveHistory'||t==='fluidHistory');
  ['navAdminSum','navAdminJobPlan','navAdminMaint','navAdminCash','navAdminDoc','navAdminMore'].forEach(id=>{document.getElementById(id)?.classList.remove('active');});
  if(t==='summary')document.getElementById('navAdminSum')?.classList.add('active');
  if(t==='jobPlan')document.getElementById('navAdminJobPlan')?.classList.add('active');
  if(t==='maint')document.getElementById('navAdminMaint')?.classList.add('active');
  if(t==='cash'||t==='cashHistory')document.getElementById('navAdminCash')?.classList.add('active');
  if(t==='leave'||(t==='leaveHistory'&&adminRole==='viewer'))document.getElementById('navAdminMore')?.classList.add('active');
  if(t==='doc')document.getElementById('navAdminDoc')?.classList.add('active');
  if(t==='settings'||t==='history'||t==='fluidHistory'||(t==='leaveHistory'&&adminRole!=='viewer'))document.getElementById('navAdminMore')?.classList.add('active');
  if(t==='settings'){setTimeout(()=>{const si=document.getElementById('sysInfo');if(si&&si.innerHTML==='')renderSysInfo();},100);}
  if(t==='summary'){const el=document.getElementById('adminSummaryContent');if(el)el.innerHTML=buildSummaryHTML();}
  if(t==='maint'){renderAdminMaint();markSeenRepairs();}
  if(t==='cash'){renderAdminCashList();markSeenCash();}
  if(t==='cashHistory'){renderCashHistory();}
  if(t==='leave'){const el=document.getElementById('adminLeaveContent');if(el)el.innerHTML=buildLeaveHTML();markSeenLeave();}
  if(t==='doc'){renderAdminDocPanel();}
  if(t==='jobPlan'){const sel=document.getElementById('jpNewDateSel');if(sel)sel.innerHTML=jobPlanDateOptionsHTML('');const fsel=document.getElementById('jpCopyFromSel');if(fsel)fsel.innerHTML=jpExistingDateOptionsHTML('');renderJobRouteTemplates();renderJobPlan();}
  if(t==='history')renderAdminHistory();
  if(t==='fluidHistory')renderAdminFluidHistory();
  if(t==='leaveHistory')renderLeaveHistory();
  const scrollEl=document.querySelector('#admin .list-area');
  const savedPos=(window._adminTabScrollPos&&window._adminTabScrollPos[t])||0;
  if(scrollEl)scrollEl.scrollTo({top:savedPos,behavior:'auto'});
  else window.scrollTo({top:savedPos,behavior:'auto'});
}

// ── ประวัติการลา — แยกเดือน เก็บสูงสุด 1 ปีปฏิทิน ──────────────────────────
function renderLeaveHistory(){
  const el=document.getElementById('leaveHistoryContent');
  if(!el)return;

  // ลบประวัติที่เกินปีก่อนหน้า
  const curYear=new Date().getFullYear();
  const before=leaveLogs.length;
  leaveLogs=leaveLogs.filter(l=>l.year>=curYear-1);
  if(leaveLogs.length<before)saveLeaveLogs();

  if(!leaveLogs.length){
    el.innerHTML='<div class="empty-state"><div class="empty-icon">🌴</div><div class="empty-text">ยังไม่มีประวัติการลา<br><span style="font-size:11px;color:#aaa;">เมื่ออนุมัติการลาจะถูกเก็บไว้ที่นี่</span></div></div>';
    return;
  }

  const MONTH_TH=['','ม.ค.','ก.พ.','มี.ค.','เม.ย.','พ.ค.','มิ.ย.','ก.ค.','ส.ค.','ก.ย.','ต.ค.','พ.ย.','ธ.ค.'];
  // เฉพาะผู้ดูแล (super) เท่านั้นที่ลบประวัติการลาได้ — แอดมิน (viewer) ดูได้อย่างเดียว
  const canDel=adminRole!=='viewer';

  // ── สรุปรายคน (เพื่อประเมินงาน) ──
  const byEmp={};
  leaveLogs.forEach(l=>{
    if(!byEmp[l.empId])byEmp[l.empId]={name:l.empName,plate:l.plate,totalDays:0,count:0,months:{}};
    byEmp[l.empId].totalDays+=(l.days||1);
    byEmp[l.empId].count++;
    const mk=`${l.year}-${String(l.month).padStart(2,'0')}`;
    byEmp[l.empId].months[mk]=(byEmp[l.empId].months[mk]||0)+(l.days||1);
  });
  const empArr=Object.values(byEmp).sort((a,b)=>b.totalDays-a.totalDays);

  // ── แบ่งตามเดือน ──
  const byMonth={};
  leaveLogs.forEach(l=>{
    const mk=`${l.year}-${String(l.month).padStart(2,'0')}`;
    (byMonth[mk]=byMonth[mk]||[]).push(l);
  });
  const monthKeys=Object.keys(byMonth).sort().reverse();

  let html=`
  <!-- สรุปรายคน -->
  <div class="card" style="margin-bottom:14px;">
    <div style="font-size:14px;font-weight:800;color:#6C3FE8;margin-bottom:10px;">📊 สรุปรายบุคคล (ประเมินงาน)</div>
    ${empArr.map(e=>{
      const bar=Math.min(100,Math.round(e.totalDays/30*100));
      const color=e.totalDays>=10?'#EF4444':e.totalDays>=5?'#F59E0B':'#10B981';
      return`<div style="margin-bottom:10px;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:3px;">
          <div>
            <span style="font-size:13px;font-weight:700;color:#1a1a2e;">${esc(e.name)}</span>
            <span style="font-size:10.5px;color:#888;margin-left:6px;">🚛 ${esc(e.plate||'-')}</span>
          </div>
          <span style="font-size:12px;font-weight:800;color:${color};">${e.totalDays} วัน (${e.count} ครั้ง)</span>
        </div>
        <div style="background:#F1F5F9;border-radius:6px;height:8px;overflow:hidden;">
          <div style="width:${bar}%;height:100%;background:${color};border-radius:6px;transition:.3s;"></div>
        </div>
      </div>`;
    }).join('')}
  </div>

  <!-- ประวัติแยกเดือน -->
  ${monthKeys.map(mk=>{
    const [yr,mo]=mk.split('-');
    const items=byMonth[mk];
    const totalDays=items.reduce((s,l)=>s+(l.days||1),0);
    return`<div style="margin-bottom:12px;">
      <div style="display:flex;align-items:center;gap:8px;padding:8px 12px;background:#F5F3FF;border:1.5px solid #C4B5FD;border-radius:12px;margin-bottom:8px;">
        <span style="font-size:13px;font-weight:800;color:#6C3FE8;">📅 ${MONTH_TH[parseInt(mo)]} ${parseInt(yr)+543}</span>
        <span style="font-size:10px;background:#C4B5FD;color:#1a1a2e;border-radius:10px;padding:1px 7px;font-weight:700;">${items.length} ครั้ง · ${totalDays} วัน</span>
      </div>
      ${items.map(l=>`<div class="card" style="margin-bottom:6px;padding:10px 12px;">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;">
          <div style="flex:1;min-width:0;">
            <div style="font-size:13px;font-weight:700;color:#1a1a2e;">${esc(l.empName)}</div>
            <div style="font-size:11px;color:#888;">🚛 ${esc(l.plate||'-')}</div>
            <div style="font-size:12px;color:#475569;margin-top:3px;">📅 ${l.leaveFrom||'-'}${l.leaveTo&&l.leaveTo!==l.leaveFrom?' → '+l.leaveTo:''}</div>
            ${l.leaveNote?`<div style="font-size:12px;color:#666;margin-top:2px;">📋 ${esc(l.leaveNote)}</div>`:''}
            ${l.leaveReply?`<div style="font-size:11.5px;color:#1E90D6;margin-top:4px;background:#EFF6FF;border-radius:8px;padding:5px 8px;">💬 ${esc(l.leaveReply)}</div>`:''}
          </div>
          <div style="text-align:right;flex-shrink:0;">
            <div style="font-size:14px;font-weight:900;color:#6C3FE8;">${l.days||1}<span style="font-size:10px;font-weight:400;color:#888;"> วัน</span></div>
            <div style="font-size:9.5px;color:#aaa;margin-top:2px;">✅ ${l.approvedAt?new Date(l.approvedAt).toLocaleDateString('th-TH',{day:'numeric',month:'short'}):'-'}</div>
            ${canDel?`<button class="btn btn-red btn-sm" style="margin-top:8px;padding:5px 10px;font-size:10.5px;white-space:nowrap;" onclick="deleteLeaveLog('${esc(l.id)}')">🗑️ ลบ</button>`:''}
          </div>
        </div>
      </div>`).join('')}
    </div>`;
  }).join('')}`;

  el.innerHTML=html;
}

// ── ลบประวัติการลา 1 รายการ (เฉพาะผู้ดูแล/super เท่านั้น) ──────────────────────
function deleteLeaveLog(id){
  // กันสิทธิ์: แอดมิน (viewer) ห้ามลบ
  if(adminRole==='viewer'){alert('เฉพาะผู้ดูแลเท่านั้นที่ลบประวัติการลาได้');return;}
  const log=(leaveLogs||[]).find(l=>l.id===id);
  if(!log)return;
  const range=log.leaveFrom+(log.leaveTo&&log.leaveTo!==log.leaveFrom?' → '+log.leaveTo:'');
  if(!confirm('ลบประวัติการลานี้?\n\n'+(log.empName||'')+'\n📅 '+range))return;
  leaveLogs=leaveLogs.filter(l=>l.id!==id);
  saveLeaveLogs();
  renderLeaveHistory();
}

// ─────────────────────────────────────────────────────────────────────────────
// ── Accordion ตั้งค่า ─────────────────────────────────────────────────────────
function toggleAcc(key){
  const item=document.getElementById('acc_'+key);if(!item)return;
  const body=item.querySelector('.acc-body');if(!body)return;
  const isOpen=!body.classList.contains('hidden');
  // ปิดตัวอื่นๆ เฉพาะภายในกล่องเดียวกัน (parentElement) ไม่ล็อกตายตัวไว้แค่หน้าใดหน้าหนึ่ง กันบั๊กแบบเดิมที่ใช้ได้แค่บางหน้า
  const scope=item.parentElement||document;
  scope.querySelectorAll('.acc-item').forEach(el=>{
    el.querySelector('.acc-body')?.classList.add('hidden');
    el.classList.remove('acc-open');
  });
  if(!isOpen){body.classList.remove('hidden');item.classList.add('acc-open');}
}

function showEmpManage(){
  document.getElementById('adminTabBar')?.classList.add('hidden');
  document.getElementById('adminSummaryPanel').classList.add('hidden');
  document.getElementById('adminSettingsPanel').classList.add('hidden');
  document.getElementById('adminEmpPanel').classList.remove('hidden');
  renderAdminEmpList();
}
function hideEmpManage(){
  document.getElementById('adminEmpPanel').classList.add('hidden');
  document.getElementById('adminTabBar')?.classList.remove('hidden');
  switchAdminTab('settings');
}

// ══════════════════════════════════════════════════════════════════════════
// ── จัดการรถ (Vehicle management) ──
// รถเป็นเอนทิตี้แยกจากพนักงานเด็ดขาด: เพิ่ม/ลบ/แก้ไขทะเบียนรถได้เองที่นี่ ไม่ต้องผูกกับคนขับ
// "รถทั้งหมด" ในหน้าสรุปนับจากรายการนี้ตรงๆ (vehicles.length) ไม่ต้องเดาจากทะเบียนที่พนักงานกรอกไว้อีกต่อไป
// ══════════════════════════════════════════════════════════════════════════
function showVehicleManage(){
  document.getElementById('adminTabBar')?.classList.add('hidden');
  document.getElementById('adminSummaryPanel').classList.add('hidden');
  document.getElementById('adminSettingsPanel').classList.add('hidden');
  document.getElementById('adminVehiclePanel').classList.remove('hidden');
  renderAdminVehicleList();
}
function hideVehicleManage(){
  document.getElementById('adminVehiclePanel').classList.add('hidden');
  document.getElementById('adminTabBar')?.classList.remove('hidden');
  switchAdminTab('settings');
}
function toggleAddVehicle(){document.getElementById('addVehicleForm').classList.toggle('hidden');}
function doAddVehicle(){
  const plate=document.getElementById('addVehiclePlate').value.trim().toUpperCase();
  const type=document.getElementById('addVehicleType').value.trim();
  const m=document.getElementById('addVehicleMsg');
  if(!plate){if(m){m.textContent='⚠️ กรุณากรอกทะเบียนรถ';m.classList.remove('hidden');}return;}
  if(vehicles.some(v=>(v.plate||'').trim().toUpperCase()===plate)){
    if(m){m.textContent='⚠️ มีทะเบียนนี้อยู่แล้วในระบบ';m.classList.remove('hidden');}
    return;
  }
  const now=new Date().toISOString();
  vehicles.push({id:'veh_'+Date.now(),plate,type,note:'',active:true,createdAt:now,updatedAt:now});
  saveV();
  ['addVehiclePlate','addVehicleType'].forEach(x=>{const el=document.getElementById(x);if(el)el.value='';});
  if(m)m.classList.add('hidden');
  document.getElementById('addVehicleForm').classList.add('hidden');
  renderAdminVehicleList();
}
function openVEdit(id){
  document.querySelectorAll('[id^="vef_"]').forEach(el=>el.classList.add('hidden'));
  document.getElementById('vef_'+id)?.classList.remove('hidden');
}
function closeVEdit(id){document.getElementById('vef_'+id)?.classList.add('hidden');}
function doSaveVEdit(id){
  const plate=document.getElementById('vep_'+id).value.trim().toUpperCase();
  const type=document.getElementById('vet_'+id).value.trim();
  const note=document.getElementById('ven_'+id).value;
  if(!plate)return;
  if(vehicles.some(v=>v.id!==id&&(v.plate||'').trim().toUpperCase()===plate)){
    alert('⚠️ มีทะเบียนนี้อยู่แล้วในระบบ');return;
  }
  const now=new Date().toISOString();
  const oldPlate=(vehicles.find(v=>v.id===id)||{}).plate||'';
  vehicles=vehicles.map(v=>v.id===id?{...v,plate,type,note,updatedAt:now}:v);
  saveV();
  // ทะเบียนเปลี่ยน → อัปเดตทะเบียนของคนขับปัจจุบันที่ผูกกับคันนี้ให้ตรงกันด้วย (กันข้อมูลเพี้ยน)
  if(oldPlate&&oldPlate!==plate){
    const affected=employees.filter(e=>(e.plate||'').trim()===oldPlate.trim());
    if(affected.length){
      employees=employees.map(e=>affected.some(a=>a.id===e.id)?{...e,plate}:e);
      saveE();
    }
  }
  renderAdminVehicleList();
}
function toggleVehicleActive(id){
  const v=vehicles.find(x=>x.id===id);if(!v)return;
  vehicles=vehicles.map(x=>x.id===id?{...x,active:x.active===false,updatedAt:new Date().toISOString()}:x);
  saveV();
  renderAdminVehicleList();
}
function doDelVehicle(id){
  const v=vehicles.find(x=>x.id===id);if(!v)return;
  const drivers=employees.filter(e=>(e.plate||'').trim()===(v.plate||'').trim()&&e.status!=='inactive');
  const warnMsg=drivers.length?`\n\n⚠️ ตอนนี้มีคนขับผูกกับทะเบียนนี้อยู่ ${drivers.length} คน (${drivers.map(d=>d.name).join(', ')}) — ลบแล้วพวกเขาจะไม่ถูกลบ แต่ทะเบียนจะไม่อยู่ในระบบรถอีกต่อไป`:'';
  if(!confirm(`ลบรถทะเบียน "${v.plate}" ออกจากระบบ?${warnMsg}`))return;
  vehicles=vehicles.filter(x=>x.id!==id);
  saveV();
  renderAdminVehicleList();
}
function renderAdminVehicleList(){
  const el=document.getElementById('adminVehicleList');
  if(!el)return;
  const q=(window.adminVehicleSearchQuery||'').toLowerCase().trim();
  const filtered=vehicles.filter(v=>!q||(v.plate||'').toLowerCase().includes(q)||(v.type||'').toLowerCase().includes(q));
  if(!vehicles.length){el.innerHTML='<div class="empty-state"><div class="empty-icon">🚛</div><div class="empty-text">ยังไม่มีรถในระบบ — กด "+ เพิ่มรถ" เพื่อเริ่มต้น</div></div>';return;}
  if(!filtered.length){el.innerHTML='<div class="empty-state"><div class="empty-icon">🔍</div><div class="empty-text">ไม่พบข้อมูลที่ค้นหา</div></div>';return;}
  const sorted=filtered.slice().sort((a,b)=>(a.plate||'').localeCompare(b.plate||''));
  el.innerHTML=sorted.map(v=>{
    const drivers=employees.filter(e=>(e.plate||'').trim()===(v.plate||'').trim()&&e.status!=='inactive');
    const isActive=v.active!==false;
    return `<div class="emp-card" style="margin-bottom:12px;opacity:${isActive?'1':'.6'};">
      <div class="emp-card-row">
        <div style="width:42px;height:42px;border-radius:12px;background:${isActive?'#EEF2FF':'#F1F5F9'};display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0;">🚛</div>
        <div style="flex:1;min-width:0;">
          <div style="color:#1a1a2e;font-weight:800;">${esc(v.plate)}</div>
          <div style="color:#888;font-size:11px;">${v.type?esc(v.type):'ไม่ระบุประเภทรถ'}</div>
          <div style="color:${drivers.length?'#065F46':'#94A3B8'};font-size:11px;margin-top:2px;">${drivers.length?'👤 คนขับ: '+esc(drivers.map(d=>d.name).join(', ')):'⚪ ยังไม่มีคนขับ'}</div>
          ${v.note?`<div style="color:#92400E;font-size:11px;margin-top:4px;background:#FFFBEB;border:1px solid #FDE68A;border-radius:6px;padding:4px 8px;">${skeIcon('note')} ${esc(v.note)}</div>`:''}
        </div>
        <div class="pill" style="background:${isActive?'#ECFDF5':'#F1F5F9'};color:${isActive?'#065F46':'#64748B'};border:1px solid ${isActive?'#6EE7B7':'#CBD5E1'};font-size:10px;flex-shrink:0;">${isActive?'✅ ใช้งาน':'⛔ ปิดใช้งาน'}</div>
      </div>
      <div class="row-btns" style="margin-top:10px;">
        <button class="btn btn-blue btn-sm" style="flex:1;" onclick="openVEdit('${v.id}')">✏️ แก้ไข</button>
        <button class="btn btn-gray btn-sm" style="flex:1;" onclick="toggleVehicleActive('${v.id}')">${isActive?'⛔ ปิดใช้งาน':'✅ เปิดใช้งาน'}</button>
        <button class="btn btn-red btn-sm" style="flex:1;" onclick="doDelVehicle('${v.id}')">🗑️ ลบ</button>
      </div>
      <div id="vef_${v.id}" class="hidden" style="margin-top:12px;border-top:1px solid #E8EAF0;padding-top:12px;display:flex;flex-direction:column;gap:11px;">
        <div style="color:#1E90D6;font-weight:700;">✏️ แก้ไขรถ: ${esc(v.plate)}</div>
        <div><div class="inp-label">ทะเบียนรถ</div><input class="inp" id="vep_${v.id}" value="${esc(v.plate)}" style="text-transform:uppercase;"></div>
        <div><div class="inp-label">ประเภทรถ</div><input class="inp" id="vet_${v.id}" value="${esc(v.type||'')}" placeholder="เช่น 6W7.2, 10W"></div>
        <div><div class="inp-label">หมายเหตุ</div><textarea class="inp" id="ven_${v.id}" rows="2">${esc(v.note||'')}</textarea></div>
        <div class="row-btns">
          <button class="btn btn-gray" style="flex:1;" onclick="closeVEdit('${v.id}')">ยกเลิก</button>
          <button class="btn btn-blue" style="flex:1;" onclick="doSaveVEdit('${v.id}');closeVEdit('${v.id}');">✓ บันทึก</button>
        </div>
      </div>
    </div>`;
  }).join('');
}

function toggleAddEmp(){document.getElementById('addEmpForm').classList.toggle('hidden');const sel=document.getElementById('addPlate');if(sel)sel.innerHTML=vehiclePlateOptionsHTML('');const posel=document.getElementById('addPosition');if(posel)posel.innerHTML=positionOptionsHTML('');}

// สร้างตัวเลือกทะเบียนรถจากรายการ "รถ" จริง (vehicles) — กันคนขับผูกกับทะเบียนที่ไม่มีอยู่จริง/พิมพ์ผิด
function vehiclePlateOptionsHTML(selected){
  const opts=['<option value="">-- เลือกทะเบียนรถ --</option>'];
  vehicles.slice().sort((a,b)=>(a.plate||'').localeCompare(b.plate||'')).forEach(v=>{
    const tag=v.active===false?' (ปิดใช้งาน)':'';
    opts.push(`<option value="${esc(v.plate)}" ${v.plate===selected?'selected':''}>${esc(v.plate)}${tag}</option>`);
  });
  return opts.join('');
}

// รายการตำแหน่งที่ใช้ทั่วทั้งระบบ
const POSITION_OPTIONS=['พนักงานขับรถ','รถร่วม','ผู้ช่วยคนขับ','แอดมิน','ช่างซ่อมบำรุง','ฝ่ายบุคคล'];
// ตำแหน่งที่มีสิทธิ์ "แจ้ง/ติดตามสถานะรถ" — เฉพาะพนักงานขับรถและรถร่วมเท่านั้น (ตำแหน่งอื่นไม่เกี่ยวกับการขับรถ ไม่ควรมีสิทธิ์นี้)
const DRIVING_POSITIONS=['พนักงานขับรถ'];
function positionOptionsHTML(cur){
  return '<option value="">-- เลือกตำแหน่ง --</option>'+POSITION_OPTIONS.map(p=>`<option value="${esc(p)}" ${cur===p?'selected':''}>${esc(p)}</option>`).join('');
}
// ตำแหน่งนี้มีสิทธิ์แจ้งสถานะรถไหม — ยังไม่เคยตั้งตำแหน่ง (ข้อมูลเก่าก่อนมีระบบนี้) ให้ถือว่าใช่ กันคนขับเดิมหลุดสิทธิ์กะทันหันตอนอัพเดทระบบ
function isDrivingPosition(position){
  if(!position)return true;
  return DRIVING_POSITIONS.includes(position);
}
// พนักงานคนนี้ต้อง "ผูกกับสถานะรถ/จังหวัดสแตนบาย" ไหม — ต้องมีทั้งทะเบียนรถ และตำแหน่งเป็นพนักงานขับรถ/รถร่วม (หรือยังไม่ตั้งตำแหน่ง)
function needsVehicleTracking(e){
  if(!e)return true;
  if(!e.plate)return false;
  return isDrivingPosition(e.position);
}

// ══ แผนงาน (จ่ายงาน) ══════════════════════════════════════════════════════
function openJobPlan(){switchAdminTab('jobPlan');}
function closeJobPlan(){switchAdminTab('summary');}

function todayStrJP(){const d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');}
// เช็คว่าวันที่นี้ผ่านไปแล้วหรือยัง (ก่อนวันนี้) — ใช้กันไม่ให้ส่งแจ้งเตือนไปหาพนักงานสำหรับแผนงานที่กลายเป็นแค่ข้อมูลย้อนหลังไปแล้ว
function isPastWorkDate(workDate){
  if(!workDate)return false;
  return workDate<todayStrJP();
}

const THAI_DOW_JP=['อา.','จ.','อ.','พ.','พฤ.','ศ.','ส.'];
function fmtJobDateFull(dateStr){
  if(!dateStr)return'ไม่ระบุวันที่';
  const d=new Date(dateStr+'T00:00:00');
  if(isNaN(d.getTime()))return dateStr;
  return THAI_DOW_JP[d.getDay()]+' '+String(d.getDate()).padStart(2,'0')+'/'+String(d.getMonth()+1).padStart(2,'0')+'/'+d.getFullYear();
}
function jobPlanDateOptionsHTML(cur){
  const opts=['<option value="">-- เลือกวันที่ --</option>'];
  const now=new Date();
  for(let i=0;i<30;i++){
    const d=new Date(now.getFullYear(),now.getMonth(),now.getDate()+i);
    const val=d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
    let label=THAI_DOW_JP[d.getDay()]+' '+d.toLocaleDateString('th-TH',{day:'numeric',month:'short',year:'numeric'});
    if(i===0)label+=' (วันนี้)';else if(i===1)label+=' (พรุ่งนี้)';
    opts.push(`<option value="${val}" ${cur===val?'selected':''}>${label}</option>`);
  }
  return opts.join('');
}
function jobPlanTimeOptionsHTML(cur){
  const opts=['<option value="">-- เวลา --</option>'];
  for(let h=0;h<24;h++){
    for(let m=0;m<60;m+=30){
      const val=String(h).padStart(2,'0')+':'+String(m).padStart(2,'0');
      opts.push(`<option value="${val}" ${cur===val?'selected':''}>${val} น.</option>`);
    }
  }
  return opts.join('');
}
function jobPlanEmpOptionsHTML(cur){
  // ดึงพนักงานทุกคนจากหน้าจัดการพนักงานมาให้เลือกได้หมด (รวมรถร่วม/ตำแหน่งอื่นๆ) — "สิทธิ์แจ้งสถานะ" กับ
  // "ถูกมอบหมายงานในแผนงานได้" เป็นคนละเรื่องกัน ไม่ควรใช้เงื่อนไขเดียวกัน (needsVehicleTracking ใช้เช็คสิทธิ์แจ้งสถานะเท่านั้น)
  const list=employees.slice().sort((a,b)=>String(a.name).localeCompare(String(b.name),'th'));
  const opts=['<option value="">-- เลือกพนักงาน --</option>'];
  list.forEach(e=>{opts.push(`<option value="${e.id}" ${cur===e.id?'selected':''}>${esc(e.name)}${e.position?' ('+esc(e.position)+')':''}</option>`);});
  return opts.join('');
}
function fmtJobDate(dateStr){
  if(!dateStr)return'';
  const d=new Date(dateStr+'T00:00:00');
  if(isNaN(d.getTime()))return dateStr;
  return d.toLocaleDateString('th-TH',{day:'numeric',month:'short',year:'numeric'});
}
function buildJobNoteText(row){
  const parts=[];
  if(row.route)parts.push(row.route);
  if(row.workDate)parts.push('วันที่ '+fmtJobDate(row.workDate));
  if(row.standbyTime)parts.push('เวลา '+row.standbyTime+' น.');
  if(row.remark)parts.push('หมายเหตุ: '+row.remark);
  return parts.join(' · ')||'ได้รับมอบหมายงาน';
}

// บันทึกแผนงาน — ถ้าระบุ changedRowIds (string เดี่ยวหรือ array หลายแถว) จะดึงข้อมูลสดจากเซิร์ฟเวอร์มาก่อน แล้วอัปเดตเฉพาะแถวที่ระบุลงไป
// (กันปัญหาแอดมินหลายคนแก้แผนงานพร้อมกันคนละเครื่อง แล้วเขียนทับข้อมูลกันเอง ทำให้ชื่อที่เพิ่งเลือกไว้หายไป)
// ถ้าไม่ระบุเลย จะบันทึกทับทั้งชุดแบบเดิม (ใช้กับกรณีสร้างข้อมูลชุดใหญ่ตอนตั้งค่าเริ่มต้น ซึ่งเสี่ยงชนกันน้อยกว่า)
async function saveJobPlan(changedRowIds){
  _cacheSet('ske_jobplan',jobPlanRows);
  if(!window.fbSaveJobPlan)return;
  const ids=changedRowIds?(Array.isArray(changedRowIds)?changedRowIds:[changedRowIds]):null;
  if(ids&&ids.length&&window.fbGetJobPlanFresh){
    try{
      const fresh=await window.fbGetJobPlanFresh();
      if(fresh){
        let merged=fresh.slice();
        ids.forEach(rid=>{
          const changedRow=jobPlanRows.find(r=>r.id===rid);
          if(!changedRow){
            merged=merged.filter(r=>r.id!==rid);
          }else{
            const exists=merged.some(r=>r.id===rid);
            merged=exists?merged.map(r=>r.id===rid?changedRow:r):merged.concat([changedRow]);
          }
        });
        jobPlanRows=merged;
        _cacheSet('ske_jobplan',jobPlanRows);
        await window.fbSaveJobPlan(merged).catch(()=>{});
        renderJobPlan();
        return;
      }
    }catch(e){/* ดึงข้อมูลสดไม่สำเร็จ (เช่นเน็ตหลุด) — บันทึกด้วยข้อมูลเครื่องตัวเองไปก่อน ดีกว่าไม่บันทึกอะไรเลย */}
  }
  return window.fbSaveJobPlan(jobPlanRows).catch(()=>{});
}

function renderJobPlanRowTR(row){
  const hasRemark=!!(row.remark&&row.remark.trim());
  const unassigned=!row.empId;
  const bg=hasRemark?'#FEE2E2':(unassigned?'#FDF2F8':'#fff');
  return `<tr style="background:${bg};border-bottom:1px solid #F1F5F9;">
    <td style="padding:6px;min-width:150px;">
      <input value="${esc(row.route||'')}" placeholder="พิมพ์เส้นทาง..." onblur="updateJobPlanField('${row.id}','route',this.value)" style="width:100%;border:none;background:transparent;font-size:11.5px;font-weight:${hasRemark?'700':'500'};color:${hasRemark?'#B91C1C':'#1a1a2e'};">
    </td>
    <td style="padding:6px;min-width:88px;">
      <select onchange="updateJobPlanField('${row.id}','standbyTime',this.value)" style="width:100%;border:none;background:transparent;font-size:11.5px;">${jobPlanTimeOptionsHTML(row.standbyTime)}</select>
    </td>
    <td style="padding:6px;min-width:150px;">
      <select onchange="onJobPlanEmpChange('${row.id}',this.value)" style="width:100%;border:none;background:transparent;font-size:11.5px;font-weight:700;color:${unassigned?'#DB2777':'#1a1a2e'};">${jobPlanEmpOptionsHTML(row.empId)}</select>
    </td>
    <td style="padding:6px;min-width:85px;color:#475569;font-size:11.5px;white-space:nowrap;">${esc(row.plate||'-')}</td>
    <td style="padding:6px;min-width:100px;color:#475569;font-size:11.5px;white-space:nowrap;">${esc(row.phone||'-')}</td>
    <td style="padding:6px;min-width:140px;">
      <input value="${esc(row.remark||'')}" placeholder="หมายเหตุ..." onblur="updateJobPlanField('${row.id}','remark',this.value)" style="width:100%;border:none;background:transparent;font-size:11.5px;color:#B91C1C;">
    </td>
    <td style="padding:6px;text-align:center;min-width:76px;white-space:nowrap;position:sticky;right:0;background:${bg};box-shadow:-4px 0 6px -4px rgba(0,0,0,.15);">
      <button onclick="copyRouteToDate('${row.id}')" title="คัดลอกเส้นทางนี้ไปวันอื่น" style="background:none;border:none;color:#1E90D6;font-size:14px;cursor:pointer;">📋</button>
      ${row.dispatched?'<span title="จ่ายงานแล้ว">✅</span>':`
        ${row.empId?`<button onclick="dispatchJobPlanRow('${row.id}')" title="จ่ายงานเส้นทางนี้เลย" style="background:none;border:none;color:#059669;font-size:14px;cursor:pointer;">🚀</button>`:''}
        <button onclick="delJobPlanRow('${row.id}')" title="ลบเส้นทางนี้" style="background:none;border:none;color:#DC2626;font-size:14px;cursor:pointer;">🗑️</button>`}
    </td>
  </tr>`;
}

function renderJobPlanDateGroup(date,rows){
  return `<div style="margin-bottom:18px;">
    <div style="background:linear-gradient(90deg,#F97316,#FB923C);color:#fff;font-weight:800;font-size:13px;padding:9px 14px;border-radius:10px 10px 0 0;">
      📅 แผนงานวันที่ ${fmtJobDateFull(date)}
    </div>
    <div style="overflow-x:auto;border:1px solid #E8EAF0;border-top:none;border-radius:0 0 10px 10px;background:#fff;">
      <table style="width:100%;border-collapse:collapse;">
        <thead><tr style="background:#EFF6FF;">
          <th style="padding:8px 6px;text-align:left;color:#1E40AF;font-weight:700;font-size:11px;border-bottom:2px solid #BFDBFE;">เส้นทาง</th>
          <th style="padding:8px 6px;text-align:left;color:#1E40AF;font-weight:700;font-size:11px;border-bottom:2px solid #BFDBFE;">เวลาสแตนบาย</th>
          <th style="padding:8px 6px;text-align:left;color:#1E40AF;font-weight:700;font-size:11px;border-bottom:2px solid #BFDBFE;">ชื่อ-สกุล</th>
          <th style="padding:8px 6px;text-align:left;color:#1E40AF;font-weight:700;font-size:11px;border-bottom:2px solid #BFDBFE;">ทะเบียน</th>
          <th style="padding:8px 6px;text-align:left;color:#1E40AF;font-weight:700;font-size:11px;border-bottom:2px solid #BFDBFE;">เบอร์โทร</th>
          <th style="padding:8px 6px;text-align:left;color:#1E40AF;font-weight:700;font-size:11px;border-bottom:2px solid #BFDBFE;">หมายเหตุ</th>
          <th style="padding:8px 6px;border-bottom:2px solid #BFDBFE;position:sticky;right:0;background:#EFF6FF;box-shadow:-4px 0 6px -4px rgba(0,0,0,.15);"></th>
        </tr></thead>
        <tbody>${rows.map(r=>renderJobPlanRowTR(r)).join('')}</tbody>
      </table>
    </div>
    <div style="display:flex;gap:8px;margin-top:6px;">
      <button class="btn btn-gray btn-sm" style="font-size:11.5px;flex:1;" onclick="addJobPlanRow('${date}')">+ เพิ่มเส้นทาง</button>
      <button class="btn btn-purple btn-sm" style="font-size:11.5px;flex:1;" onclick="syncJobPlanDateFromTemplates('${date}')" title="เพิ่มเส้นทางที่ขาดหายไปจากเทมเพลตล่าสุด (ไม่ลบ/ไม่แตะของเดิม)">🔄 ซิงก์ตามเทมเพลต</button>
      <button class="btn btn-blue btn-sm" style="font-size:11.5px;flex:1;" onclick="dispatchJobPlan('${date}')">🚀 จ่ายงาน</button>
    </div>
  </div>`;
}

const THAI_MONTHS_FULL_JP=['มกราคม','กุมภาพันธ์','มีนาคม','เมษายน','พฤษภาคม','มิถุนายน','กรกฎาคม','สิงหาคม','กันยายน','ตุลาคม','พฤศจิกายน','ธันวาคม'];
function fmtJobMonthLabel(mk){
  if(mk==='other')return'ไม่ระบุวันที่';
  const [y,m]=mk.split('-').map(Number);
  return THAI_MONTHS_FULL_JP[m-1]+' '+(y+543);
}
function toggleJobPlanMonth(mk){toggleAcc('jpmonth_'+mk);}
function renderJobPlan(){
  const el=document.getElementById('jobPlanList');
  if(!el)return;
  const fsel=document.getElementById('jpCopyFromSel');
  if(fsel)fsel.innerHTML=jpExistingDateOptionsHTML(fsel.value);
  if(!jobPlanRows.length){
    el.innerHTML='<div class="empty-state"><div class="empty-icon">📋</div><div class="empty-text">ยังไม่มีแผนงาน เลือกวันที่ด้านบนแล้วกด "+ เพิ่ม" เพื่อเริ่มต้น</div></div>';
    return;
  }
  const byDate={};
  jobPlanRows.forEach(r=>{const k=r.workDate||'ไม่ระบุวันที่';if(!byDate[k])byDate[k]=[];byDate[k].push(r);});
  const dates=Object.keys(byDate).sort();
  // จัดกลุ่มวันที่ตามเดือน — เดือนที่ผ่านไปแล้ว (ก่อนเดือนปัจจุบัน) พับเก็บอัตโนมัติ กันหน้ารก แต่ยังกดดูย้อนหลังได้เสมอ
  // เดือนปัจจุบันและอนาคตแสดงปกติ ไม่พับ (ใช้งานอยู่บ่อย)
  const byMonth={};
  dates.forEach(d=>{
    const mk=/^\d{4}-\d{2}/.test(d)?d.slice(0,7):'other';
    if(!byMonth[mk])byMonth[mk]=[];
    byMonth[mk].push(d);
  });
  const monthKeys=Object.keys(byMonth).sort();
  const now=new Date();
  const curMonthKey=now.getFullYear()+'-'+String(now.getMonth()+1).padStart(2,'0');
  el.innerHTML=monthKeys.map(mk=>{
    const bodyHtml=byMonth[mk].map(d=>renderJobPlanDateGroup(d,byDate[d])).join('');
    const isPast=mk!=='other'&&mk<curMonthKey;
    if(!isPast)return bodyHtml;
    return `<div class="acc-item" id="acc_jpmonth_${mk}" style="margin-bottom:16px;border:1px solid #E8EAF0;border-radius:12px;overflow:hidden;">
      <button class="acc-head" onclick="toggleJobPlanMonth('${mk}')" style="background:#F1F5F9;width:100%;">
        <span>🗓️ ${fmtJobMonthLabel(mk)} (${byMonth[mk].length} วัน) — เดือนที่ผ่านมาแล้ว</span><span class="acc-arrow">›</span>
      </button>
      <div class="acc-body hidden" style="padding:12px;">${bodyHtml}</div>
    </div>`;
  }).join('');
}

// เติมเส้นทางที่ "ขาดหายไป" ให้ตรงกับเทมเพลตล่าสุด — ใช้เมื่อแก้ไข/เพิ่มเทมเพลตทีหลัง จากที่วันนั้นถูกสร้างไปแล้ว
// (การสร้างวันแบบอัตโนมัติเป็นการสแนปช็อตครั้งเดียวตอนกดสร้าง ไม่ได้อัปเดตย้อนหลังให้เองถ้าไปแก้เทมเพลตทีหลัง)
// เทียบด้วย "ชื่อเส้นทาง+เวลา" คู่กัน — ถ้าคู่ไหนยังไม่มีในวันนั้น จะเพิ่มแถวใหม่ให้ ไม่แตะ/ไม่ลบแถวเดิมที่มีอยู่แล้วเด็ดขาด (กันมอบหมายงานที่ทำไปแล้วหาย)
// ซิงก์แถวในวันนั้นให้ตรงกับเส้นทางหลักล่าสุด — ทำ 2 อย่าง: (1) เพิ่มเส้นทางที่ขาดหายไป (2) อัปเดตชื่อ/เวลาของแถวเดิม
// ถ้าเทมเพลตต้นทางถูกแก้ไข (เช่น เปลี่ยนชื่อ) — อัปเดตเฉพาะแถวที่ "ยังไม่ได้จ่ายงาน" เท่านั้น กันไปแก้ข้อมูลที่แจ้งพนักงานไปแล้วโดยไม่รู้ตัว
function syncJobPlanDateFromTemplates(date){
  if(!confirm('ซิงก์เส้นทางของวันนี้ตามเส้นทางหลักประจำสัปดาห์?')) return;
  const dnum=weekdayNumOf(date);
  const matched=jobRouteTemplates.filter(t=>(t.weekDays||[]).includes(dnum));
  if(!matched.length){alert('⚠️ ไม่มีเส้นทางหลักที่ตั้งค่าให้วิ่งวัน'+WEEKDAY_LABELS_JP[dnum-1]+'เลย');return;}
  const existing=jobPlanRows.filter(r=>r.workDate===date);
  let addedCount=0,updatedCount=0;
  const updates={}; // id -> {route,standbyTime}
  const toAdd=[];
  matched.forEach(t=>{
    // หาแถวเดิมที่เคยสร้างจากเทมเพลตตัวนี้โดยตรง (ผูกด้วย sourceTemplateId) ก่อน — แม่นยำกว่าเทียบข้อความ
    const linkedRow=existing.find(r=>r.sourceTemplateId===t.id);
    if(linkedRow){
      if(!linkedRow.dispatched&&(linkedRow.route!==t.route||linkedRow.standbyTime!==t.standbyTime)){
        updates[linkedRow.id]={route:t.route,standbyTime:t.standbyTime};
        updatedCount++;
      }
      return;
    }
    // ไม่มีแถวที่ผูกไว้ — เช็คว่ามีแถวที่ข้อความตรงกันอยู่แล้วไหม (กันสร้างซ้ำ เผื่อเคยเพิ่มด้วยมือ) ถ้าไม่มีเลยค่อยสร้างใหม่
    const textMatch=existing.find(r=>(r.route||'')===(t.route||'')&&(r.standbyTime||'')===(t.standbyTime||''));
    if(!textMatch){
      toAdd.push({id:'jp_'+Date.now()+'_'+Math.random().toString(36).slice(2,6)+Math.random(),workDate:date,route:t.route,standbyTime:t.standbyTime,empId:'',empName:'',plate:'',phone:'',remark:'',dispatched:false,sourceTemplateId:t.id});
      addedCount++;
    }
  });
  if(!addedCount&&!updatedCount){alert('✅ วันนี้มีเส้นทางครบและตรงกับเทมเพลตล่าสุดแล้ว ไม่มีอะไรต้องแก้');return;}
  jobPlanRows=jobPlanRows.map(r=>updates[r.id]?{...r,...updates[r.id]}:r).concat(toAdd);
  saveJobPlan();renderJobPlan();
  const parts=[];
  if(addedCount)parts.push(`เพิ่ม ${addedCount} เส้นทางที่ขาด`);
  if(updatedCount)parts.push(`อัปเดตชื่อ/เวลา ${updatedCount} เส้นทาง`);
  showDocUploadToast(`✅ ${parts.join(' และ ')}แล้ว`,true);
}

function addJobPlanRow(workDate){
  if(!confirm('เพิ่มเส้นทางใหม่ 1 แถวในวันนี้?'))return;
  const d=workDate||todayStrJP();
  const _newId='jp_'+Date.now()+'_'+Math.random().toString(36).slice(2,6);
  jobPlanRows=jobPlanRows.concat([{id:_newId,workDate:d,route:'',standbyTime:'',empId:'',empName:'',plate:'',phone:'',remark:'',dispatched:false}]);
  saveJobPlan(_newId);renderJobPlan();
}

// เพิ่มวันที่ใหม่ทั้งกลุ่ม — เลือกได้ 3 แบบ: (1) สร้างอัตโนมัติจากเส้นทางหลักตามวันในสัปดาห์ (2) คัดลอกจากวันที่มีอยู่ (3) เริ่มว่างเปล่า
function addNewDateGroup(){
  const sel=document.getElementById('jpNewDateSel');
  const date=sel?sel.value:'';
  if(!date){alert('⚠️ กรุณาเลือกวันที่ก่อน');return;}
  if(jobPlanRows.some(r=>r.workDate===date)){
    alert('มีแผนงานวันที่นี้อยู่แล้ว เลื่อนลงไปดู/เพิ่มเส้นทางในตารางของวันนั้นได้เลย');
    renderJobPlan();
    return;
  }
  const source=document.getElementById('jpCopyFromSel')?.value||'';
  if(source==='__template__'){
    const dnum=weekdayNumOf(date);
    const matched=jobRouteTemplates.filter(t=>(t.weekDays||[]).includes(dnum));
    if(!matched.length){
      alert(`⚠️ ไม่มีเส้นทางหลักที่ตั้งค่าให้วิ่งวัน${WEEKDAY_LABELS_JP[dnum-1]} เลย กรุณาไปตั้งค่า "เส้นทางหลักประจำสัปดาห์" ก่อน หรือเลือก "ไม่คัดลอก" แล้วพิมพ์เอง`);
      return;
    }
    const newRows=matched.map(t=>({id:'jp_'+Date.now()+'_'+Math.random().toString(36).slice(2,6)+Math.random(),workDate:date,route:t.route,standbyTime:t.standbyTime,empId:'',empName:'',plate:'',phone:'',remark:'',dispatched:false,sourceTemplateId:t.id}));
    jobPlanRows=jobPlanRows.concat(newRows);
    saveJobPlan();renderJobPlan();
    showDocUploadToast(`✅ สร้าง ${matched.length} เส้นทางอัตโนมัติสำหรับวัน${WEEKDAY_LABELS_JP[dnum-1]} แล้ว`,true);
    return;
  }
  if(source){
    const srcRows=jobPlanRows.filter(r=>r.workDate===source);
    const newRows=srcRows.map(r=>({id:'jp_'+Date.now()+'_'+Math.random().toString(36).slice(2,6)+Math.random(),workDate:date,route:r.route,standbyTime:r.standbyTime,empId:'',empName:'',plate:'',phone:'',remark:'',dispatched:false}));
    jobPlanRows=jobPlanRows.concat(newRows);
    saveJobPlan();renderJobPlan();
    return;
  }
  addJobPlanRow(date);
}

function jpExistingDateOptionsHTML(cur){
  const dates=[...new Set(jobPlanRows.map(r=>r.workDate).filter(Boolean))].sort();
  let html='<option value="">-- ไม่คัดลอก (เริ่มว่างเปล่า) --</option>';
  html+=`<option value="__template__" ${cur==='__template__'?'selected':''}>🔁 สร้างอัตโนมัติจากเส้นทางหลัก (ตามวันในสัปดาห์)</option>`;
  if(dates.length){
    html+='<option disabled>── หรือคัดลอกทั้งวันจากวันที่มีอยู่ ──</option>';
    html+=dates.map(d=>`<option value="${d}" ${cur===d?'selected':''}>${fmtJobDateFull(d)}</option>`).join('');
  }
  return html;
}

// คัดลอก "เฉพาะเส้นทางเดียว" ไปอีกวันหนึ่ง — ใช้เมื่อเส้นทางซ้ำแค่บางวัน ไม่ใช่ทุกวัน (ไม่ต้องคัดลอกทั้งวันทิ้งของที่ไม่ตรง)
let _jpCopySourceId=null;
function copyRouteToDate(rowId){
  const row=jobPlanRows.find(r=>r.id===rowId);
  if(!row)return;
  _jpCopySourceId=rowId;
  document.getElementById('jpCopyRouteLabel').textContent=row.route?('เส้นทาง: '+row.route):'(ยังไม่ได้กรอกเส้นทาง)';
  document.getElementById('jpCopyRouteDateSel').innerHTML=jobPlanDateOptionsHTML('');
  document.getElementById('jpCopyRouteModal').classList.remove('hidden');
}
function closeJpCopyRouteModal(){
  document.getElementById('jpCopyRouteModal').classList.add('hidden');
  _jpCopySourceId=null;
}
function confirmCopyRouteToDate(){
  const row=jobPlanRows.find(r=>r.id===_jpCopySourceId);
  const date=document.getElementById('jpCopyRouteDateSel')?.value;
  if(!row||!date){alert('⚠️ กรุณาเลือกวันที่ปลายทาง');return;}
  const newRow={id:'jp_'+Date.now()+'_'+Math.random().toString(36).slice(2,6),workDate:date,route:row.route,standbyTime:row.standbyTime,empId:'',empName:'',plate:'',phone:'',remark:'',dispatched:false};
  jobPlanRows=jobPlanRows.concat([newRow]);
  saveJobPlan(newRow.id);
  closeJpCopyRouteModal();
  renderJobPlan();
  showDocUploadToast('✅ คัดลอกเส้นทางไปวันที่ '+fmtJobDateFull(date)+' แล้ว',true);
}

async function delJobPlanRow(id){
  const row=jobPlanRows.find(r=>r.id===id);
  if(!row)return;
  if(!confirm('ลบเส้นทางนี้?'))return;
  // คืนสถานะพนักงานเฉพาะตอนที่ "จ่ายงานไปแล้วจริง" เท่านั้น — ถ้าแค่เลือกชื่อไว้ในแผนร่างยังไม่เคยกดจ่ายงาน ไม่เคยไปแตะสถานะเขาเลยตั้งแต่แรก ไม่ต้องคืนอะไร
  if(row.dispatched&&row.empId){
    if(confirm(`เส้นทางนี้จ่ายงานให้ "${row.empName}" ไปแล้ว — ต้องการคืนสถานะพนักงานคนนี้กลับเป็นสถานะก่อนได้งานด้วยไหม?`)){
      await revertJobAssignment(row.empId,id);
    }
  }
  jobPlanRows=jobPlanRows.filter(r=>r.id!==id);
  saveJobPlan(id);renderJobPlan();
}

function updateJobPlanField(id,field,value){
  jobPlanRows=jobPlanRows.map(r=>r.id===id?{...r,[field]:value}:r);
  saveJobPlan(id);
  // สำคัญ: ไม่ sync สถานะ/แจ้งเตือนไปหาพนักงานจากการแก้ไขข้อความเลย ไม่ว่าจะจ่ายงานไปแล้วหรือยัง
  // การแก้เส้นทาง/เวลา/หมายเหตุ เป็นแค่การแก้แผนในหน้าแอดมิน ต้องกดปุ่ม "จ่ายงาน" เท่านั้นถึงจะแจ้งพนักงานจริง
}

async function syncJobNoteToEmployee(row){
  if(!row||!row.empId)return;
  const emp=employees.find(e=>e.id===row.empId);
  // จำสถานะ "ก่อนได้งาน" ไว้ ก่อนทับเป็น got_job — เผื่อไว้คืนกลับตอนงานถูกดึงออก (เช่น สแตนบายว่างงาน ก็ต้องกลับไปสแตนบายว่างงาน ไม่ใช่เหมารวมเป็นสแตนบายรอขึ้นงานเสมอ)
  // ถ้าตอนนี้เป็น got_job อยู่แล้ว (เช่น sync ซ้ำ/แก้ไขข้อมูลงานเดิม) ไม่ทับ previousStatus เดิมที่เคยจำไว้
  const prevStatus=(emp&&emp.status!=='got_job')?emp.status:(emp?.previousStatus||'standby');
  const patch={status:'got_job',note:buildJobNoteText(row),province:'',jobWorkDate:row.workDate||'',previousStatus:prevStatus,updatedAt:new Date().toISOString()};
  employees=employees.map(e=>e.id===row.empId?{...e,...patch}:e);
  _cacheSet('ske_emp',employees);
  try{ await fbPatchEmployee(row.empId,patch); }catch(e){console.warn('sync job note error',e);}
  const dash=document.getElementById('dashboard');
  if(dash&&!dash.classList.contains('hidden'))renderDashboard();
}
// คืนสถานะพนักงานเมื่อถูกถอด/สลับออกจากแถวหนึ่ง (เฉพาะกรณีที่เคยจ่ายงานไปแล้วจริง) — แต่ก่อนคืนสถานะ เช็คก่อนว่า "ยังมีงานอื่นค้างอยู่ไหม"
// (เผื่อคนคนเดียวถูกมอบหมายมากกว่า 1 เส้นทาง/วัน) ถ้ามีงานอื่นค้าง ให้คงสถานะ "ได้งานแล้ว" ไว้ตามงานที่เหลือแทน ไม่คืนทับ
// คืนกลับไปที่ "สถานะก่อนได้งาน" เป๊ะๆ (ไม่ใช่เหมารวมเป็นสแตนบายรอขึ้นงานเสมอ) และไม่ใส่ข้อความ "งานถูกยกเลิก" อัตโนมัติอีกต่อไป
// (ถ้าแอดมินอยากแจ้งพนักงานว่างานถูกยกเลิกจริงๆ ให้ไปพิมพ์ในช่องหมายเหตุตอนแก้ไขสถานะเองแทน)
async function revertJobAssignment(empId,excludeRowId){
  const otherRow=jobPlanRows.find(r=>r.id!==excludeRowId&&r.empId===empId&&r.dispatched);
  if(otherRow){
    await syncJobNoteToEmployee(otherRow);
    return;
  }
  const emp=employees.find(e=>e.id===empId);
  const restoreStatus=emp?.previousStatus||'standby';
  const patch={status:restoreStatus,note:'',updatedAt:new Date().toISOString()};
  employees=employees.map(e=>e.id===empId?{...e,...patch}:e);
  _cacheSet('ske_emp',employees);
  try{ await fbPatchEmployee(empId,patch); }catch(e){console.warn('revert job error',e);}
}

// เลือก/สลับ/ล้างชื่อพนักงานในแถว — เป็นแค่การแก้ "แผนร่าง" เท่านั้น ไม่แจ้ง/ไม่แตะสถานะพนักงานเลย
// ต้องกดปุ่ม "🚀 จ่ายงาน" (รายเส้นทางหรือรวมทั้งวัน) เท่านั้นถึงจะส่งสถานะ "ได้งานแล้ว" ไปหาพนักงานจริง
async function onJobPlanEmpChange(id,empId){
  const row=jobPlanRows.find(r=>r.id===id);
  if(!row)return;
  const prevEmpId=row.empId;
  const wasDispatched=row.dispatched;
  if(!empId){
    // ล้างชื่อออก — คืนสถานะคนเดิมเฉพาะตอนที่เคยจ่ายงานให้เขาไปแล้วจริงเท่านั้น
    if(wasDispatched&&prevEmpId&&confirm(`เส้นทางนี้จ่ายงานให้ "${row.empName}" ไปแล้ว — ต้องการคืนสถานะกลับเป็นสถานะก่อนได้งานด้วยไหม?`)){
      await revertJobAssignment(prevEmpId,id);
    }
    jobPlanRows=jobPlanRows.map(r=>r.id===id?{...r,empId:'',empName:'',plate:'',phone:'',dispatched:false}:r);
    saveJobPlan(id);renderJobPlan();
    return;
  }
  const emp=employees.find(e=>e.id===empId);
  if(!emp)return;
  // ถ้าแถวนี้ "เคยจ่ายงานไปแล้วจริง" แล้วมาสลับตัวคนขับ ต้องคืนสถานะคนเดิมก่อน (เพราะเขาถูกแจ้งไปแล้วจริง)
  // กรณีนี้ถือเป็น "การแก้ไขงานที่จ่ายไปแล้วโดยตรง" ไม่ใช่การวางแผนร่างใหม่ — จึงต้องแจ้งคนใหม่ทันที ไม่ต้องรอกดปุ่มจ่ายงานซ้ำอีกรอบ
  // (ต่างจากแถวที่ยังไม่เคยจ่ายงานเลย ซึ่งยังคงเป็นแค่แผนร่าง ต้องกดจ่ายงานเองก่อนถึงจะแจ้งจริง)
  if(wasDispatched&&prevEmpId&&prevEmpId!==empId){
    await revertJobAssignment(prevEmpId,id);
  }
  jobPlanRows=jobPlanRows.map(r=>r.id===id?{...r,empId:emp.id,empName:emp.name,plate:emp.plate||'',phone:emp.phone||'',dispatched:wasDispatched}:r);
  saveJobPlan(id);
  renderJobPlan();
  if(wasDispatched){
    if(isPastWorkDate(row.workDate)){
      showDocUploadToast(`✅ บันทึกเปลี่ยนเป็น "${emp.name}" แล้ว (ไม่ได้แจ้งเตือน เพราะวันที่ผ่านไปแล้ว)`,true);
    }else{
      await syncJobNoteToEmployee(jobPlanRows.find(r=>r.id===id));
      showDocUploadToast(`✅ ส่งงานนี้ให้ "${emp.name}" แทนแล้ว`,true);
    }
  }
}

// ══ Export แผนงานทั้งหมดเป็น CSV (เปิดใน Excel ได้) — ไว้เก็บสำเนา/บันทึกภาพรวมแยกในคอม ══
function exportJobPlanCSV(){
  if(!jobPlanRows||!jobPlanRows.length){alert('ยังไม่มีแผนงานให้ดาวน์โหลด');return;}
  const rows=[['วันที่','เส้นทาง','เวลาสแตนบาย','ชื่อพนักงาน','ทะเบียนรถ','เบอร์โทร','หมายเหตุ','สถานะจ่ายงาน']];
  jobPlanRows.slice()
    .sort((a,b)=>(a.workDate||'').localeCompare(b.workDate||'')) // จัดกลุ่มตามวันที่เท่านั้น ภายในวันเดียวกันเรียงตามลำดับในแผนงานจริง ไม่เรียงซ้ำตามเวลาอีก
    .forEach(r=>{
      rows.push([
        r.workDate?fmtJobDateFull(r.workDate):'',
        r.route||'',
        r.standbyTime||'',
        r.empName||'',
        r.plate||'',
        r.phone||'',
        r.remark||'',
        r.dispatched?'จ่ายงานแล้ว':(r.empId?'รอจ่ายงาน':'ยังไม่มอบหมาย')
      ]);
    });
  const esc2=v=>{const s=String(v);return /[",\n]/.test(s)?'"'+s.replace(/"/g,'""')+'"':s;};
  const csv='\uFEFF'+rows.map(row=>row.map(esc2).join(',')).join('\r\n'); // \uFEFF = BOM กัน Excel อ่านภาษาไทยเพี้ยน
  const blob=new Blob([csv],{type:'text/csv;charset=utf-8;'});
  const url=URL.createObjectURL(blob);
  const a=document.createElement('a');
  a.href=url;a.download='แผนงาน_'+new Date().toISOString().slice(0,10)+'.csv';
  document.body.appendChild(a);a.click();a.remove();
  setTimeout(()=>URL.revokeObjectURL(url),3000);
}

// จ่ายงานเฉพาะเส้นทางเดียว (แยกจากปุ่มจ่ายงานรวมทั้งวัน) — ใช้เวลาเพิ่มเส้นทางใหม่เข้าไปในวันที่จ่ายงานไปแล้วบางส่วน
// กันปัญหาเดิม: ถ้าใช้ปุ่ม "จ่ายงานวันนี้" ซ้ำทั้งวัน อาจไปกระทบคนที่จ่ายไปแล้วโดยไม่ตั้งใจ จ่ายทีละเส้นจึงชัดเจนและปลอดภัยกว่า
async function dispatchJobPlanRow(rowId){
  const row=jobPlanRows.find(r=>r.id===rowId);
  if(!row)return;
  if(row.dispatched){alert('เส้นทางนี้จ่ายงานไปแล้ว');return;}
  if(!row.empId){alert('⚠️ กรุณาเลือกพนักงานก่อนจ่ายงาน');return;}
  if(!row.route||!row.standbyTime){alert('⚠️ กรุณากรอกเส้นทาง/เวลาสแตนบายให้ครบก่อนจ่ายงาน');return;}
  const isPast=isPastWorkDate(row.workDate);
  const confirmMsg=isPast
    ? `วันที่ในแผนนี้ (${fmtJobDateFull(row.workDate)}) ผ่านไปแล้ว — ระบบจะบันทึกเป็นข้อมูลไว้เท่านั้น "จะไม่ส่งแจ้งเตือนไปหา ${row.empName}" ยืนยันบันทึกไหม?`
    : `ยืนยันจ่ายงานเส้นทางนี้ให้ "${row.empName}"?`;
  if(!confirm(confirmMsg))return;
  if(!isPast)await syncJobNoteToEmployee(row);
  jobPlanRows=jobPlanRows.map(r=>r.id===rowId?{...r,dispatched:true,dispatchedAt:new Date().toISOString()}:r);
  await saveJobPlan(rowId);
  renderJobPlan();
  showDocUploadToast(isPast?`✅ บันทึกข้อมูล "${row.empName}" ไว้แล้ว (ไม่ได้แจ้งเตือน เพราะวันที่ผ่านไปแล้ว)`:`✅ จ่ายงานให้ "${row.empName}" แล้ว`,true);
}

async function dispatchJobPlan(date){
  const assigned=jobPlanRows.filter(r=>r.workDate===date&&r.empId&&!r.dispatched);
  if(!assigned.length){alert('⚠️ วันนี้ยังไม่มีเส้นทางที่มอบหมายพนักงานไว้ (หรือจ่ายงานไปครบหมดแล้ว)');return;}
  const ready=assigned.filter(r=>r.route&&r.standbyTime);
  const incomplete=assigned.length-ready.length;
  if(!ready.length){alert('⚠️ กรุณากรอกเส้นทาง/เวลาสแตนบาย ให้ครบก่อนจ่ายงาน');return;}
  const dateLabel=fmtJobDateFull(date);
  const isPast=isPastWorkDate(date);
  const pastNote=isPast?' — วันที่นี้ผ่านไปแล้ว จะบันทึกเป็นข้อมูลเท่านั้น ไม่ส่งแจ้งเตือนไปหาพนักงาน':'';
  if(incomplete>0&&!confirm(`วันที่ ${dateLabel} มี ${incomplete} เส้นทางที่กรอกไม่ครบ จะข้ามไปก่อน — ยืนยันจ่ายงานให้พนักงาน ${ready.length} คนที่กรอกครบแล้วหรือไม่?${pastNote}`))return;
  if(incomplete===0&&!confirm(`ยืนยันจ่ายงานวันที่ ${dateLabel} ให้พนักงาน ${ready.length} คน?${pastNote}`))return;
  showDocUploadPopup(isPast?'กำลังบันทึกข้อมูล':'กำลังจ่ายงาน','กรุณารอสักครู่ อย่าเพิ่งปิดหน้านี้');
  const dispatchedIds=[];
  for(const row of ready){
    if(!isPast)await syncJobNoteToEmployee(row);
    jobPlanRows=jobPlanRows.map(r=>r.id===row.id?{...r,dispatched:true,dispatchedAt:new Date().toISOString()}:r);
    dispatchedIds.push(row.id);
  }
  await saveJobPlan(dispatchedIds);
  renderJobPlan();
  hideDocUploadPopup();
  alert(isPast
    ?`✅ บันทึกข้อมูลวันที่ ${dateLabel} ไว้แล้ว ${ready.length} รายการ (ไม่ได้แจ้งเตือนพนักงาน เพราะวันที่ผ่านไปแล้ว)`
    :`✅ จ่ายงานวันที่ ${dateLabel} ให้พนักงาน ${ready.length} คนเรียบร้อยแล้ว — สถานะของทุกคนเปลี่ยนเป็น "ได้งานแล้ว" แล้ว`);
}

// ══ เส้นทางหลักประจำสัปดาห์ (route templates) ══
// วันในสัปดาห์: 1=จันทร์ 2=อังคาร 3=พุธ 4=พฤหัสบดี 5=ศุกร์ 6=เสาร์ 7=อาทิตย์ (ตรงกับที่ผู้ใช้ระบุ)
const WEEKDAY_LABELS_JP=['จ','อ','พ','พฤ','ศ','ส','อา']; // index 0-6 = วันที่ 1-7
// แปลงวันที่ (YYYY-MM-DD) เป็นเลขวันในสัปดาห์ 1-7 (จันทร์=1...อาทิตย์=7) — JS Date.getDay() ให้ อาทิตย์=0 เลยต้องแปลง
function weekdayNumOf(dateStr){
  const d=new Date(dateStr+'T00:00:00');
  if(isNaN(d.getTime()))return null;
  const jsDay=d.getDay(); // 0=อาทิตย์...6=เสาร์
  return jsDay===0?7:jsDay;
}
function saveJobRouteTemplates(){
  _cacheSet('ske_jobtemplates',jobRouteTemplates);
  if(window.fbSaveJobRouteTemplates)return window.fbSaveJobRouteTemplates(jobRouteTemplates).catch(()=>{});
  return Promise.resolve();
}
function renderJobRouteTemplates(){
  const el=document.getElementById('jobTemplateList');
  if(!el)return;
  if(!jobRouteTemplates.length){
    el.innerHTML='<div style="font-size:12px;color:#aaa;padding:8px 0;">ยังไม่มีเส้นทางหลัก กด "+ เพิ่มเส้นทางหลัก" ด้านล่างเพื่อเริ่มต้น</div>';
    return;
  }
  el.innerHTML=jobRouteTemplates.map(t=>`
    <div class="card" style="padding:10px;">
      <input class="inp" value="${esc(t.route||'')}" placeholder="พิมพ์เส้นทาง..." onblur="updateJobRouteTemplate('${t.id}','route',this.value)" style="margin-bottom:6px;">
      <div style="display:flex;gap:6px;align-items:center;">
        <select class="inp" style="flex:1;" onchange="updateJobRouteTemplate('${t.id}','standbyTime',this.value)">${jobPlanTimeOptionsHTML(t.standbyTime)}</select>
        <button onclick="delJobRouteTemplate('${t.id}')" style="background:none;border:none;color:#DC2626;font-size:16px;cursor:pointer;flex-shrink:0;">🗑️</button>
      </div>
      <div style="display:flex;gap:4px;margin-top:8px;flex-wrap:wrap;">
        ${WEEKDAY_LABELS_JP.map((lb,i)=>{
          const dnum=i+1;
          const on=(t.weekDays||[]).includes(dnum);
          return `<button onclick="toggleTemplateWeekday('${t.id}',${dnum})" style="width:34px;height:34px;border-radius:8px;border:1.5px solid ${on?'#7B2FBE':'#E8EAF0'};background:${on?'#7B2FBE':'#F5F6FA'};color:${on?'#fff':'#888'};font-size:12px;font-weight:700;cursor:pointer;">${lb}</button>`;
        }).join('')}
      </div>
    </div>`).join('');
}
function addJobRouteTemplate(){
  jobRouteTemplates=jobRouteTemplates.concat([{id:'jt_'+Date.now()+'_'+Math.random().toString(36).slice(2,6),route:'',standbyTime:'',weekDays:[1,2,3,4,5,6,7]}]);
  saveJobRouteTemplates();renderJobRouteTemplates();
}
function delJobRouteTemplate(id){
  if(!confirm('ลบเส้นทางหลักนี้? (ไม่กระทบแผนงานที่สร้างไปแล้ว)'))return;
  jobRouteTemplates=jobRouteTemplates.filter(t=>t.id!==id);
  saveJobRouteTemplates();renderJobRouteTemplates();
}
function updateJobRouteTemplate(id,field,value){
  jobRouteTemplates=jobRouteTemplates.map(t=>t.id===id?{...t,[field]:value}:t);
  saveJobRouteTemplates();
}
function toggleTemplateWeekday(id,dnum){
  jobRouteTemplates=jobRouteTemplates.map(t=>{
    if(t.id!==id)return t;
    const cur=t.weekDays||[];
    const next=cur.includes(dnum)?cur.filter(d=>d!==dnum):cur.concat([dnum]).sort();
    return {...t,weekDays:next};
  });
  saveJobRouteTemplates();renderJobRouteTemplates();
}

function doAddEmp(){
  const nameEl=document.getElementById('addName');
  const name=nameEl.value.trim();
  const position=document.getElementById('addPosition')?.value.trim()||'';
  const plate=document.getElementById('addPlate').value.trim().toUpperCase();
  const phone=document.getElementById('addPhone').value.trim();
  if(!name){
    alert('⚠️ กรุณากรอกชื่อ-นามสกุลก่อนบันทึก');
    nameEl.focus();nameEl.style.borderColor='#DC2626';nameEl.style.boxShadow='0 0 0 2px #FCA5A5';
    return;
  }
  employees.push({id:Date.now()+'',name,position,plate,phone,status:'standby',province:'',note:'',updatedAt:new Date().toISOString()});
  saveE();['addName','addPosition','addPlate','addPhone'].forEach(x=>{const el=document.getElementById(x);if(el)el.value='';});
  document.getElementById('addEmpForm').classList.add('hidden');renderAdminEmpList();
}

// ══════════════════════════════════════════════════════════════════════════
// ── สลับคนขับ (Switch Driver) ──
// ใช้เวลาเจ้าของรถ/พนักงานคนอื่นต้องขับแทนคันที่ไม่ใช่คันประจำของตัวเอง (เช่น พนักงานลา)
// โดยไม่ต้องไปสร้างพนักงานใหม่หรือแก้ฟอร์มทีละคน — แค่เปลี่ยนทะเบียนรถ (plate) ที่ผูกกับพนักงานคนนั้น
// ประวัติเก่าทั้งหมด (ลา/ซ่อม/เที่ยววิ่ง/เอกสาร ฯลฯ) ผูกกับ empId อยู่แล้ว จึงไม่ถูกกระทบ
// ══════════════════════════════════════════════════════════════════════════
let _sd={step:1,plate:'',driverMode:'',driverId:'',newName:'',newPhone:'',ownerPickOpen:false,ownerPickMarkNew:false,q:''};
function _swDistinctPlates(){
  const map=new Map();
  employees.forEach(e=>{
    const p=(e.plate||'').trim();
    if(!p)return;
    if(!map.has(p))map.set(p,[]);
    map.get(p).push(e);
  });
  return [...map.entries()].map(([plate,emps])=>({plate,emps})).sort((a,b)=>a.plate.localeCompare(b.plate));
}
// รายการรถจริงจากทะเบียนรถ (vehicles) — ครอบคลุมรถที่ยังไม่มีคนขับด้วย ไม่ใช่แค่ทะเบียนที่มีคนผูกอยู่ในโปรไฟล์พนักงาน
function _swVehicleGroups(){
  return vehicles.filter(v=>v.active!==false).map(v=>{
    const p=(v.plate||'').trim();
    const emps=employees.filter(e=>(e.plate||'').trim()===p&&e.status!=='inactive');
    return{plate:p,emps};
  }).sort((a,b)=>a.plate.localeCompare(b.plate));
}
function _swOwnerEmp(){return employees.find(e=>e.isOwner)||null;}
function openSwitchDriverModal(){
  _sd={step:1,plate:'',driverMode:'',driverId:'',newName:'',newPhone:'',ownerPickOpen:false,ownerPickMarkNew:false,q:''};
  let ov=document.getElementById('switchDriverModal');
  if(!ov){
    ov=document.createElement('div');ov.id='switchDriverModal';
    ov.style.cssText='position:fixed;inset:0;z-index:10002;background:rgba(15,23,42,.55);display:flex;align-items:flex-end;justify-content:center;';
    ov.onclick=ev=>{if(ev.target===ov)closeSwitchDriverModal();};
    document.body.appendChild(ov);
  }
  ov.style.display='flex';
  renderSwitchDriverModal();
}
function closeSwitchDriverModal(){const ov=document.getElementById('switchDriverModal');if(ov)ov.style.display='none';}
function _sdDots(){
  return `<div style="display:flex;gap:6px;padding:2px 0 12px;">
    ${[1,2,3].map(n=>`<div style="height:7px;border-radius:4px;background:${_sd.step>=n?'#7B2FBE':'#E2E8F0'};width:${_sd.step===n?'22px':'7px'};transition:.2s;"></div>`).join('')}
  </div>`;
}
function renderSwitchDriverModal(){
  const ov=document.getElementById('switchDriverModal');if(!ov)return;
  let body='';
  if(_sd.step===1)body=_sdStep1Html();
  else if(_sd.step===2)body=_sdStep2Html();
  else if(_sd.step===3)body=_sdStep3Html();
  else if(_sd.step===4)body=_sdDoneHtml();
  ov.innerHTML=`<div style="width:100%;max-width:480px;background:#fff;border-radius:20px 20px 0 0;padding:18px 18px 22px;max-height:88vh;overflow:auto;box-shadow:0 -10px 40px rgba(0,0,0,.25);" onclick="event.stopPropagation()">
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:4px;">
      <div style="font-size:16px;font-weight:900;color:#1a1a2e;flex:1;">🔄 สลับคนขับ</div>
      <button onclick="closeSwitchDriverModal()" style="width:30px;height:30px;border-radius:50%;background:#F5F6FF;color:#555;border:none;font-size:14px;">✕</button>
    </div>
    ${_sd.step<4?_sdDots():''}
    ${body}
  </div>`;
}
function _sdStep1Html(){
  const groups=_swVehicleGroups();
  return `<div style="font-size:11px;font-weight:800;color:#7B2FBE;text-transform:uppercase;letter-spacing:.03em;">ขั้นตอนที่ 1 / 3</div>
    <div style="font-size:16px;font-weight:900;color:#1a1a2e;margin:2px 0 12px;">เลือกรถที่จะสลับคนขับ</div>
    <input class="inp" placeholder="หรือพิมพ์ทะเบียนรถ..." value="${esc(_sd.plate)}" oninput="_sd.plate=this.value.toUpperCase();document.getElementById('sdNext1').disabled=!_sd.plate.trim();" style="margin-bottom:12px;text-transform:uppercase;">
    <div style="display:flex;flex-direction:column;gap:8px;max-height:280px;overflow:auto;">
      ${groups.map(g=>{
        const sel=_sd.plate===g.plate;
        const names=g.emps.length?g.emps.map(e=>e.name).join(', '):'ยังไม่มีคนขับ';
        const anyLeave=g.emps.some(e=>isLeaveActiveToday(e));
        return `<div onclick="_sd.plate='${esc(g.plate)}';document.getElementById('sdNext1').disabled=false;renderSwitchDriverModal();" style="display:flex;align-items:center;gap:10px;border:1.5px solid ${sel?'#7B2FBE':'#E8EAF0'};background:${sel?'#F5F0FF':'#fff'};border-radius:14px;padding:11px 13px;cursor:pointer;">
          <div style="width:38px;height:38px;border-radius:10px;background:#EEF2FF;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0;">🚛</div>
          <div style="flex:1;min-width:0;">
            <div style="font-size:14px;font-weight:900;color:#1a1a2e;">${esc(g.plate)}</div>
            <div style="font-size:11px;color:#888;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">คนขับปัจจุบัน: ${esc(names)}</div>
          </div>
          ${anyLeave?'<span style="font-size:10px;font-weight:800;padding:3px 8px;border-radius:999px;background:#FFF7ED;color:#C2410C;border:1px solid #FDBA74;white-space:nowrap;">🌴 ลาอยู่</span>':''}
        </div>`;
      }).join('')}
    </div>
    ${!groups.length?'<div style="text-align:center;color:#94A3B8;font-size:12.5px;padding:10px 4px;">ยังไม่มีรถในระบบ — ไปเพิ่มรถที่ "จัดการรถ" ก่อน หรือพิมพ์ทะเบียนด้านบนได้เลย</div>':''}
    <div style="display:flex;gap:8px;margin-top:16px;">
      <button class="btn btn-gray" style="flex:1;" onclick="closeSwitchDriverModal()">ยกเลิก</button>
      <button class="btn btn-purple" id="sdNext1" style="flex:1;" ${_sd.plate.trim()?'':'disabled'} onclick="_sd.step=2;renderSwitchDriverModal();">ถัดไป →</button>
    </div>`;
}
function _sdEmpListHtml(){
  const q=_sd.q.toLowerCase().trim();
  const list=employees.filter(e=>!q||(e.name||'').toLowerCase().includes(q)||(e.plate||'').toLowerCase().includes(q));
  return list.map(e=>{
        const sel=_sd.driverMode==='existing'&&_sd.driverId===e.id;
        return `<div onclick="_sd.driverMode='existing';_sd.driverId='${e.id}';renderSwitchDriverModal();" style="display:flex;align-items:center;gap:10px;border:1.5px solid ${sel?'#7B2FBE':'#E8EAF0'};background:${sel?'#F5F0FF':'#fff'};border-radius:14px;padding:11px 13px;cursor:pointer;">
          <div class="avatar" style="width:38px;height:38px;font-size:14px;">${avatarImg(e,38)||esc((e.name||'?').charAt(0))}</div>
          <div style="flex:1;min-width:0;">
            <div style="font-size:13.5px;font-weight:900;color:#1a1a2e;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${esc(e.name)}${e.isOwner?' 👑':''}</div>
            <div style="font-size:11px;color:#888;">ปัจจุบันขับ ${esc(e.plate||'-')}${e.plate===_sd.plate?' เช่นกัน':''}</div>
          </div>
        </div>`;
      }).join('')||'<div style="text-align:center;color:#94A3B8;font-size:12.5px;padding:16px;">ไม่พบพนักงาน</div>';
}
function sdOnSearchInput(val){
  _sd.q=val;
  const el=document.getElementById('sdEmpListContainer');
  if(el)el.innerHTML=_sdEmpListHtml();
}
function _sdStep2Html(){
  const owner=_swOwnerEmp();
  const chosen=_sd.driverMode==='existing'||_sd.driverMode==='owner'||_sd.driverMode==='new';
  return `<div style="font-size:11px;font-weight:800;color:#7B2FBE;text-transform:uppercase;letter-spacing:.03em;">ขั้นตอนที่ 2 / 3</div>
    <div style="font-size:16px;font-weight:900;color:#1a1a2e;margin:2px 0 12px;">วันนี้ใครขับ <span style="color:#7B2FBE;">${esc(_sd.plate)}</span></div>
    ${_sd.ownerPickOpen?`
      <div style="background:#FFFBEB;border:1.5px solid #FDE68A;border-radius:12px;padding:11px;margin-bottom:12px;">
        <div style="font-size:12.5px;font-weight:800;color:#92400E;margin-bottom:8px;">ยังไม่เคยตั้งค่าว่าใครคือเจ้าของ เลือกเลยครับ</div>
        <select id="sdOwnerPick" class="inp" style="margin-bottom:8px;">
          ${employees.map(e=>`<option value="${e.id}">${esc(e.name)}</option>`).join('')}
          <option value="__new__">— ยังไม่มีในระบบ (สร้างโปรไฟล์ใหม่) —</option>
        </select>
        <div style="display:flex;gap:8px;">
          <button class="btn btn-gray btn-sm" style="flex:1;" onclick="_sd.ownerPickOpen=false;renderSwitchDriverModal();">ยกเลิก</button>
          <button class="btn btn-orange btn-sm" style="flex:1;" onclick="sdConfirmOwnerPick()">✓ ยืนยันว่านี่คือฉัน</button>
        </div>
      </div>
    `:''}
    ${_sd.driverMode==='newForm'?`
      <div style="background:#F5F0FF;border:1.5px solid #DDD6FE;border-radius:12px;padding:11px;margin-bottom:12px;">
        <div style="font-size:12.5px;font-weight:800;color:#5B21B6;margin-bottom:8px;">${_sd.ownerPickMarkNew?'สร้างโปรไฟล์เจ้าของใหม่':'เพิ่มคนขับใหม่'}</div>
        <input class="inp" id="sdNewName" placeholder="ชื่อ-นามสกุล" value="${esc(_sd.newName)}" style="margin-bottom:8px;">
        <input class="inp" id="sdNewPhone" placeholder="เบอร์โทรศัพท์" value="${esc(_sd.newPhone)}" style="margin-bottom:8px;">
        <div style="display:flex;gap:8px;">
          <button class="btn btn-gray btn-sm" style="flex:1;" onclick="_sd.driverMode='';renderSwitchDriverModal();">ยกเลิก</button>
          <button class="btn btn-purple btn-sm" style="flex:1;" onclick="sdConfirmNewDriver()">✓ ยืนยันคนขับใหม่</button>
        </div>
      </div>
    `:''}
    <input class="inp" placeholder="🔍 ค้นหาชื่อพนักงาน..." value="${esc(_sd.q)}" oninput="sdOnSearchInput(this.value)" style="margin-bottom:10px;">
    <div style="font-size:10.5px;color:#94A3B8;font-weight:800;margin-bottom:6px;text-transform:uppercase;">ตัวเลือกด่วน</div>
    <div style="display:flex;flex-direction:column;gap:8px;margin-bottom:14px;">
      <div onclick="sdClickOwner()" style="display:flex;align-items:center;gap:10px;border:1.5px solid ${_sd.driverMode==='owner'?'#7B2FBE':'#E8EAF0'};background:${_sd.driverMode==='owner'?'#F5F0FF':'#fff'};border-radius:14px;padding:11px 13px;cursor:pointer;">
        <div style="width:38px;height:38px;border-radius:50%;background:linear-gradient(135deg,#FBBF24,#F59E0B);display:flex;align-items:center;justify-content:center;font-size:16px;color:#fff;flex-shrink:0;">👑</div>
        <div style="flex:1;min-width:0;">
          <div style="font-size:13.5px;font-weight:900;color:#1a1a2e;">ฉันขับเอง (เจ้าของ)</div>
          <div style="font-size:11px;color:#888;">${owner?esc(owner.name):'ยังไม่ได้ตั้งค่า — กดเพื่อเลือก'}</div>
        </div>
      </div>
      <div onclick="_sd.driverMode='newForm';_sd.ownerPickMarkNew=false;_sd.newName='';_sd.newPhone='';renderSwitchDriverModal();" style="display:flex;align-items:center;gap:10px;border:1.5px solid ${_sd.driverMode==='new'?'#7B2FBE':'#E8EAF0'};background:${_sd.driverMode==='new'?'#F5F0FF':'#fff'};border-radius:14px;padding:11px 13px;cursor:pointer;">
        <div style="width:38px;height:38px;border-radius:50%;background:#F1F5F9;border:1.5px dashed #CBD5E1;display:flex;align-items:center;justify-content:center;font-size:18px;color:#94A3B8;flex-shrink:0;">＋</div>
        <div style="flex:1;min-width:0;">
          <div style="font-size:13.5px;font-weight:900;color:#1a1a2e;">${_sd.driverMode==='new'?esc(_sd.newName):'เพิ่มคนขับใหม่'}</div>
          <div style="font-size:11px;color:#888;">ตั้งชื่อ + เบอร์ครั้งแรกครั้งเดียว</div>
        </div>
      </div>
    </div>
    <div style="font-size:10.5px;color:#94A3B8;font-weight:800;margin-bottom:6px;text-transform:uppercase;">พนักงานทั้งหมด</div>
    <div id="sdEmpListContainer" style="display:flex;flex-direction:column;gap:8px;max-height:220px;overflow:auto;">
      ${_sdEmpListHtml()}
    </div>
    <div style="display:flex;gap:8px;margin-top:16px;">
      <button class="btn btn-gray" style="flex:1;" onclick="_sd.step=1;renderSwitchDriverModal();">ย้อนกลับ</button>
      <button class="btn btn-purple" style="flex:1;" ${chosen?'':'disabled'} onclick="_sd.step=3;renderSwitchDriverModal();">ถัดไป →</button>
    </div>`;
}
function sdClickOwner(){
  const owner=_swOwnerEmp();
  if(owner){_sd.driverMode='owner';_sd.driverId=owner.id;renderSwitchDriverModal();return;}
  _sd.ownerPickOpen=true;renderSwitchDriverModal();
}
function sdConfirmOwnerPick(){
  const val=document.getElementById('sdOwnerPick')?.value;
  if(!val)return;
  _sd.ownerPickOpen=false;
  if(val==='__new__'){_sd.driverMode='newForm';_sd.ownerPickMarkNew=true;_sd.newName='';_sd.newPhone='';renderSwitchDriverModal();return;}
  employees=employees.map(e=>e.id===val?{...e,isOwner:true}:e);
  saveE();
  if(window.fbUpdateEmployeeFields)fbPatchEmployee(val,{isOwner:true});
  _sd.driverMode='owner';_sd.driverId=val;
  renderSwitchDriverModal();
}
function sdConfirmNewDriver(){
  const name=(document.getElementById('sdNewName')?.value||'').trim();
  const phone=(document.getElementById('sdNewPhone')?.value||'').trim();
  if(!name){alert('กรุณากรอกชื่อคนขับใหม่');return;}
  _sd.newName=name;_sd.newPhone=phone;
  _sd.driverMode='new';
  renderSwitchDriverModal();
}
function _sdStep3Html(){
  let driverName='',driverAvatar='👤';
  if(_sd.driverMode==='existing'){const e=employees.find(x=>x.id===_sd.driverId);driverName=e?e.name:'-';}
  else if(_sd.driverMode==='owner'){const e=employees.find(x=>x.id===_sd.driverId);driverName=(e?e.name:'เจ้าของ')+' (เจ้าของ)';driverAvatar='👑';}
  else if(_sd.driverMode==='new'){driverName=_sd.newName+' (คนขับใหม่)';driverAvatar='＋';}
  const currentDrivers=employees.filter(e=>e.plate===_sd.plate&&!((_sd.driverMode==='existing'||_sd.driverMode==='owner')&&e.id===_sd.driverId));
  return `<div style="font-size:11px;font-weight:800;color:#7B2FBE;text-transform:uppercase;letter-spacing:.03em;">ขั้นตอนที่ 3 / 3</div>
    <div style="font-size:16px;font-weight:900;color:#1a1a2e;margin:2px 0 12px;">ยืนยันการสลับคนขับ</div>
    <div style="background:#F5F0FF;border:1.5px solid #DDD6FE;border-radius:16px;padding:18px;text-align:center;margin-bottom:14px;">
      <div style="font-size:20px;font-weight:900;color:#7B2FBE;letter-spacing:.02em;">${esc(_sd.plate)}</div>
      <div style="font-size:20px;color:#7B2FBE;margin:6px 0;">⬇</div>
      <div style="font-size:16px;font-weight:900;color:#1a1a2e;">${driverAvatar} ${esc(driverName)}</div>
    </div>
    ${currentDrivers.length?`<div style="background:#FFFBEB;border:1.5px solid #FDE68A;border-radius:12px;padding:10px 12px;font-size:11.5px;color:#92400E;line-height:1.6;margin-bottom:8px;">
      ⚠️ ประวัติเก่าของ <b>${esc(currentDrivers.map(e=>e.name).join(', '))}</b> (ลา/ซ่อม/เที่ยววิ่งที่บันทึกไว้) จะยังอยู่ครบ ไม่ถูกลบหรือแก้ไข — แค่จะไม่ใช่คนขับปัจจุบันของคันนี้อีกต่อไปเท่านั้น
    </div>`:''}
    <div style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:12px;padding:10px 12px;font-size:11px;color:#64748B;line-height:1.6;">
      📌 หลังยืนยัน ทุกหน้าจอ (ภาพรวม/ซ่อมบำรุง/การเงิน) จะอัปเดตชื่อคนขับของ ${esc(_sd.plate)} ให้ทันที
    </div>
    <div style="display:flex;gap:8px;margin-top:16px;">
      <button class="btn btn-gray" style="flex:1;" onclick="_sd.step=2;renderSwitchDriverModal();">ย้อนกลับ</button>
      <button class="btn btn-green" style="flex:1;" onclick="sdConfirmSwitch()">✅ ยืนยันสลับคนขับ</button>
    </div>`;
}
function sdConfirmSwitch(){
  const plate=_sd.plate;
  const now=new Date().toISOString();
  let finalId=null,finalName='';
  if(_sd.driverMode==='existing'||_sd.driverMode==='owner'){
    finalId=_sd.driverId;
    const patch={plate};
    employees=employees.map(e=>e.id===finalId?{...e,...patch}:e);
    saveE();
    if(window.fbUpdateEmployeeFields)fbPatchEmployee(finalId,patch);
    const e=employees.find(x=>x.id===finalId);finalName=e?e.name:'';
  }else if(_sd.driverMode==='new'){
    finalId=Date.now()+'';
    const rec={id:finalId,name:_sd.newName,plate,phone:_sd.newPhone,status:'standby',province:'',note:'',updatedAt:now};
    if(_sd.ownerPickMarkNew)rec.isOwner=true;
    employees.push(rec);
    saveE();
    if(window.fbSaveEmployees)window.fbSaveEmployees(employees);
    finalName=_sd.newName;
  }
  // ── คนขับเก่าของทะเบียนนี้ (ที่ถูกสลับออก) ต้องหายไปจากหน้าสถานะทันที ──
  // ล้างทะเบียน/จังหวัด และตั้งสถานะเป็น 'inactive' (ไม่ตรงกับสถานะใดบนบอร์ด standby/traveling/returning/done ฯลฯ)
  // ประวัติเก่าทั้งหมด (ลา/ซ่อม/เที่ยววิ่ง/เอกสาร) ยังผูกกับ empId เดิมอยู่ครบ ไม่ถูกลบหรือแก้ไข
  const swappedOutIds=employees.filter(e=>e.plate===plate&&e.id!==finalId).map(e=>e.id);
  if(swappedOutIds.length){
    const outPatch={status:'inactive',plate:'',province:'',standbyAt:null,updatedAt:now};
    employees=employees.map(e=>swappedOutIds.includes(e.id)?{...e,...outPatch}:e);
    saveE();
    swappedOutIds.forEach(id=>{
      if(window.fbUpdateEmployeeFields)fbPatchEmployee(id,outPatch);
    });
  }
  _sd.step=4;_sd.doneName=finalName;
  renderSwitchDriverModal();
  renderAdminEmpList();
  const summaryEl=document.getElementById('adminSummaryContent');
  if(summaryEl)summaryEl.innerHTML=buildSummaryHTML();
}
function _sdDoneHtml(){
  return `<div style="text-align:center;padding:26px 10px 6px;">
    <div style="width:64px;height:64px;border-radius:50%;background:#ECFDF5;border:2px solid #6EE7B7;display:flex;align-items:center;justify-content:center;font-size:30px;margin:0 auto 16px;">✅</div>
    <div style="font-size:16px;font-weight:900;color:#1a1a2e;margin-bottom:6px;">สลับคนขับเรียบร้อย</div>
    <div style="font-size:12.5px;color:#64748B;line-height:1.6;">${esc(_sd.plate)} ตอนนี้คนขับคือ<br><b style="color:#1a1a2e;">${esc(_sd.doneName||'-')}</b></div>
    <button class="btn btn-purple btn-full" style="margin-top:20px;" onclick="closeSwitchDriverModal()">เสร็จสิ้น</button>
  </div>`;
}

let _aSel={};
function renderAdminEmpList(){
  const el=document.getElementById('adminEmpList');
  const q=(window.adminSearchQuery||'').toLowerCase().trim();
  const filteredEmployees=employees.filter(e=>{
    if(!q) return true;
    return (e.name||'').toLowerCase().includes(q) || (e.plate||'').toLowerCase().includes(q);
  });
  if(!employees.length){el.innerHTML='<div class="empty-state"><div class="empty-icon">'+skeIcon('user')+'</div><div class="empty-text">ยังไม่มีพนักงาน</div></div>';return;}
  if(!filteredEmployees.length){el.innerHTML='<div class="empty-state"><div class="empty-icon">🔍</div><div class="empty-text">ไม่พบข้อมูลที่ค้นหา</div></div>';return;}
  // อย่ารีเซ็ตตัวเลือกสถานะที่ผู้ดูแลกำลังเลือกค้างไว้ (ยังไม่ได้กดบันทึก) ของพนักงานที่เปิดแผงแก้ไขอยู่
  // กันไม่ให้ realtime update จากพนักงานคนอื่นมาทับสถานะที่เพิ่งเลือก
  filteredEmployees.forEach(e=>{
    const panel=document.getElementById('aef_'+e.id);
    const panelOpen=panel&&!panel.classList.contains('hidden');
    if(!panelOpen)_aSel[e.id]=e.status;
  });
  el.innerHTML=filteredEmployees.map(e=>{
    const s=getS(e.status);const lbl=getFullLabel(e);
    const lp=e.onLeave?leaveApprovalPill(e):null;
    return`<div class="emp-card" style="margin-bottom:12px;">
      <div class="emp-card-row">
        <div class="avatar" style="width:42px;height:42px;font-size:18px;">${avatarImg(e,42)}${leaveIcon(e)}</div>
        <div style="flex:1;min-width:0;">
          <div style="color:#1a1a2e;font-weight:700;">${esc(e.name)}${e.position?` <span style="color:#1E90D6;font-weight:600;font-size:11px;background:#EFF6FF;border-radius:6px;padding:1px 7px;">${esc(e.position)}</span>`:''}</div>
          <div style="color:#888;font-size:11px;">🚛 ${esc(e.plate||'ยังไม่ระบุทะเบียน')}${phoneLink(e.phone)}${lineLink(e.lineId)}</div>
          ${e.status==='standby'&&e.province?`<div style="color:#7B2FBE;font-size:11px;margin-top:2px;">${skeIcon('pin')} ${esc(e.province)}</div>`:''}
          ${e.note?`<div style="color:#92400E;font-size:11px;margin-top:4px;background:#FFFBEB;border:1px solid #FDE68A;border-radius:6px;padding:4px 8px;">${skeIcon('note')} ${esc(e.note)}</div>`:''}
          ${e.onLeave?`<div style="color:#475569;font-size:11px;margin-top:4px;">${skeIcon('leave')} ลา: ${fmtLeaveRange(e)}</div>`:''}
          ${e.onLeave&&e.leaveNote?`<div style="color:#92400E;font-size:11px;margin-top:4px;background:#FFFBEB;border:1px solid #FDE68A;border-radius:6px;padding:4px 8px;">${skeIcon('note')} ${esc(e.leaveNote)}</div>`:''}
          ${lp?`<span class="pill" style="background:${lp.bg};color:${lp.color};border:1px solid ${lp.border};font-size:10px;margin-top:4px;display:inline-block;">${lp.text}</span>`:''}
        </div>
        <div class="pill" style="background:${s.bg};color:${s.color};border:1px solid ${s.border};font-size:10px;flex-shrink:0;">${skeIcon(s.ic)} ${getS(e.status).label}</div>
      </div>
      <div class="row-btns" style="margin-top:10px;">
        <button class="btn btn-blue btn-sm" style="flex:1;" onclick="openAEdit('${e.id}')">✏️ แก้ไข</button>
        <button class="btn btn-red btn-sm" style="flex:1;" onclick="doDelEmp('${e.id}')">🗑️ ลบ</button>
      </div>
      <div id="aef_${e.id}" class="hidden" style="margin-top:12px;border-top:1px solid #E8EAF0;padding-top:12px;display:flex;flex-direction:column;gap:11px;">
        <div style="color:#1E90D6;font-weight:700;">✏️ แก้ไข: ${esc(e.name)}</div>
        <div style="display:flex;flex-direction:column;align-items:center;gap:6px;">
          <div class="avatar-upload" onclick="document.getElementById('aeavatar_${e.id}').click()">
            <div class="avatar" id="aeav_${e.id}" style="width:72px;height:72px;font-size:28px;">${avatarImg(e,72)||esc((e.name||'?').charAt(0))}</div>
            <div class="avatar-upload-overlay"><span>📷</span></div>
          </div>
          <div style="font-size:11px;color:#888;">กดรูปเพื่อเปลี่ยนรูปโปรไฟล์พนักงาน</div>
          <input type="file" id="aeavatar_${e.id}" accept="image/*" style="display:none;" onchange="handleAdminAvatarChange(this,'${e.id}')">
          <button type="button" class="btn btn-sm btn-gray ${e.photo?'':'hidden'}" id="aeavatarrm_${e.id}" onclick="removeAdminAvatar('${e.id}')" style="font-size:11px;padding:4px 12px;">🗑️ ลบรูปโปรไฟล์</button>
        </div>
        <div><div class="inp-label">ชื่อ</div><input class="inp" id="aen_${e.id}" value="${esc(e.name)}"></div>
        <div><div class="inp-label">ตำแหน่ง</div><select class="inp" id="aepos_${e.id}" onchange="aOnPositionChange('${e.id}')">${positionOptionsHTML(e.position||'')}</select></div>
        <div><div class="inp-label">ทะเบียน (ไม่บังคับ — เลือกทีหลังได้)</div><select class="inp" id="aep_${e.id}" onchange="aOnPositionChange('${e.id}')">${vehiclePlateOptionsHTML(e.plate)}</select></div>
        <div><div class="inp-label">เบอร์โทร</div><input class="inp" id="aeph_${e.id}" value="${esc(e.phone||'')}" type="tel" inputmode="tel"></div>
        <div><div class="inp-label">💬 LINE ID <span style="font-size:10px;color:#888;font-weight:400;">(สำหรับปุ่ม "LINE ด่วน" — ดู ID ได้จาก LINE ตัวเอง > โปรไฟล์)</span></div><input class="inp" id="aeli_${e.id}" value="${esc(e.lineId||'')}" placeholder="เช่น somchai_ske"></div>
        <div style="background:#F0FDFA;border:1px solid #99F6E4;border-radius:8px;padding:9px 11px;display:flex;align-items:center;justify-content:space-between;gap:8px;">
          <span style="font-size:12.5px;color:#0F766E;font-weight:600;">🔑 PIN ปัจจุบัน: <b id="curpin_${e.id}" data-pin="${esc(e.pin||'')}" style="letter-spacing:2px;">••••</b></span>
          <button type="button" class="btn btn-sm btn-gray" style="padding:4px 12px;font-size:11px;" onclick="toggleEmpPin('${e.id}',this)">👁️ แสดง</button>
        </div>
        <div><div class="inp-label">🔒 รีเซ็ต PIN <span style="font-size:10px;color:#888;font-weight:400;">(เว้นว่างถ้าไม่ต้องการเปลี่ยน)</span></div><input class="inp" id="aepin_${e.id}" type="password" inputmode="numeric" maxlength="4" placeholder="PIN ใหม่ 4 หลัก"></div>
        <div class="status-grid">${STATUSES.map(st=>{
          // ฝั่งแอดมิน: ล็อกปุ่มสแตนบายเฉพาะถ้า "ไม่มีทะเบียนรถ" เท่านั้น ไม่เช็คตำแหน่ง — แอดมินต้องตั้งสถานะแทนรถร่วมได้ (มีรถจริง แค่ไม่ได้ใช้แอปเอง)
          const noVehicle=!e.plate;
          const disabled=noVehicle&&st.id==='standby';
          return`<button class="status-opt" id="aes_${e.id}_${st.id}" ${disabled?'disabled':''}
          style="border-color:${e.status===st.id?st.color:'#E8EAF0'};color:${disabled?'#CBD5E1':(e.status===st.id?st.color:'#888')};background:${disabled?'#F8FAFC':(e.status===st.id?st.bg:'#F5F6FA')};${disabled?'cursor:not-allowed;':''}"
          ${disabled?'':`onclick="aSelStat('${e.id}','${st.id}')"`}><span class="status-emoji" style="color:${disabled?'#CBD5E1':st.color}">${skeIcon(st.ic)}</span><br>${st.label}</button>`;}).join('')}</div>
        <div id="aprv_${e.id}">${e.plate?provHTML(e.status,e.province||''):'<div style="font-size:11.5px;color:#94A3B8;background:#F8FAFC;border:1px dashed #CBD5E1;border-radius:8px;padding:8px 10px;">📍 ยังไม่มีทะเบียนรถผูกไว้ — ไม่ต้องระบุจังหวัดสแตนบาย</div>'}</div>
        <div><div class="inp-label">หมายเหตุ</div><textarea class="inp" id="aen2_${e.id}" rows="2">${esc(e.note||'')}</textarea></div>
        <div style="border-top:1px solid #E8EAF0;padding-top:11px;">
          <label style="display:flex;align-items:center;gap:8px;font-size:13px;font-weight:700;color:#475569;cursor:pointer;">
            <input type="checkbox" id="aeleave_${e.id}" ${e.onLeave?'checked':''} onchange="toggleAEditLeave('${e.id}')" style="width:18px;height:18px;flex-shrink:0;">
            <span class="ic" style="vertical-align:-.14em">${skeIcon('leave')}</span> อยู่ระหว่างลา / แจ้งลา
          </label>
          <div id="aeleavebox_${e.id}" class="${e.onLeave?'':'hidden'}" style="margin-top:10px;display:flex;flex-direction:column;gap:9px;">
            <div><div class="inp-label">ลาตั้งแต่วันที่</div><input type="date" class="inp" id="aeleavefrom_${e.id}" value="${e.leaveFrom||''}"></div>
            <div><div class="inp-label">ถึงวันที่</div><input type="date" class="inp" id="aeleaveto_${e.id}" value="${e.leaveTo||''}"></div>
            <div><div class="inp-label">หมายเหตุการลา</div><textarea class="inp" id="aeleavenote_${e.id}" rows="2">${esc(e.leaveNote||'')}</textarea></div>
            ${e.onLeave?`<div style="display:flex;gap:6px;">
              <button class="btn btn-sm ${e.leaveApproval==='approved'?'btn-green':'btn-gray'}" style="flex:1;" onclick="setLeaveApproval('${e.id}','approved')">✅ อนุมัติลา</button>
              <button class="btn btn-sm ${e.leaveApproval==='rejected'?'btn-red':'btn-gray'}" style="flex:1;" onclick="setLeaveApproval('${e.id}','rejected')">❌ ไม่อนุมัติลา</button>
            </div>`:''}
          </div>
        </div>
        <div class="row-btns">
          <button class="btn btn-gray" style="flex:1;" onclick="closeAEdit('${e.id}')">← ยกเลิก</button>
          <button class="btn btn-blue" style="flex:1;" onclick="doSaveAEdit('${e.id}')">✓ บันทึก</button>
        </div>
      </div>
    </div>`;
  }).join('');
}

function openAEdit(id){document.getElementById('aef_'+id).classList.remove('hidden');document.getElementById('aef_'+id).style.display='flex';}
// ── ผู้ดูแลเปลี่ยน/ลบรูปโปรไฟล์ของพนักงานคนอื่นได้จากแผงแก้ไข ──
async function handleAdminAvatarChange(input,id){
  const file=input.files&&input.files[0];
  if(!file)return;
  try{
    const compressed=await compressAvatar(file);
    const av=document.getElementById('aeav_'+id);
    if(av)av.innerHTML=`<img src="${compressed}" style="width:100%;height:100%;object-fit:cover;border-radius:50%;display:block;">`;
    document.getElementById('aeavatarrm_'+id)?.classList.remove('hidden');
    const oldPhoto=(employees.find(x=>x.id===id)||{}).photo;
    const photoId=await uploadPhoto(compressed);
    if(oldPhoto&&window.fbDeletePhotos)window.fbDeletePhotos([oldPhoto]);
    const patch={photo:photoId};
    employees=employees.map(x=>x.id===id?{...x,...patch}:x);
    if(currentUser&&currentUser.id===id)currentUser={...currentUser,...patch};
    saveE();saveU();
    if(window.fbUpdateEmployeeFields)fbPatchEmployee(id,patch);
  }catch(err){console.error('admin avatar error',err);alert('อัปโหลดรูปไม่สำเร็จ ลองใหม่อีกครั้ง');}
  input.value='';
}
function removeAdminAvatar(id){
  if(!confirm('ลบรูปโปรไฟล์ของพนักงานคนนี้?'))return;
  const cur=employees.find(x=>x.id===id);
  if(cur&&cur.photo&&window.fbDeletePhotos)window.fbDeletePhotos([cur.photo]);
  const patch={photo:''};
  employees=employees.map(x=>x.id===id?{...x,...patch}:x);
  if(currentUser&&currentUser.id===id)currentUser={...currentUser,...patch};
  saveE();saveU();
  if(window.fbUpdateEmployeeFields)fbPatchEmployee(id,patch);
  const av=document.getElementById('aeav_'+id);
  const emp=employees.find(x=>x.id===id);
  if(av)av.innerHTML=esc((emp&&emp.name)?emp.name.charAt(0):'?');
  document.getElementById('aeavatarrm_'+id)?.classList.add('hidden');
}
// ผู้ดูแลกดดู PIN ปัจจุบันของพนักงาน
function toggleEmpPin(id,btn){
  const el=document.getElementById('curpin_'+id);
  if(!el)return;
  const pin=el.getAttribute('data-pin')||'';
  const shown=el.getAttribute('data-shown')==='1';
  if(shown){el.textContent='••••';el.setAttribute('data-shown','0');if(btn)btn.textContent='👁️ แสดง';}
  else{el.textContent=pin?pin:'(ยังไม่ตั้ง PIN)';el.setAttribute('data-shown','1');if(btn)btn.textContent='🙈 ซ่อน';}
}
function closeAEdit(id){document.getElementById('aef_'+id).classList.add('hidden');}
function toggleAEditLeave(id){
  const box=document.getElementById('aeleavebox_'+id);
  const cb=document.getElementById('aeleave_'+id);
  if(box&&cb)box.classList.toggle('hidden',!cb.checked);
}
function aSelStat(eid,sid){
  // อ่านค่าจังหวัดจาก dropdown ปัจจุบันก่อน re-render
  const wrap=document.getElementById('aprv_'+eid);
  const curSel=wrap?wrap.querySelector('.province-sel'):null;
  const needProv=sid==='standby'||sid==='traveling'||sid==='returning'||sid==='done';
  const emp=employees.find(e=>e.id===eid);
  const curProv=curSel?curSel.value:(needProv?(emp?.province||''):'');
  _aSel[eid]=sid;
  STATUSES.forEach(st=>{const b=document.getElementById(`aes_${eid}_${st.id}`);if(!b)return;b.style.borderColor=sid===st.id?st.color:'#E8EAF0';b.style.color=sid===st.id?st.color:'#888';b.style.background=sid===st.id?st.bg:'#F5F6FF';});
  if(wrap){
    const curPlate=document.getElementById('aep_'+eid)?.value.trim()||'';
    // ฝั่งแอดมิน: เช็คแค่ "มีทะเบียนรถไหม" ไม่เช็คตำแหน่ง — เพราะแอดมินต้องตั้งค่าสถานะ/จังหวัดแทนรถร่วมได้ (รถร่วมไม่ได้ใช้แอปเอง แต่ยังมีรถต้องติดตาม)
    // ต่างจากฝั่งพนักงานกดเอง (selStat) ที่จำกัดเฉพาะพนักงานขับรถเท่านั้น
    wrap.innerHTML=curPlate?provHTML(sid,curProv):'<div style="font-size:11.5px;color:#94A3B8;background:#F8FAFC;border:1px dashed #CBD5E1;border-radius:8px;padding:8px 10px;">📍 ยังไม่มีทะเบียนรถผูกไว้ — ไม่ต้องระบุจังหวัดสแตนบาย</div>';
  }
}
// เมื่อเปลี่ยนตำแหน่งในฟอร์มแก้ไข — รีเฟรชกล่องจังหวัดให้ตรงกับตำแหน่งที่เพิ่งเลือกทันที
function aOnPositionChange(eid){
  aSelStat(eid,_aSel[eid]||'standby');
}
function doSaveAEdit(id){
  const name=document.getElementById('aen_'+id).value.trim();
  const position=document.getElementById('aepos_'+id)?.value.trim()||'';
  const plate=document.getElementById('aep_'+id).value.trim().toUpperCase();
  const phone=document.getElementById('aeph_'+id).value.trim();
  const lineId=document.getElementById('aeli_'+id)?.value.trim()||'';
  const note=document.getElementById('aen2_'+id).value;
  const newPin=document.getElementById('aepin_'+id)?.value.trim()||'';
  const status=_aSel[id]||'standby';
  // ฝั่งแอดมิน: บังคับเลือกจังหวัดตามว่า "มีทะเบียนรถไหม" เท่านั้น ไม่เช็คตำแหน่ง — เพราะแอดมินต้องตั้งค่าแทนรถร่วมได้ (มีรถจริง แค่ไม่ได้ใช้แอปเอง)
  const noVehicle=!plate;
  const needProv=!noVehicle&&(status==='standby'||status==='traveling'||status==='returning'||status==='done');
  if(noVehicle&&status==='standby'){
    alert('⚠️ ยังไม่ได้ผูกทะเบียนรถให้คนนี้ กรุณาเลือกทะเบียนรถก่อนตั้งสถานะ "สแตนบายรอขึ้นงาน"');
    return;
  }
  const wrap=document.getElementById('aprv_'+id);
  const prov=needProv?(wrap?.querySelector('.province-sel')?.value||''):'';
  if(needProv&&!prov){
    alert('⚠️ กรุณาเลือกจังหวัดก่อนบันทึก');
    const sel=wrap?.querySelector('.province-sel');
    if(sel){sel.focus();sel.style.borderColor='#DC2626';sel.style.boxShadow='0 0 0 2px #FCA5A5';}
    return;
  }
  if(needProv&&!isValidProvince(prov)){
    alert('⚠️ ไม่พบจังหวัดนี้ในรายชื่อ กรุณาเลือกจากรายการที่พิมพ์ขึ้นมา (พิมพ์แล้วแตะเลือกจากลิสต์)');
    const sel=wrap?.querySelector('.province-sel');
    if(sel){sel.focus();sel.style.borderColor='#DC2626';sel.style.boxShadow='0 0 0 2px #FCA5A5';}
    return;
  }
  const onLeave=document.getElementById('aeleave_'+id)?.checked||false;
  const leaveFromVal=document.getElementById('aeleavefrom_'+id)?.value||'';
  const leaveToVal=document.getElementById('aeleaveto_'+id)?.value||'';
  const leaveNoteVal=document.getElementById('aeleavenote_'+id)?.value||'';
  const now=new Date().toISOString();
  employees=employees.map(e=>{
    if(e.id!==id)return e;
    const prev=e;
    const standbyAt=(status==='standby'&&prev.status!=='standby')?now:(status==='standby'?prev.standbyAt||now:null);
    const updated={...e,name,position,plate,phone,lineId,note,status,province:prov,updatedAt:now,standbyAt};
    updated.onLeave=onLeave;
    if(onLeave){
      updated.leaveFrom=leaveFromVal||prev.leaveFrom||null;
      updated.leaveTo=leaveToVal||leaveFromVal||prev.leaveTo||null;
      updated.leaveNote=leaveNoteVal;
      if(!prev.onLeave)updated.leaveApproval='pending';
    }
    if(newPin.length===4&&/^\d{4}$/.test(newPin))updated.pin=newPin;
    recordRunLogIfNeeded(prev,status,note,id,plate,name);
    return updated;
  });
  if(currentUser?.id===id){currentUser={...currentUser,name,position,plate,phone,lineId,note,status,province:prov};saveU();}
  saveE();renderAdminEmpList();
}
function doDelEmp(id){
  if(!confirm('ลบพนักงานคนนี้?'))return;
  employees=employees.filter(e=>e.id!==id);
  if(currentUser?.id===id){currentUser=null;saveU();}
  saveE();renderAdminEmpList();
  renderSysInfo();
}
async function doChangePw(){
  const v=document.getElementById('newPwInput').value;
  const m=document.getElementById('pwMsg');
  if(v.length<4){m.textContent='ต้องมีอย่างน้อย 4 ตัวอักษร';m.style.color='#EF4444';m.classList.remove('hidden');return;}
  await setAdminPw(v);document.getElementById('newPwInput').value='';
  m.textContent='✅ เปลี่ยนรหัสผ่านผู้ดูแลสำเร็จ!';m.style.color='#10B981';m.classList.remove('hidden');
  setTimeout(()=>m.classList.add('hidden'),2500);
}
async function doChangeViewerPw(){
  const v=document.getElementById('newViewerPwInput').value;
  const m=document.getElementById('viewerPwMsg');
  if(v.length<4){m.textContent='ต้องมีอย่างน้อย 4 ตัวอักษร';m.style.color='#EF4444';m.classList.remove('hidden');return;}
  if(await sha256Hex(v)===adminPwHash){m.textContent='⚠️ ห้ามตั้งซ้ำกับรหัสผู้ดูแล';m.style.color='#EF4444';m.classList.remove('hidden');return;}
  await setViewerPw(v);document.getElementById('newViewerPwInput').value='';
  m.textContent='✅ เปลี่ยนรหัสผ่านแอดมินสำเร็จ!';m.style.color='#10B981';m.classList.remove('hidden');
  setTimeout(()=>m.classList.add('hidden'),2500);
}
async function doChangeAdminPin2(){
  const v=document.getElementById('newPin2Input').value.trim();
  const m=document.getElementById('pin2Msg');
  if(v.length<4){m.textContent='ต้องมีอย่างน้อย 4 หลัก';m.style.color='#EF4444';m.classList.remove('hidden');return;}
  await setAdminPin2(v);document.getElementById('newPin2Input').value='';
  m.textContent='✅ เปลี่ยน PIN ชั้นที่ 2 สำเร็จ!';m.style.color='#10B981';m.classList.remove('hidden');
  setTimeout(()=>m.classList.add('hidden'),2500);
}
async function doChangeEmergencyCode(){
  const v=document.getElementById('newEmergInput').value;
  const m=document.getElementById('emergMsg');
  if(v.length<8){m.textContent='ต้องมีอย่างน้อย 8 ตัวอักษร (ยิ่งจำยากยิ่งปลอดภัย)';m.style.color='#EF4444';m.classList.remove('hidden');return;}
  await setEmergencyCode(v);document.getElementById('newEmergInput').value='';
  m.textContent='✅ เปลี่ยน Emergency Code สำเร็จ! เก็บรหัสนี้ไว้ให้ดี ห้ามบอกใคร';m.style.color='#10B981';m.classList.remove('hidden');
  setTimeout(()=>m.classList.add('hidden'),3500);
}

function fmt(iso){if(!iso)return'-';return new Date(iso).toLocaleString('th-TH',{hour:'2-digit',minute:'2-digit',day:'numeric',month:'short'});}

// [ถอดออก] เดิมตรงนี้มี setInterval ทุก 30 วิ ที่อ่าน cache จาก localStorage มาทับตัวแปร employees ในหน่วยความจำ
// เป็นโค้ดยุคก่อนมี Firebase realtime — ปัจจุบันมันคือ "ต้นเหตุสถานะเด้งกลับ":
// 1) ถ้าเปิดแอพ 2 ที่ (PWA + แท็บเบราว์เซอร์) แท็บเก่าจะเขียน cache เวอร์ชันเก่า แล้ว interval ของอีกแท็บดูดค่าเก่ากลับมาทับสถานะที่เพิ่งบันทึก
// 2) หลังเพิ่มระบบตัดรูปออกจาก cache เมื่อพื้นที่เต็ม cache จะไม่มีวันตรงกับข้อมูลจริง ทำให้ทับซ้ำทุก 30 วิ (รูปโปรไฟล์หาย/สถานะย้อน)
// การซิงก์ข้ามเครื่อง/ข้ามแท็บมี onValue ของ Firebase ทำหน้าที่นี้อยู่แล้วแบบเรียลไทม์ ไม่ต้องใช้ตัวนี้
